﻿namespace mn.SSIS.DataAnalyticsRestAPI.TestHarness
{
    partial class DataAnalyticsRestAPITestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProviders = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ProviderComboBox = new System.Windows.Forms.ComboBox();
            this.URLTextBox = new System.Windows.Forms.TextBox();
            this.AccountComboBox = new System.Windows.Forms.ComboBox();
            this.APIKeyTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.APIComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.FromDate = new System.Windows.Forms.DateTimePicker();
            this.ToDate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.PageNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.ResultsTxtBox = new System.Windows.Forms.RichTextBox();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.FirstPageBtn = new System.Windows.Forms.Button();
            this.AllPagesBtn = new System.Windows.Forms.Button();
            this.ResponseDataGridView = new System.Windows.Forms.DataGridView();
            this.EmailAnalyticsSplitContainer = new System.Windows.Forms.SplitContainer();
            this.ChkBoxUserLibToTest = new System.Windows.Forms.CheckBox();
            this.TabControlOutput = new System.Windows.Forms.TabControl();
            this.tabPageGrid = new System.Windows.Forms.TabPage();
            this.tabPageOutput = new System.Windows.Forms.TabPage();
            this.txtBoxXSLT = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.PageNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResponseDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmailAnalyticsSplitContainer)).BeginInit();
            this.EmailAnalyticsSplitContainer.Panel1.SuspendLayout();
            this.EmailAnalyticsSplitContainer.Panel2.SuspendLayout();
            this.EmailAnalyticsSplitContainer.SuspendLayout();
            this.TabControlOutput.SuspendLayout();
            this.tabPageGrid.SuspendLayout();
            this.tabPageOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblProviders
            // 
            this.lblProviders.AutoSize = true;
            this.lblProviders.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProviders.Location = new System.Drawing.Point(3, 9);
            this.lblProviders.Name = "lblProviders";
            this.lblProviders.Size = new System.Drawing.Size(67, 16);
            this.lblProviders.TabIndex = 0;
            this.lblProviders.Text = "Provider";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Account";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(328, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "API Key";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(328, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "URL";
            // 
            // ProviderComboBox
            // 
            this.ProviderComboBox.FormattingEnabled = true;
            this.ProviderComboBox.Location = new System.Drawing.Point(77, 9);
            this.ProviderComboBox.Name = "ProviderComboBox";
            this.ProviderComboBox.Size = new System.Drawing.Size(226, 21);
            this.ProviderComboBox.TabIndex = 1;
            // 
            // URLTextBox
            // 
            this.URLTextBox.Location = new System.Drawing.Point(401, 8);
            this.URLTextBox.Name = "URLTextBox";
            this.URLTextBox.Size = new System.Drawing.Size(507, 20);
            this.URLTextBox.TabIndex = 3;
            // 
            // AccountComboBox
            // 
            this.AccountComboBox.FormattingEnabled = true;
            this.AccountComboBox.Location = new System.Drawing.Point(76, 41);
            this.AccountComboBox.Name = "AccountComboBox";
            this.AccountComboBox.Size = new System.Drawing.Size(226, 21);
            this.AccountComboBox.TabIndex = 5;
            // 
            // APIKeyTextBox
            // 
            this.APIKeyTextBox.Location = new System.Drawing.Point(402, 37);
            this.APIKeyTextBox.Name = "APIKeyTextBox";
            this.APIKeyTextBox.Size = new System.Drawing.Size(362, 20);
            this.APIKeyTextBox.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "API";
            // 
            // APIComboBox
            // 
            this.APIComboBox.FormattingEnabled = true;
            this.APIComboBox.Location = new System.Drawing.Point(77, 75);
            this.APIComboBox.Name = "APIComboBox";
            this.APIComboBox.Size = new System.Drawing.Size(226, 21);
            this.APIComboBox.TabIndex = 9;
            this.APIComboBox.SelectedIndexChanged += new System.EventHandler(this.APIComboBox_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(328, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "From";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(512, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "To";
            // 
            // FromDate
            // 
            this.FromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FromDate.Location = new System.Drawing.Point(401, 76);
            this.FromDate.Name = "FromDate";
            this.FromDate.Size = new System.Drawing.Size(96, 20);
            this.FromDate.TabIndex = 11;
            this.FromDate.ValueChanged += new System.EventHandler(this.FromDate_ValueChanged);
            // 
            // ToDate
            // 
            this.ToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ToDate.Location = new System.Drawing.Point(545, 76);
            this.ToDate.Name = "ToDate";
            this.ToDate.Size = new System.Drawing.Size(101, 20);
            this.ToDate.TabIndex = 13;
            this.ToDate.ValueChanged += new System.EventHandler(this.ToDate_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(677, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Page";
            // 
            // PageNumericUpDown
            // 
            this.PageNumericUpDown.Location = new System.Drawing.Point(728, 76);
            this.PageNumericUpDown.Name = "PageNumericUpDown";
            this.PageNumericUpDown.Size = new System.Drawing.Size(36, 20);
            this.PageNumericUpDown.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 124);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "XSLT";
            // 
            // ResultsTxtBox
            // 
            this.ResultsTxtBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ResultsTxtBox.Location = new System.Drawing.Point(3, 3);
            this.ResultsTxtBox.Name = "ResultsTxtBox";
            this.ResultsTxtBox.Size = new System.Drawing.Size(1041, 409);
            this.ResultsTxtBox.TabIndex = 19;
            this.ResultsTxtBox.Text = "";
            // 
            // CloseBtn
            // 
            this.CloseBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseBtn.Location = new System.Drawing.Point(958, 90);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(92, 33);
            this.CloseBtn.TabIndex = 21;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(958, 51);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(92, 33);
            this.ResetBtn.TabIndex = 20;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // FirstPageBtn
            // 
            this.FirstPageBtn.Location = new System.Drawing.Point(857, 51);
            this.FirstPageBtn.Name = "FirstPageBtn";
            this.FirstPageBtn.Size = new System.Drawing.Size(95, 33);
            this.FirstPageBtn.TabIndex = 16;
            this.FirstPageBtn.Text = "Get First Page";
            this.FirstPageBtn.UseVisualStyleBackColor = true;
            this.FirstPageBtn.Click += new System.EventHandler(this.FirstPageBtn_Click);
            // 
            // AllPagesBtn
            // 
            this.AllPagesBtn.Location = new System.Drawing.Point(857, 90);
            this.AllPagesBtn.Name = "AllPagesBtn";
            this.AllPagesBtn.Size = new System.Drawing.Size(95, 33);
            this.AllPagesBtn.TabIndex = 17;
            this.AllPagesBtn.Text = "Get All Pages";
            this.AllPagesBtn.UseVisualStyleBackColor = true;
            this.AllPagesBtn.Click += new System.EventHandler(this.AllPagesBtn_Click);
            // 
            // ResponseDataGridView
            // 
            this.ResponseDataGridView.AllowUserToAddRows = false;
            this.ResponseDataGridView.AllowUserToDeleteRows = false;
            this.ResponseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ResponseDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ResponseDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ResponseDataGridView.Location = new System.Drawing.Point(3, 3);
            this.ResponseDataGridView.Name = "ResponseDataGridView";
            this.ResponseDataGridView.ReadOnly = true;
            this.ResponseDataGridView.Size = new System.Drawing.Size(1041, 409);
            this.ResponseDataGridView.TabIndex = 23;
            // 
            // EmailAnalyticsSplitContainer
            // 
            this.EmailAnalyticsSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EmailAnalyticsSplitContainer.Location = new System.Drawing.Point(5, 5);
            this.EmailAnalyticsSplitContainer.Name = "EmailAnalyticsSplitContainer";
            this.EmailAnalyticsSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // EmailAnalyticsSplitContainer.Panel1
            // 
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.txtBoxXSLT);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.ChkBoxUserLibToTest);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.CloseBtn);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.ResetBtn);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.AllPagesBtn);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.lblProviders);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.FirstPageBtn);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label1);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label2);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label3);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.ProviderComboBox);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label8);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.URLTextBox);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.PageNumericUpDown);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.AccountComboBox);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label7);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.APIKeyTextBox);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.ToDate);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label4);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.FromDate);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.APIComboBox);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label6);
            this.EmailAnalyticsSplitContainer.Panel1.Controls.Add(this.label5);
            this.EmailAnalyticsSplitContainer.Panel1MinSize = 350;
            // 
            // EmailAnalyticsSplitContainer.Panel2
            // 
            this.EmailAnalyticsSplitContainer.Panel2.Controls.Add(this.TabControlOutput);
            this.EmailAnalyticsSplitContainer.Panel2MinSize = 350;
            this.EmailAnalyticsSplitContainer.Size = new System.Drawing.Size(1055, 795);
            this.EmailAnalyticsSplitContainer.SplitterDistance = 350;
            this.EmailAnalyticsSplitContainer.TabIndex = 24;
            // 
            // ChkBoxUserLibToTest
            // 
            this.ChkBoxUserLibToTest.AutoSize = true;
            this.ChkBoxUserLibToTest.Location = new System.Drawing.Point(857, 35);
            this.ChkBoxUserLibToTest.Name = "ChkBoxUserLibToTest";
            this.ChkBoxUserLibToTest.Size = new System.Drawing.Size(115, 17);
            this.ChkBoxUserLibToTest.TabIndex = 22;
            this.ChkBoxUserLibToTest.Text = "Use Library to Test";
            this.ChkBoxUserLibToTest.UseVisualStyleBackColor = true;
            // 
            // TabControlOutput
            // 
            this.TabControlOutput.Controls.Add(this.tabPageOutput);
            this.TabControlOutput.Controls.Add(this.tabPageGrid);
            this.TabControlOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControlOutput.Location = new System.Drawing.Point(0, 0);
            this.TabControlOutput.Name = "TabControlOutput";
            this.TabControlOutput.SelectedIndex = 0;
            this.TabControlOutput.Size = new System.Drawing.Size(1055, 441);
            this.TabControlOutput.TabIndex = 24;
            // 
            // tabPageGrid
            // 
            this.tabPageGrid.Controls.Add(this.ResponseDataGridView);
            this.tabPageGrid.Location = new System.Drawing.Point(4, 22);
            this.tabPageGrid.Name = "tabPageGrid";
            this.tabPageGrid.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGrid.Size = new System.Drawing.Size(1047, 415);
            this.tabPageGrid.TabIndex = 0;
            this.tabPageGrid.Text = "Results Grid";
            this.tabPageGrid.UseVisualStyleBackColor = true;
            // 
            // tabPageOutput
            // 
            this.tabPageOutput.Controls.Add(this.ResultsTxtBox);
            this.tabPageOutput.Location = new System.Drawing.Point(4, 22);
            this.tabPageOutput.Name = "tabPageOutput";
            this.tabPageOutput.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOutput.Size = new System.Drawing.Size(1047, 415);
            this.tabPageOutput.TabIndex = 1;
            this.tabPageOutput.Text = "Output Messages";
            this.tabPageOutput.UseVisualStyleBackColor = true;
            // 
            // txtBoxXSLT
            // 
            this.txtBoxXSLT.Location = new System.Drawing.Point(6, 143);
            this.txtBoxXSLT.Multiline = true;
            this.txtBoxXSLT.Name = "txtBoxXSLT";
            this.txtBoxXSLT.Size = new System.Drawing.Size(1042, 204);
            this.txtBoxXSLT.TabIndex = 23;
            // 
            // DataAnalyticsRestAPITestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CloseBtn;
            this.ClientSize = new System.Drawing.Size(1065, 805);
            this.Controls.Add(this.EmailAnalyticsSplitContainer);
            this.MaximizeBox = false;
            this.Name = "DataAnalyticsRestAPITestForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = "Email Analytics Data Provider Test Harness";
            this.Load += new System.EventHandler(this.EmailDataAnalyticsTestForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PageNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResponseDataGridView)).EndInit();
            this.EmailAnalyticsSplitContainer.Panel1.ResumeLayout(false);
            this.EmailAnalyticsSplitContainer.Panel1.PerformLayout();
            this.EmailAnalyticsSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.EmailAnalyticsSplitContainer)).EndInit();
            this.EmailAnalyticsSplitContainer.ResumeLayout(false);
            this.TabControlOutput.ResumeLayout(false);
            this.tabPageGrid.ResumeLayout(false);
            this.tabPageOutput.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblProviders;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ProviderComboBox;
        private System.Windows.Forms.TextBox URLTextBox;
        private System.Windows.Forms.ComboBox AccountComboBox;
        private System.Windows.Forms.TextBox APIKeyTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox APIComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker FromDate;
        private System.Windows.Forms.DateTimePicker ToDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown PageNumericUpDown;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox ResultsTxtBox;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button FirstPageBtn;
        private System.Windows.Forms.Button AllPagesBtn;
        private System.Windows.Forms.DataGridView ResponseDataGridView;
        private System.Windows.Forms.SplitContainer EmailAnalyticsSplitContainer;
        private System.Windows.Forms.CheckBox ChkBoxUserLibToTest;
        private System.Windows.Forms.TextBox txtBoxXSLT;
        private System.Windows.Forms.TabControl TabControlOutput;
        private System.Windows.Forms.TabPage tabPageOutput;
        private System.Windows.Forms.TabPage tabPageGrid;
    }
}

