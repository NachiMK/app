﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

using mn.SSIS.DataAnalyticsRestAPI.Library;
using mn.SSIS.Common.XMLLibrary;
using System.Configuration;

namespace mn.SSIS.DataAnalyticsRestAPI.TestHarness
{
    public partial class DataAnalyticsRestAPITestForm : Form
    {
        public DataAnalyticsRestAPITestForm()
        {
            InitializeComponent();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void ResetForm()
        {
            this.URLTextBox.Text = this.ConfigApiUri;
            this.APIKeyTextBox.Text = ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            this.FromDate.Value = DateTime.Now.AddDays(-1);
            this.ToDate.Value = DateTime.Now.AddDays(-1);
            this.PageNumericUpDown.Value = 0;
            this.PageNumericUpDown.ReadOnly = true;
            AddProvidersToComboBox();
            AddAccountsToComboBox();
            AddAPIOptionsToComboBox();
            this.ResultsTxtBox.Text = string.Empty;
            this.ChkBoxUserLibToTest.Checked = true;
            this.txtBoxXSLT.Text = string.Empty;
            this.tabPageOutput.Select();
        }

        private void AddAPIOptionsToComboBox()
        {
            if (this.APIComboBox.Items.Count == 0)
            {
                this.APIComboBox.Items.Clear();
                SortedDictionary<string, string> APIDictionary = new SortedDictionary<string, string>();
                APIDictionary.Add("clicks", "Clicks");
                APIDictionary.Add("opens", "Opens");
                APIDictionary.Add("bounces", "Bounces");
                APIDictionary.Add("campaigns", "Campaigns");

                this.APIComboBox.DataSource = new BindingSource(APIDictionary, null);
                this.APIComboBox.DisplayMember = "Value";
                this.APIComboBox.ValueMember = "Key";
            }
            this.APIComboBox.SelectedIndex = 0;
        }

        private void AddAccountsToComboBox()
        {
            if (this.AccountComboBox.Items.Count == 0)
            {
                this.AccountComboBox.Items.Clear();
                SortedDictionary<int, string> AccountDictionary = GetMaropostAccounts();

                this.AccountComboBox.DataSource = new BindingSource(AccountDictionary, null);
                this.AccountComboBox.DisplayMember = "Value";
                this.AccountComboBox.ValueMember = "Key";
            }
            SetDefaultAccountComboBox();
        }

        private void SetDefaultAccountComboBox()
        {
            for (int Idx = 0; Idx < AccountComboBox.Items.Count; Idx++)
            {
                KeyValuePair<int, string> comboItem = (KeyValuePair<int, string>)AccountComboBox.Items[Idx];
                if (comboItem.Key == 487)
                    AccountComboBox.SelectedIndex = Idx;
            }
        }

        private static SortedDictionary<int, string> GetMaropostAccounts()
        {
            SortedDictionary<int, string> AccountDictionary = new SortedDictionary<int, string>();
            AccountDictionary.Add(493, "SN - Adventist(493)");
            AccountDictionary.Add(494, "SN - BBW(494)");
            AccountDictionary.Add(45, "SN - Believe(45)");
            AccountDictionary.Add(488, "SN - Black Singles(488)");
            AccountDictionary.Add(495, "SN - Catholic(495)");
            AccountDictionary.Add(486, "SN - Christian Mingle(486)");
            AccountDictionary.Add(496, "SN - Cupid(496)");
            AccountDictionary.Add(422, "SN - DailyBibleVerse(422)");
            AccountDictionary.Add(487, "SN - JDate(487)");
            AccountDictionary.Add(497, "SN - JDate France(497)");
            AccountDictionary.Add(498, "SN - JDate Israel(498)");
            AccountDictionary.Add(499, "SN - JDate UK(499)");
            AccountDictionary.Add(9, "SN - LDS Mingle(9)");
            AccountDictionary.Add(489, "SN - LDS Singles(489)");
            AccountDictionary.Add(509, "SN - MilitarySingles(509)");
            AccountDictionary.Add(490, "SN - Silver Singles(490)");
            AccountDictionary.Add(26, "SN - Spark(26)");
            return AccountDictionary;
        }

        private void AddProvidersToComboBox()
        {
            if (this.ProviderComboBox.Items.Count == 0)
            {
                this.ProviderComboBox.Items.Clear();
                SortedDictionary<int, string> ProvidersDictionary = new SortedDictionary<int, string>();
                ProvidersDictionary.Add(1, "Maropost");

                this.ProviderComboBox.DataSource = new BindingSource(ProvidersDictionary, null);
                this.ProviderComboBox.DisplayMember = "Value";
                this.ProviderComboBox.ValueMember = "Key";
            }
            this.ProviderComboBox.SelectedIndex = 0;
        }

        private void AddXMLToResults(string XMLResponse)
        {
            System.IO.StringReader Textreader = new System.IO.StringReader(XMLResponse);

            XmlTextReader reader = new XmlTextReader(Textreader);
            while ((reader != null) && (reader.Read()))
            {
                string strName = reader.Name;
                string strValue = reader.Value;

                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // The node is an element.
                        FormatElement(strName);
                        break;
                    case XmlNodeType.Text: //Display the text in each element.
                        this.ResultsTxtBox.SelectionColor = Color.Black;
                        this.ResultsTxtBox.AppendText(reader.Value);
                        break;
                    case XmlNodeType.EndElement: //Display the end of the element.
                        FormatEndElement(strName);
                        break;
                    case XmlNodeType.Attribute: //Display Attribute.
                        this.ResultsTxtBox.AppendText(strValue);
                        break;
                    default:
                        this.ResultsTxtBox.AppendText(strValue);
                        break;
                }
            }

            if (reader == null)
                OutputValidationMessage(XMLResponse, true);
        }

        private void FormatEndElement(string ReaderName)
        {
            this.ResultsTxtBox.SelectionColor = Color.Blue;
            this.ResultsTxtBox.AppendText("</");
            this.ResultsTxtBox.SelectionColor = Color.Brown;
            this.ResultsTxtBox.AppendText(ReaderName);
            this.ResultsTxtBox.SelectionColor = Color.Blue;
            this.ResultsTxtBox.AppendText(">");
            this.ResultsTxtBox.AppendText("\n");
        }

        private void FormatElement(string ReaderName)
        {
            this.ResultsTxtBox.SelectionColor = Color.Blue;
            this.ResultsTxtBox.AppendText("<");
            this.ResultsTxtBox.SelectionColor = Color.Brown;
            this.ResultsTxtBox.AppendText(ReaderName);
            this.ResultsTxtBox.SelectionColor = Color.Blue;
            this.ResultsTxtBox.AppendText(">");
        }

        private void EmailDataAnalyticsTestForm_Load(object sender, EventArgs e)
        {
            this.ResetForm();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FromDate_ValueChanged(object sender, EventArgs e)
        {
            ValidDateRange();
        }

        private void ToDate_ValueChanged(object sender, EventArgs e)
        {
            ValidDateRange();
        }

        private void ValidDateRange()
        {
            string strMsg;
            bool ShowInRed = false;
            if ((this.FromDate.Value.CompareTo(DateTime.Now) > 0) || (this.ToDate.Value.CompareTo(DateTime.Now) > 0))
            {
                strMsg = "From Date/To Date should NOT be greater than Today.";
                ShowInRed = true;
            }
            else if (this.FromDate.Value.CompareTo(this.ToDate.Value) > 0)
            {
                strMsg = "ToDate should be greater than From Date.";
                ShowInRed = true;
            }
            else
            {
                strMsg = "Date range is good.";
            }
            OutputValidationMessage(strMsg, ShowInRed);
        }

        private void OutputValidationMessage(string Msg, bool ErrorMessage = false)
        {
            if (string.IsNullOrEmpty(Msg))
                return;
            this.ResultsTxtBox.SelectionColor = (ErrorMessage == true) ? Color.Red : Color.Black;
            this.ResultsTxtBox.AppendText(Msg);
            this.ResultsTxtBox.AppendText(System.Environment.NewLine);
            this.ResultsTxtBox.AppendText("--------------------------------------");
            this.ResultsTxtBox.AppendText(System.Environment.NewLine);

            if (ErrorMessage)
                this.tabPageOutput.Select();
        }

        private void FirstPageBtn_Click(object sender, EventArgs e)
        {
            if (!ChkBoxUserLibToTest.Checked)
                AdhocMaropostTesting();
            else
                HttpGet();
        }

        private void HttpGet()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                Application.DoEvents();

                IDataAnalyticsRestAPIProvider _apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(DataAnalyticsRestAPIProviderType.Maropost, this.URLTextBox.Text, this.APIKeyTextBox.Text);
                AddApiParameters(_apiProvider);

                DataAnalyticsRestAPIResponse response = _apiProvider.HttpGet(this.ApiName);
                OutputValidationMessage(response.ToString(), true);
                OutputValidationMessage(response.ResponseXml, false);

                // Transform
                string strXML = TransformXML(response.ResponseXml);

                OutputValidationMessage(strXML, false);

                // Add results
                BindXMLToGridView(strXML);
            }
            catch (Exception ex)
            {
                OutputValidationMessage(ex.Message, true);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void AddApiParameters(IDataAnalyticsRestAPIProvider _apiProvider)
        {
            _apiProvider.Parameters.Add("AccountID", this.AccountID, DataAnlayticsRestAPIParameterType.URLSegmentParameter);

            if (this.ApiName.ToLower() != "campaigns")
            {
                _apiProvider.Parameters.Add("from", this.FromDateString);
                _apiProvider.Parameters.Add("to", this.ToDateString);
                _apiProvider.Parameters.Add("fields", "\"memberid\"");
            }
        }

        private string TransformXML(string XMLResponseString)
        {
            string strReturn = string.Empty;

            try
            {
                if (txtBoxXSLT.Text.Length > 0)
                    strReturn = XMLHelper.Transform(XMLResponseString, txtBoxXSLT.Text);
            }
            catch (Exception ex)
            {
                OutputValidationMessage("Issue applying XSLT transformation.", true);
                OutputValidationMessage(ex.Message, true);
                strReturn = string.Empty;
            }

            return strReturn;
        }

        private void BindXMLToGridView(string XMLResponseString)
        {
            DataSet dsGrid = XMLStringToDataSet(XMLResponseString);
            ResponseDataGridView.DataSource = dsGrid;
            if ((dsGrid != null) && (dsGrid.Tables.Count > 0))
                ResponseDataGridView.DataMember = dsGrid.Tables[0].ToString();
            ResponseDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            ResponseDataGridView.AutoSize = true;
            ResponseDataGridView.EditMode = DataGridViewEditMode.EditProgrammatically;
            setRowNumber(ResponseDataGridView);
            OutputValidationMessage("See Data in Grid Tab.", true);
        }

        private static DataSet XMLStringToDataSet(string XMLResponseString)
        {
            DataSet dsGrid = new DataSet("XMLTable");
            string XMLString = XMLHelper.RemoveAllAttributes(XMLResponseString);
            XmlTextReader xReader = new StringXMLTextReader(XMLString).xmlTextReader;
            dsGrid.ReadXml(xReader, XmlReadMode.InferTypedSchema);
            return dsGrid;
        }

        private void AdhocMaropostTesting()
        {
            string strReturn;

            try
            {
                Cursor.Current = Cursors.WaitCursor;
                Application.DoEvents();
                var OpenResponse = MaropostTryOut.GetOpens(this.ApiUri, this.AccountID, this.ApiKey, this.FromDate.Value, this.ToDate.Value, out strReturn);
                // AddXMLToResults(strResults);
                // Add results
                var bindingList = new BindingList<MaropostOpenResponse>(OpenResponse);
                var source = new BindingSource(bindingList, null);
                ResponseDataGridView.DataSource = source;
                setRowNumber(ResponseDataGridView);
            }
            catch (Exception ex)
            {
                OutputValidationMessage(ex.Message, true);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private string AccountID
        {
            get
            {
                return this.AccountComboBox.SelectedValue.ToString();
            }
        }
        
        private string ApiUri
        {
            get
            {
                string strUri = (string.IsNullOrEmpty(this.URLTextBox.Text)) ? ConfigApiUri : this.URLTextBox.Text;
                if (strUri.Contains("{ApiName}"))
                    strUri = strUri.Replace("{ApiName}", this.ApiName);
                return strUri;
            }
        }

        private string ConfigApiUri
        {
            get
            {
                return ConfigurationManager.AppSettings["API.Maropost.ApiUri"];
            }
        }

        private string ApiKey
        {
            get
            {
                return this.APIKeyTextBox.Text;
            }
        }

        private string ApiName
        {
            get
            {
                return this.APIComboBox.SelectedValue.ToString();
            }
        }

        private string FromDateString
        {
           get
            {
                return FromDate.Value.ToString("yyyy-MM-dd");
            }
        }

        private string ToDateString
        {
            get
            {
                return ToDate.Value.ToString("yyyy-MM-dd");
            }
        }

        private void setRowNumber(DataGridView dgv)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                row.HeaderCell.Value = String.Format("{0}", row.Index + 1);
            }
        }

        private void AllPagesBtn_Click(object sender, EventArgs e)
        {

        }

        private void SetOpensAPIDefaults()
        {
            SetXSLTForClicksBouncesOpens();
        }

        private void SetBouncesAPIDefaults()
        {
            SetXSLTForClicksBouncesOpens();
        }

        private void SetClicksAPIDefaults()
        {
            SetXSLTForClicksBouncesOpens();
        }

        private void SetXSLTForClicksBouncesOpens()
        {
            string strXSLT = "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">"
                              + System.Environment.NewLine + "<xsl:output omit-xml-declaration=\"yes\" indent=\"yes\"/>"
                              + System.Environment.NewLine + "<xsl:strip-space elements=\"*\"/>"
                              + System.Environment.NewLine + " <xsl:template match=\"*\">"
                              + System.Environment.NewLine + "  <xsl:element name=\"{name()}\">"
                              + System.Environment.NewLine + "   <xsl:copy-of select=\"@*\"/>"
                              + System.Environment.NewLine + "   <xsl:apply-templates/>"
                              + System.Environment.NewLine + "  </xsl:element>"
                              + System.Environment.NewLine + " </xsl:template>"
                              + System.Environment.NewLine + " <xsl:template match=\"//contact\">"
                              + System.Environment.NewLine + "  <xsl:apply-templates/>"
                              + System.Environment.NewLine + " </xsl:template>"
                              + System.Environment.NewLine + "</xsl:stylesheet>";

            this.txtBoxXSLT.Text = strXSLT;
        }

        private void SetCampaignsAPIDefaults()
        {
            string strXSLT = "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">"
                              + System.Environment.NewLine + "<xsl:output omit-xml-declaration=\"yes\" indent=\"yes\"/>"
                              + System.Environment.NewLine + "<xsl:strip-space elements=\"*\"/>"
                              + System.Environment.NewLine + " <xsl:template match=\"*\">"
                              + System.Environment.NewLine + "  <xsl:element name=\"{name()}\">"
                              + System.Environment.NewLine + "   <xsl:copy-of select=\"@*\"/>"
                              + System.Environment.NewLine + "   <xsl:apply-templates/>"
                              + System.Environment.NewLine + "  </xsl:element>"
                              + System.Environment.NewLine + " </xsl:template>"
                              + System.Environment.NewLine + "</xsl:stylesheet>";

            this.txtBoxXSLT.Text = strXSLT;
            this.URLTextBox.Text = ConfigurationManager.AppSettings["API.Maropost.Campaig.ApiUri"];
        }

        private void APIComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.APIComboBox.SelectedIndex >= 0)
            {
                this.URLTextBox.Text = ConfigApiUri;
                switch (this.ApiName.ToLower())
                {
                    case "opens":
                        SetOpensAPIDefaults();
                        break;
                    case "bounces":
                        SetBouncesAPIDefaults();
                        break;
                    case "clicks":
                        SetClicksAPIDefaults();
                        break;
                    case "campaigns":
                        SetCampaignsAPIDefaults();
                        break;
                }
                this.URLTextBox.Text = this.ApiUri;
            }
        }

    }
}
