﻿using System;
using System.Data;
using System.Xml.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using mn.SSIS.DataAnalyticsRestAPI.Library;
using RestSharp;

namespace mn.SSIS.DataAnalyticsRestAPI.UnitTest
{
    [TestClass]
    public class UnitTestDataAnalyticsRestAPI
    {
        //public UnitTestEmailAnalyticsDataDnld(EmailAnalyticsDataProviderType providerType, string apiUri, string apiKey, string accountId)
        //{
        //    this.ProviderType = providerType;
        //    this.APIUri = apiUri;
        //    this.APIKey = apiKey;
        //    this.AccountID = accountID;
        //}

        [TestMethod]
        public void TestEmptyAPIDownload()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Generic;
            string strApiUri = string.Empty;
            string strApiKey = string.Empty;
            string strApiName = string.Empty;

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("Name", "Value", DataAnlayticsRestAPIParameterType.URLSegmentParameter);
            apiProvider.Parameters.Add("Name1", "Value1");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsFalse(response.Status == ResponseStatusType.Success);
            Assert.IsTrue(string.IsNullOrEmpty(response.ResponseXml));
        }

        [TestMethod]
        public void TestGenericAPIDownload()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Generic;
            string strApiUri = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.JDate.Opens"];
            string strApiKey = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            string strApiName = "Opens";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
        }

        public void TestMaropostAPIDownload()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = string.Empty;
            string strApiKey = string.Empty;
            string strApiName = string.Empty;

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("", "", DataAnlayticsRestAPIParameterType.URLSegmentParameter);
            apiProvider.Parameters.Add("", "");
            DataAnalyticsRestAPIResponse response = null;
            response = apiProvider.HttpGet(strApiName);
        }

        [TestMethod]
        public void TestMaropostOpensOutOfRangeDate()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.JDate.Opens"];
            string strApiKey = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            string strApiName = "Opens";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "03/05/2016");
            apiProvider.Parameters.Add("to", "03/06/2016");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }

        [TestMethod]
        public void TestMaropostOpens()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.JDate.Opens"];
            string strApiKey = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            string strApiName = "Opens";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "2016-03-05");
            apiProvider.Parameters.Add("to", "2016-03-06");
            apiProvider.Parameters.Add("fields", "\"memberid\"");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }

        [TestMethod]
        public void TestMaropostOpensEmptyResponse()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.JDate.Opens"];
            string strApiKey = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            string strApiName = "Opens";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "2016-01-01");
            apiProvider.Parameters.Add("to", "2016-01-01");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }

        [TestMethod]
        public void TestMaropostInvalidApi()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiUri"];
            strApiUri = strApiUri.Replace("{ApiName}", "NOTAnApi");
            string strApiKey = System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            string strApiName = "Opens";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "03/05/2016");
            apiProvider.Parameters.Add("to", "03/06/2016");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsTrue(string.IsNullOrEmpty(response.ResponseXml));
        }

        [TestMethod]
        public void TestDownloadBounces()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = this.ApiUri.Replace("{ApiName}", "bounces").Replace("{AccountID}", "487");
            string strApiKey = this.ApiKey;
            string strApiName = "bounces";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "2016-03-05");
            apiProvider.Parameters.Add("to", "2016-03-06");
            apiProvider.Parameters.Add("fields", "\"memberid\"");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }


        [TestMethod]
        public void TestDownloadClicks()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = this.ApiUri.Replace("{ApiName}", "clicks").Replace("{AccountID}", "487");
            string strApiKey = this.ApiKey;
            string strApiName = "clicks";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "2016-03-05");
            apiProvider.Parameters.Add("to", "2016-03-06");
            apiProvider.Parameters.Add("fields", "\"memberid\"");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }


        [TestMethod]
        public void TestCampaignDownload()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = this.CampaignApiUri.Replace("{AccountID}", "487");
            string strApiKey = this.ApiKey;
            string strApiName = "campaigns";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status == ResponseStatusType.Success);
            Assert.IsFalse(string.IsNullOrEmpty(response.ResponseXml));
            Assert.IsNotNull(XDocument.Parse(response.ResponseXml));
        }

        [TestMethod]
        public void TestInvalidApiName()
        {
            DataAnalyticsRestAPIProviderType providerType = DataAnalyticsRestAPIProviderType.Maropost;
            string strApiUri = this.ApiUri.Replace("{ApiName}", "INVALID").Replace("{AccountID}", "487");
            string strApiKey = this.ApiKey;
            string strApiName = "INVALID";

            IDataAnalyticsRestAPIProvider apiProvider = DataAnalyticsRestAPIProviderFactory.CreateNew(providerType, strApiUri, strApiKey);
            apiProvider.Parameters.Add("from", "2016-03-05");
            apiProvider.Parameters.Add("to", "2016-03-06");
            apiProvider.Parameters.Add("fields", "\"memberid\"");
            DataAnalyticsRestAPIResponse response = apiProvider.HttpGet(strApiName);

            Assert.IsNotNull(response);
            Assert.IsTrue(response.Status != ResponseStatusType.Success);
            Assert.IsNotNull(response.InnerException);
        }

        private string ApiUri
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiUri"];
            }
        }

        private string ApiKey
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["API.Maropost.ApiKey"];
            }
        }

        private string CampaignApiUri
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["API.Maropost.Campaig.ApiUri"];
            }
        }

    }
}
