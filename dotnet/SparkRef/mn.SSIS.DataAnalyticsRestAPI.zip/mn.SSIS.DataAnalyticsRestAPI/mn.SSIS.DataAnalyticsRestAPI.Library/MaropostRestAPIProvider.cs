﻿using RestSharp;
using RestSharp.Deserializers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mn.SSIS.Common.XMLLibrary;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class MaropostRestAPIProvider : IDataAnalyticsRestAPIProvider
    {
        public string APIUri { get; set; }

        internal string APIKey { get; set; }

        public DataAnalyticsRestAPIParameters Parameters { get; set; }

        private DataAnalyticsRestAPIResponse APIResponse { get; set; }

        public DataAnalyticsRestAPIResponse HttpGet(string ApiName)
        {
            return HttpGet(ApiName, 1);
        }

        public bool IsValidUri()
        {
            Uri uriResult;
            bool result = Uri.TryCreate(APIUri, UriKind.Absolute, out uriResult)
                && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
            return result;
        }

        public DataAnalyticsRestAPIResponse HttpGet(string ApiName, int StartPageIndex = 1)
        {
            APIResponse = new DataAnalyticsRestAPIResponse();
            APIResponse.Status = ResponseStatusType.Initialized;

            try
            {
                if (!IsValidUri())
                    throw new ArgumentException("Invalid API Uri provided.");

                var Restclient = new RestClient(this.APIUri);
                var Restrequest = new RestRequest(Method.GET);

                Restrequest.AddParameter("auth_token", APIKey);
                DataAnalyticsRestAPIProvider.AddParametersToRestClient(Restrequest, Parameters);

                APIResponse.ResponseXml = ExecuteAndGetXML(Restclient, Restrequest, ApiName, StartPageIndex: StartPageIndex);
            }
            catch (Exception ex)
            {
                APIResponse.InnerException = new Exception("Error in HttpGet", ex);
                APIResponse.Status = ResponseStatusType.Failure;
            }

            return APIResponse ;
        }

        private string ExecuteAndGetXML(RestClient Restclient, RestRequest Restrequest, string ApiName, int StartPageIndex = 1)
        {
            StringBuilder retXMLAsString = new StringBuilder(256);

            switch (ApiName.ToLower())
            {
                case "opens":
                case "bounces":
                case "clicks":
                case "campaigns":
                        int PageIndex = StartPageIndex;
                        bool HasMoreRecords = true;

                            try
                            {
                                while (HasMoreRecords)
                                {
                                    // add page parameter
                                    UpsertPageParameter(Restrequest, PageIndex++);

                                    var response = Restclient.Execute(Restrequest);
                                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                                    {
                                        //strReturn = response.Content;
                                        if (response.Content != null)
                                        {
                                            if (XMLHelper.HasElements(response.Content))
                                                XMLHelper.MergeXML(ref retXMLAsString, response.Content);
                                            else
                                            {
                                                //call was successful but no DATA
                                                if (retXMLAsString.Length == 0)
                                                    retXMLAsString.Append(response.Content);
                                                HasMoreRecords = false;
                                            }
                                        }
                                        else
                                            HasMoreRecords = false;
                                    }
                                    else
                                    {
                                        SetResponseAsFailure(response);
                                        HasMoreRecords = false;
                                    }
                                }

                                if (APIResponse.Status == ResponseStatusType.Initialized)
                                    APIResponse.Status = ResponseStatusType.Success;
                            }
                            catch (Exception ex)
                            {
                                this.APIResponse.InnerException = new Exception("Call to Maropost API:" + this.APIUri + " for API Name:" + ApiName + "failed.", ex);
                                this.APIResponse.Status = ResponseStatusType.Failure;
                                this.APIResponse.ResponseMessage = "Call to Maropost API:" + this.APIUri + " for API Name:" + ApiName + "failed.";
                            }
                    break;
                default:
                    APIResponse.Status = ResponseStatusType.InvalidParameters;
                    throw new ArgumentException("Invalid API Name provided.");
            }

            return retXMLAsString.ToString();
        }

        private void UpsertPageParameter(RestRequest Restrequest, int PageNumber)
        {
            Parameter pageParam = null;
            foreach (Parameter p in Restrequest.Parameters)
            {
                if (p.Name == "page")
                {
                    pageParam = p;
                    break;
                }
            }
            
            if (pageParam != null)
                pageParam.Value = PageNumber;
            else
                Restrequest.AddParameter("page", PageNumber);
        }

        private void SetResponseAsFailure(IRestResponse response)
        {
            APIResponse.Status = ResponseStatusType.Failure;
            APIResponse.InnerException = new Exception("API Call returned successfully but HTTP Status code is NOT OK.", response.ErrorException);
            APIResponse.ResponseMessage = "API Call returned successfully but HTTP Status code is NOT OK.";
        }

        private MaropostRestAPIProvider()
        {
            Parameters = new DataAnalyticsRestAPIParameters();
            APIResponse = new DataAnalyticsRestAPIResponse();
        }

        internal MaropostRestAPIProvider(string Uri, string Key)
            : this()
        {
            APIUri = Uri;
            APIKey = Key;
        }
    }

    public class MaropostOpenResponseList : List<MaropostOpenResponse>
    {
        [DeserializeAs(Attribute = true, Name = "type")]
        public string ListType { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(this.Count * 16);
            sb.AppendLine(string.Format("Opens, type:", this.ListType));
            foreach (MaropostOpenResponse m in this)
                sb.AppendLine(m.ToString());
            return sb.ToString();
        }
    }


    [DeserializeAs(Name = "open")]
    public class MaropostOpenResponse
    {
        [DeserializeAs(Name = "account-id")]
        public int AccountId { get; set; }

        [DeserializeAs(Name = "campaign-id")]
        public int CampaignId { get; set; }

        [DeserializeAs(Name = "contact-id")]
        public int ContactId { get; set; }

        [DeserializeAs(Name = "browswer")]
        public string Browser { get; set; }

        [DeserializeAs(Name = "recorded-at")]
        public DateTime RecordedAt { get; set; }

        [DeserializeAs(Name = "contact")]
        public Contact Contact { get; set; }
        public override string ToString()
        {
            StringBuilder strBuffer = new StringBuilder(100);
            strBuffer.AppendLine(string.Format("Account:{0}", AccountId.ToString()));
            strBuffer.AppendLine(string.Format("Campaignid:{0}", CampaignId.ToString()));
            strBuffer.AppendLine(string.Format("Contactid:{0}", ContactId.ToString()));
            strBuffer.AppendLine(string.Format("Browswer:{0}", Browser.ToString()));
            strBuffer.AppendLine(string.Format("Recorded:{0}", RecordedAt.ToString()));
            strBuffer.AppendLine(string.Format("Contact:{0}", Contact.ToString()));
            return strBuffer.ToString();
        }
    }

    public class Contact
    {
        [DeserializeAs(Name = "id")]
        public int Id { get; set; }

        [DeserializeAs(Name = "email")]
        public string Email { get; set; }

        [DeserializeAs(Name = "memberid")]
        public int MemberId { get; set; }
        public override string ToString()
        {
            return string.Format("Id:{0}, Email:{1}, MemberId:{2}", Id.ToString(), Email, MemberId.ToString());
        }
    }

}
