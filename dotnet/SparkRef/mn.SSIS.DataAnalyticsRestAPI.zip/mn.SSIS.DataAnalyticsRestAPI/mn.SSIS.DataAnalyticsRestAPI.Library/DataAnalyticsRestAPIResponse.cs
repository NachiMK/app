﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class DataAnalyticsRestAPIResponse
    {
        private string _ResponseXML;
        private Exception _Exception;

        public ResponseStatusType Status { get; internal set; }

        public bool IsAPICallSuccessful ()
        {
            return (Status == ResponseStatusType.Success);
        }

        public Exception InnerException 
        {
            get
            {
                return _Exception;
            }
            internal set
            {
                if (value != null)
                    _Exception = value;
            }
        }

        public string ResponseMessage { get; internal set; }

        public string ResponseXml 
        { 
            get
            {
                return _ResponseXML;
            }
            internal set
            {
                if (IsValidXML(value))
                    _ResponseXML = value;
            }
        }

        private bool IsValidXML(string value)
        {
            bool retVal = false;

            try
            {
                // Check we actually have a value
                if (string.IsNullOrEmpty(value) == false)
                {
                    // Try to load the value into a document
                    XDocument xmlDoc = XDocument.Parse(value);

                    // If we managed with no exception then this is valid XML!
                    retVal = true;
                }
                else
                {
                    // A blank value is not valid xml
                    retVal = false;
                }
            }
            catch
            {
                retVal = false;
            }

            return retVal;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(100);
            sb.AppendLine(string.Format("Status:{0}", Status.ToString()));
            sb.AppendLine(string.Format("Inner Exception:{0}", (InnerException != null ? InnerException.Message : "No Exception") ));
            sb.AppendLine(string.Format("Message:{0}", ResponseMessage));
            sb.AppendLine(string.Format("Response Data:{0}", (ResponseXml == null ? "ResponseXml IS Empty or Null" : "ResponseXml IS not null")));
            return sb.ToString();
        }


        internal DataAnalyticsRestAPIResponse()
        {
            InitializeDataAnalyticsResponse();
        }

        private void InitializeDataAnalyticsResponse()
        {
            Status = ResponseStatusType.Initialized;
            InnerException = null;
            ResponseMessage = string.Empty;
            ResponseXml = string.Empty;
        }
    }


    public enum ResponseStatusType
    {
        Success,
        Failure,
        InvalidParameters,
        Initialized
    }
}
