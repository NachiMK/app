﻿using RestSharp;
using RestSharp.Deserializers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class MaropostTryOut
    {
        public static MaropostOpenResponseList GetOpens(string URL, string Account, string APIKey, DateTime FromDate, DateTime ToDate, out string Message)
        {
            //http://api.maropost.com/accounts/487/reports/opens.xml?auth_token=ac04c4bbbab94bcbf00266a4582dc01f687efc6c&from=2016-02-01&to=2016-02-02&fields="memberid"

            MaropostOpenResponseList m = new MaropostOpenResponseList();

            string strReturn = string.Empty;

            string strAccount = Account;
            string strURL = URL; // +"/" + strAccount.ToString() + "/reports/opens.xml?";
            string strAPIKey = APIKey;
            string fromDate = FromDate.ToString("yyyy-MM-dd");
            string toDate = ToDate.ToString("yyyy-MM-dd");

            var client = new RestClient(strURL);
            var request = new RestRequest(Method.GET);
            request.AddParameter("AccountID", strAccount, ParameterType.UrlSegment);
            request.AddParameter("auth_token", strAPIKey);
            request.AddParameter("from", fromDate);
            request.AddParameter("to", toDate);
            request.AddParameter("fields", "\"memberid\"");

            //var r = client.Execute(request);
            //r = null;

            int PageIndex = 152;
            bool HasMoreRecords = true;
            StringBuilder sbXML = new StringBuilder(200);

            while (HasMoreRecords)
            {
                // add page parameter
                request.AddParameter("page", PageIndex++);
                var response = client.Execute<MaropostOpenResponseList>(request);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    //strReturn = response.Content;
                    bool bln = HasXMLElements(response.Content);
                    if ((response.Data != null) && (response.Data.Count > 0))
                    {
                        m.AddRange(response.Data);
                        AppendXML(response.Content, ref sbXML);
                    }
                    else
                        HasMoreRecords = false;
                }
                else
                    strReturn = response.ErrorMessage;
            }

            Message = strReturn;
            return m;
        }

        private static bool HasXMLElements(string responseContent)
        {
            try
            {
                using (System.IO.TextReader textReader = new System.IO.StringReader(responseContent))
                {
                    System.Xml.Linq.XDocument x = System.Xml.Linq.XDocument.Load(textReader);
                    if (x != null)
                    {
                        IEnumerable<System.Xml.Linq.XElement> xeElements = x.Elements();
                        if (xeElements != null)
                            return (xeElements.ElementAt<System.Xml.Linq.XElement>(0).Nodes().Count<System.Xml.Linq.XNode>() > 0);
                    }
                }
            }
            catch
            {

            }
            return false;
        }

        private static void AppendXML(string ResponseXML, ref StringBuilder XMLStringBuilder)
        {
            try
            {
                if (XMLStringBuilder == null)
                    XMLStringBuilder = new StringBuilder(256);

                if (XMLStringBuilder.Length > 0)
                {
                    using (System.IO.TextReader TargettextReader = new System.IO.StringReader(XMLStringBuilder.ToString()))
                    {
                        var TargetXML = System.Xml.Linq.XDocument.Load(TargettextReader);

                        using (System.IO.TextReader textReader = new System.IO.StringReader(ResponseXML))
                        {
                            TargetXML.Root.Add(System.Xml.Linq.XDocument.Load(textReader).Root.Elements());
                            XMLStringBuilder.Clear();
                            XMLStringBuilder.Append(TargetXML.ToString());
                        }
                    }
                }
                else
                {
                    XMLStringBuilder.Append(ResponseXML);
                }
            }
            catch
            {

            }
        }
    }

    /*
    public class TwilioApi
    {
        const string BaseUrl = "https://api.twilio.com/2008-08-01";

        readonly string _accountSid;
        readonly string _secretKey;

        public TwilioApi(string accountSid, string secretKey)
        {
            _accountSid = accountSid;
            _secretKey = secretKey;
        }

        public T Execute<T>(RestRequest request) where T : new()
        {
            var client = new RestClient();
            client.BaseUrl = BaseUrl;
            client.Authenticator = new HttpBasicAuthenticator(_accountSid, _secretKey);
            request.AddParameter("AccountSid", _accountSid, ParameterType.UrlSegment); // used on every request
            var response = client.Execute<T>(request);

            if (response.ErrorException != null)
            {
                const string message = "Error retrieving response.  Check inner details for more info.";
                var twilioException = new ApplicationException(message, response.ErrorException);
                throw twilioException;
            }
            return response.Data;
        }
    }
    */

    //public class MaropostOpenResponseList : List<MaropostOpenResponse>
    //{
    //    [DeserializeAs(Attribute = true, Name="type")]
    //    public string ListType { get; set; }

    //    public override string ToString()
    //    {
    //        StringBuilder sb = new StringBuilder(this.Count * 16);
    //        sb.AppendLine(string.Format("Opens, type:", this.ListType));
    //        foreach (MaropostOpenResponse m in this)
    //            sb.AppendLine(m.ToString());
    //        return sb.ToString();
    //    }
    //}


    //[DeserializeAs(Name = "open")]
    //public class MaropostOpenResponse
    //{
    //    [DeserializeAs(Name = "account-id")]
    //    public int AccountId {get; set;}

    //    [DeserializeAs(Name = "campaign-id")]
    //    public int CampaignId {get; set;}
        
    //    [DeserializeAs(Name = "contact-id")]
    //    public int ContactId {get; set;}
        
    //    [DeserializeAs(Name = "browswer")]
    //    public string Browser {get; set;}

    //    [DeserializeAs(Name = "recorded-at")]
    //    public DateTime RecordedAt {get; set;}

    //    [DeserializeAs(Name = "contact")]
    //    public Contact Contact { get; set; }
    //    public override string ToString()
    //    {
    //        StringBuilder strBuffer = new StringBuilder(100);
    //        strBuffer.AppendLine(string.Format("Account:{0}", AccountId.ToString()));
    //        strBuffer.AppendLine(string.Format("Campaignid:{0}", CampaignId.ToString()));
    //        strBuffer.AppendLine(string.Format("Contactid:{0}", ContactId.ToString()));
    //        strBuffer.AppendLine(string.Format("Browswer:{0}", Browser.ToString()));
    //        strBuffer.AppendLine(string.Format("Recorded:{0}", RecordedAt.ToString()));
    //        strBuffer.AppendLine(string.Format("Contact:{0}", Contact.ToString()));
    //        return strBuffer.ToString();
    //    }
    //}

    //public class Contact
    //{
    //    [DeserializeAs(Name="id")]
    //    public int Id { get; set; }

    //    [DeserializeAs(Name = "email")]
    //    public string Email { get; set; }

    //    [DeserializeAs(Name = "memberid")]
    //    public int MemberId { get; set; }
    //    public override string ToString()
    //    {
    //        return string.Format("Id:{0}, Email:{1}, MemberId:{2}", Id.ToString(), Email, MemberId.ToString());
    //    }
    //}

}
