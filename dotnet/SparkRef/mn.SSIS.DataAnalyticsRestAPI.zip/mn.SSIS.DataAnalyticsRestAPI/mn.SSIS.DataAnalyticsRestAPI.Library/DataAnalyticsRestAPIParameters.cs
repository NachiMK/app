﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class DataAnalyticsRestAPIParameters : IEnumerable<DataAnalyticsRestAPIParameter>
    {
        private List<DataAnalyticsRestAPIParameter> _ParameterList;

        internal List<DataAnalyticsRestAPIParameter> Parameters
        {
            get
            {
                return _ParameterList;
            }
        }

        public DataAnalyticsRestAPIParameters()
        {
            _ParameterList = new List<DataAnalyticsRestAPIParameter>();
        }

        public void Add(string Name, string Value, DataAnlayticsRestAPIParameterType ParamType)
        {
            this.Add(new DataAnalyticsRestAPIParameter(Name, Value, ParamType));
        }

        public void Add(String Name, string Value)
        {
            this.Add(new DataAnalyticsRestAPIParameter(Name, Value, DataAnlayticsRestAPIParameterType.URLParameter));
        }

        public void Add(DataAnalyticsRestAPIParameter DataAnalyticsParam)
        {
            if (DataAnalyticsParam != null)
            {
                if (!this.Parameters.Contains(DataAnalyticsParam))
                    this.Parameters.Add(DataAnalyticsParam);
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(100);
            int intIdx = 0;
            foreach(DataAnalyticsRestAPIParameter param in this.Parameters)
            {
                sb.AppendLine(string.Format("Item Count:{0}", intIdx.ToString()));
                sb.AppendLine(param.ToString());
                intIdx++;
            }
            return base.ToString();
        }

        public IEnumerator<DataAnalyticsRestAPIParameter> GetEnumerator()
        {
            return _ParameterList.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }

    public class DataAnalyticsRestAPIParameter
    {
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
        public DataAnlayticsRestAPIParameterType ParameterType { get; set; }

        internal DataAnalyticsRestAPIParameter()
        {

        }

        public DataAnalyticsRestAPIParameter(string Name, string Value) : this(Name, Value, DataAnlayticsRestAPIParameterType.URLParameter)
        { }

        public DataAnalyticsRestAPIParameter(string Name, string Value, DataAnlayticsRestAPIParameterType ParamType)
        {
            this.ParameterName = Name;
            this.ParameterValue = Value;
            this.ParameterType = ParamType;
        }

        public override bool Equals(object obj)
        {
            DataAnalyticsRestAPIParameter cmpObj = (DataAnalyticsRestAPIParameter)obj;
            return this.ParameterName.Equals(cmpObj.ParameterName, StringComparison.CurrentCultureIgnoreCase);
        }

        public override int GetHashCode()
        {
            return ParameterName.GetHashCode();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(50);
            sb.AppendLine(string.Format("Parameter Name:{0}", ParameterName));
            sb.AppendLine(string.Format("Parameter Value:{0}", ParameterValue));
            sb.AppendLine(string.Format("Parameter Type:{0}", ParameterType.ToString()));
            return sb.ToString();
        }
    }

    public enum DataAnlayticsRestAPIParameterType
    {
        URLSegmentParameter,
        URLParameter
    }
}
