﻿using RestSharp;
using RestSharp.Deserializers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public enum DataAnalyticsRestAPIProviderType
    {
        Generic = 1,
        Maropost = 2,
        TestProvider = 3
    }

    public class DataAnalyticsRestAPIProvider : IDataAnalyticsRestAPIProvider
    {
        public string APIUri { get; set; }

        internal string APIKey { get; set; }

        public DataAnalyticsRestAPIParameters Parameters { get; set; }

        public DataAnalyticsRestAPIResponse HttpGet(string ApiName)
        {
            DataAnalyticsRestAPIResponse RetAPIResponse = new DataAnalyticsRestAPIResponse();
            RetAPIResponse.Status = ResponseStatusType.Initialized;

            try
            {
                if (!IsValidUri())
                    throw new ArgumentException("Invalid API Uri provided.");

                var client = new RestClient(this.APIUri);
                var request = new RestRequest(Method.GET);
                
                if (!string.IsNullOrEmpty(APIKey))
                    request.AddParameter("auth_token", APIKey);

                AddParametersToRestClient(request, Parameters);
                var r = client.Execute(request);
                RetAPIResponse.ResponseXml = (r != null) ? r.Content : string.Empty;

                RetAPIResponse.Status = ResponseStatusType.Success;
            }
            catch(Exception ex)
            {
                RetAPIResponse.InnerException = ex;
                RetAPIResponse.Status = ResponseStatusType.Failure;
            }

            return RetAPIResponse;
        }

        public bool IsValidUri()
        {
            Uri uriResult;
            bool result = Uri.TryCreate(APIUri, UriKind.Absolute, out uriResult)
                && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
            return result;
        }

        internal static void AddParametersToRestClient(RestRequest Request, DataAnalyticsRestAPIParameters parameters)
        {
            foreach (DataAnalyticsRestAPIParameter p in parameters)
            {
                if (p.ParameterType == DataAnlayticsRestAPIParameterType.URLSegmentParameter)
                    Request.AddParameter(p.ParameterName, p.ParameterValue, ParameterType.UrlSegment);
                else
                    Request.AddParameter(p.ParameterName, p.ParameterValue);
            }
        }

        private DataAnalyticsRestAPIProvider()
        {
            Parameters = new DataAnalyticsRestAPIParameters();
        }

        internal DataAnalyticsRestAPIProvider(string Uri, string Key) : this()
        {
            APIUri = Uri;
            APIKey = Key;
        }

    }
}
