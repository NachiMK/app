﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class DataAnalyticsRestAPIParser
    {
        internal DataAnalyticsRestAPIParser()
        {
        }

        public static string ConvertXMLToString(XDocument xml, bool RemoveRootNode)
        {
            if (!RemoveRootNode)
                return xml.ToString();
            else
            {
                XElement firstChild = xml.Root.Elements().First();
                return firstChild.ToString();
            }
        }

        public static XDocument Convert2Xml(string XMLAsString)
        {
            throw new NotImplementedException();
        }

        public static JsonObject Convert2Json(string XMLAsString)
        {
            throw new NotImplementedException();
        }

        public static DataSet Convert2DataSet(string XMLAsString)
        {
            throw new NotImplementedException();
        }
    }
}
