﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public class DataAnalyticsRestAPIProviderFactory
    {
        internal static IDataAnalyticsRestAPIProvider _APIProvider { get; set; }

        public static IDataAnalyticsRestAPIProvider CreateNew(DataAnalyticsRestAPIProviderType providerType, string ApiUri, string ApiKey = null)
        {
            _APIProvider = null;
            switch(providerType)
            {
                case DataAnalyticsRestAPIProviderType.Generic:
                    _APIProvider = new DataAnalyticsRestAPIProvider(ApiUri, ApiKey);
                    break;
                case DataAnalyticsRestAPIProviderType.Maropost:
                    _APIProvider = new MaropostRestAPIProvider(ApiUri, ApiKey);
                    break;
                default:
                    throw new NotImplementedException();
            }
            return _APIProvider;
        }
    }
}
