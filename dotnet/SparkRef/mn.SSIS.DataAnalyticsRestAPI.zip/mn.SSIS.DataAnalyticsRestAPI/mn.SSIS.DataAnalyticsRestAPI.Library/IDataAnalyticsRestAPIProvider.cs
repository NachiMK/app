﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.DataAnalyticsRestAPI.Library
{
    public interface IDataAnalyticsRestAPIProvider
    {
        string APIUri { get; set; }

        DataAnalyticsRestAPIResponse HttpGet(string ApiName);

        DataAnalyticsRestAPIParameters Parameters {get; set;}

        bool IsValidUri();
    }

}
