﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using mn.SSIS.Common.XMLLibrary;
using System.Text;

namespace mn.SSIS.DataAnalyticsRestAPI.UnitTest
{
    [TestClass]
    public class UnitTestXMLHelper
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidMerge()
        {
            StringBuilder sb = new StringBuilder("<Test></Test>");
            XMLHelper.MergeXML(ref sb, "test");
        }

        [TestMethod]
        public void TestHasElements_EmptyString()
        {
            Assert.IsFalse(XMLHelper.HasElements(string.Empty));
        }

        [TestMethod]
        public void TestHasElements_InvalidXML()
        {
            Assert.IsFalse(XMLHelper.HasElements("Test"));
        }

        [TestMethod]
        public void TestHasElements_XMLwithNoElements()
        {
            Assert.IsFalse(XMLHelper.HasElements("<Test></Test>"));
        }
    }
}
