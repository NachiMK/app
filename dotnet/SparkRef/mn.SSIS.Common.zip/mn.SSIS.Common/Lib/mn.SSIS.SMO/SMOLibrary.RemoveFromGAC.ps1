#
# SMOLibrary.RemoveFromGAC.ps1
# Script to remove SMOLibrary Assembly from GAC

#Load System.EnterpriseServices assembly as it contain classes to handle GAC
[Reflection.Assembly]::LoadWithPartialName("System.EnterpriseServices")
 
#Create instance of Publish class which can handle GAC Installation and/or removal
[System.EnterpriseServices.Internal.Publish] $publish = new-object System.EnterpriseServices.Internal.Publish;

#Install mn.SSIS.Common.ExportToFileLibrary.dll into GAC using GacInstall method (Provide full path to the assembly) - Usually our assemblies are save in C:\Matchnet folder
#$publish.GacRemove("C:\Matchnet\mn.SSIS.Common\mn.SSIS.Common.SMOLibrary.dll");
$publish.GacRemove("mn.SSIS.Common.SMOLibrary.dll");

