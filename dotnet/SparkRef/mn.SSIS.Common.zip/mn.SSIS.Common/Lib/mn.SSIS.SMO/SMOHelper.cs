﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using mn.SSIS.Common;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Server;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer;
using System.Collections.Specialized;
using System.Data;


namespace mn.SSIS.Common.SMOLibrary
{
    public enum ScriptColumnFilterOption
    {
        None = 0,
        Include,
        Exclude
    }

    public enum CreateTableOption
    {
        /// <summary>
        /// Create if table doesnt exists
        /// </summary>
        CreateIfNotExists = 0,
        /// <summary>
        /// Drop and create table
        /// </summary>
        DropAndCreate = 1
    }

    public class SMOHelper
    {

        /// <summary>
        ///  Creates a table same as source table if table doesnt exists in target
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargertConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTable(SQLConnector SourceConnector, string SourceTableName, SQLConnector TargertConnector, string TargetTableName, out bool TableCreated)
        {
            return CreateTable(SourceConnector, SourceTableName, TargertConnector, TargetTableName, CreateTableOption.CreateIfNotExists, string.Empty, ScriptColumnFilterOption.None, out TableCreated);
        }

        /// <summary>
        /// Creates table based on source connection and table.
        /// All columns in source are created in Target.
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargertConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTable(SQLConnector SourceConnector, string SourceTableName, SQLConnector TargertConnector, string TargetTableName, CreateTableOption createTableOption, out bool TableCreated)
        {
            return CreateTable(SourceConnector, SourceTableName, TargertConnector, TargetTableName, createTableOption, string.Empty, ScriptColumnFilterOption.None, out TableCreated);
        }


        /// <summary>
        /// Creates a table based on source table in target.
        /// creates only if target doesn't exists.
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTable(SQLConnector SourceConnector
                                    , string SourceTableName
                                    , SQLConnector TargetConnector
                                    , string TargetTableName
                                    , string CommaSeparatedColumnNames
                                    , ScriptColumnFilterOption ColFilterOption
                                    , out bool TableCreated)
        {
            return CreateTable(SourceConnector, SourceTableName, TargetConnector, TargetTableName, CreateTableOption.CreateIfNotExists, CommaSeparatedColumnNames, ColFilterOption, out TableCreated);
        }

        /// <summary>
        /// Creates Table Target Table with given name but schema exactly same
        /// as Source Table. Columns based on names can be included or excluded.
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTable(SQLConnector SourceConnector
                                            , string SourceTableName
                                            , SQLConnector TargetConnector
                                            , string TargetTableName
                                            , CreateTableOption createTableOption
                                            , string CommaSeparatedColumnNames
                                            , ScriptColumnFilterOption ColFilterOption
                                            , out bool TableCreated)
        {
            DBAppLogList RetLogList = new DBAppLogList();
            TableCreated = false;

            try
            {
                // get Table
                Table smoTable = GetTable(SourceConnector, SourceTableName, TargetTableName, CommaSeparatedColumnNames, ColFilterOption);

                // Create Table in Target
                Table smoTargetTable = CreateTable(TargetConnector, smoTable, createTableOption, out TableCreated);
            }
            catch(Exception ex)
            {
                RetLogList.Add(new DBAppLog("Error Creating Table.", ex, DBLogTypeEnum.Error));
            }

            return RetLogList;
        }


        /// <summary>
        /// Creates table based on schema from a query. Table is created only if doesnt exists in target
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTableFromQuery(SQLConnector SourceConnector, SQLConnector TargetConnector, string TargetTableName, out bool TableCreated)
        {
            //delegate
            return CreateTableFromQuery(SourceConnector, TargetConnector, TargetTableName, CreateTableOption.CreateIfNotExists, string.Empty, ScriptColumnFilterOption.None, out TableCreated);
        }

        /// <summary>
        /// Creates a Table in Target based on query provided in Source Connector
        /// Table is created with all columns in query
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTableFromQuery(SQLConnector SourceConnector, SQLConnector TargetConnector, string TargetTableName, CreateTableOption createTableOption, out bool TableCreated)
        {
            //delegate
            return CreateTableFromQuery(SourceConnector, TargetConnector, TargetTableName, createTableOption, string.Empty, ScriptColumnFilterOption.None, out TableCreated);
        }

        /// <summary>
        /// Creates a Table based on a query.
        /// Table will be created only if it doesn't exists.
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTableFromQuery(SQLConnector SourceConnector
                                                        , SQLConnector TargetConnector
                                                        , string TargetTableName
                                                        , string CommaSeparatedColumnNames
                                                        , ScriptColumnFilterOption ColFilterOption
                                                        , out bool TableCreated)
        {
            //delegate
            return CreateTableFromQuery(SourceConnector, TargetConnector, TargetTableName, CreateTableOption.CreateIfNotExists, CommaSeparatedColumnNames, ColFilterOption, out TableCreated);
        }
        /// <summary>
        /// Creates a Table based on SQL Query provided in the SQL Connector object.
        /// 
        /// You can include/exclude certain columns.
        /// </summary>
        /// <param name="SourceConnector"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static DBAppLogList CreateTableFromQuery(SQLConnector SourceConnector
                                                        , SQLConnector TargetConnector
                                                        , string TargetTableName
                                                        , CreateTableOption createTableOption
                                                        , string CommaSeparatedColumnNames
                                                        , ScriptColumnFilterOption ColFilterOption
                                                        , out bool TableCreated)
        {
            DBAppLogList RetLogList = new DBAppLogList();
            Exception outEx = null;
            TableCreated = false;
            IList<string> strMsgList = null;
            DataTable dt = null;

            try
            {
                if ((SourceConnector != null) && (SourceConnector.IsValid(true, out strMsgList)))
                {
                    // get data table
                    dt = SourceConnector.ExecuteDataTable(out outEx);
                    if (outEx != null)
                        throw outEx;

                    if (dt != null)
                    {
                        // get Table
                        Table smoTable = GetTable(SourceConnector, dt, TargetTableName, CommaSeparatedColumnNames, ColFilterOption, out outEx);

                        // Create Table in Target
                        Table smoTargetTable = CreateTable(TargetConnector, smoTable, createTableOption, out TableCreated);
                    }
                    else
                    {
                        throw new Exception("Query didnt return Datatable. Check Source Connector:" + SourceConnector.ToString());
                    }

                }
                else
                {
                    throw new InvalidArgumentException(strMsgList.ToString());
                }
            }
            catch (Exception ex)
            {
                RetLogList.Add(new DBAppLog("Error Creating Table from Query.", ex, DBLogTypeEnum.Error));
            }

            return RetLogList;
        }

        /// <summary>
        /// Creates given Table in Target Connection
        /// </summary>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTable"></param>
        /// <param name="TableCreated"></param>
        /// <returns></returns>
        public static Table CreateTable(SQLConnector TargetConnector, Table TargetTable, CreateTableOption createTableOption, out bool TableCreated)
        {
            Table RetTable = null;
            TableCreated = false;
            string strMsg = string.Empty;

            try
            {
                // Valid connection
                if ((TargetConnector != null) && (TargetConnector.IsValidConnection(out strMsg)))
                {
                    // Valid Table
                    if ((TargetTable != null) && (TargetTable.Columns != null))
                    {
                        // get DB
                        Database TargetDB = GetDatabase(TargetConnector);
                        // valid db
                        if (TargetDB != null)
                        {
                            // new table
                            RetTable = new Table(TargetDB, TargetTable.Name);
                            // Loop through and create columns.
                            foreach(Column col in TargetTable.Columns)
                            {
                                Column newCol = new Column(RetTable, col.Name, col.DataType);
                                RetTable.Columns.Add(newCol);
                            }

                            // if new table has columns then create it
                            if ((RetTable != null) && (RetTable.Columns != null))
                            {
                                bool blnTableExists = TableExists(TargetConnector, TargetTable.Name);

                                // create the actual table
                                if (createTableOption == CreateTableOption.CreateIfNotExists)
                                {
                                    if (!blnTableExists)
                                    {
                                        RetTable.Create();

                                        // check if table exists
                                        TableCreated = TableExists(TargetConnector, TargetTable.Name);
                                    }
                                }
                                else if (createTableOption == CreateTableOption.DropAndCreate)
                                {
                                    // drop table
                                    if (blnTableExists)
                                        DropTable(TargetConnector, TargetTable.Name);

                                    // create file
                                    RetTable.Create();

                                    // check if table exists
                                    TableCreated = TableExists(TargetConnector, TargetTable.Name);
                                }
                                else
                                {
                                    throw new InvalidArgumentException("Invalid Create Table Option specified.");
                                }
                            }
                            else
                            {
                                throw new Exception("Error creating Target Table from provided table.");
                            }

                        }

                    }
                    else
                    {
                        strMsg = "Target SMO Table is NULL or Columns are missing. It is required.";
                        throw new InvalidArgumentException(strMsg);
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(strMsg))
                        strMsg = "Invalid Target Connector.";
                    throw new InvalidArgumentException(strMsg);
                }
            }
            catch(Exception ex)
            {
                TableCreated = false;
                throw ex;
            }

            //return
            if (!TableCreated)
                RetTable = null;

            return RetTable;
        }

        /// <summary>
        /// Returns script of table with drop statement.
        /// All columns in source table is returned. Target table name is set to same as source table.
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScript(SQLConnector sqlConnector, string SourceTableName, out string TableScript)
        {
            // return
            return GetTableScript(sqlConnector, SourceTableName, SourceTableName, string.Empty, ScriptColumnFilterOption.None, out TableScript);
        }

        /// <summary>
        /// Returns Table script with Target table name.
        /// All cols in source table is included.
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScript(SQLConnector sqlConnector, string SourceTableName, string TargetTableName, out string TableScript)
        {
            // return
            return GetTableScript(sqlConnector, SourceTableName, TargetTableName, string.Empty, ScriptColumnFilterOption.None, out TableScript);
        }

        /// <summary>
        /// Returns Table script based on Source Table.
        /// Target table name is set to same as Source table.
        /// Can exclude or include certain columns
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScript(SQLConnector sqlConnector
                                                , string SourceTableName
                                                , string CommaSeparatedColumnNames
                                                , ScriptColumnFilterOption ColFilterOption
                                                , out string TableScript)
        {
            // return
            return GetTableScript(sqlConnector, SourceTableName, SourceTableName, CommaSeparatedColumnNames, ColFilterOption, out TableScript);
        }
        
        
        /// <summary>
        /// Returns Table script based on source table.
        /// Table script will have Target table name as script.
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScript(SQLConnector sqlConnector
                                                    , string SourceTableName
                                                    , string TargetTableName
                                                    , string CommaSeparatedColumnNames
                                                    , ScriptColumnFilterOption ColFilterOption
                                                    , out string TableScript)
        {
            DBAppLogList objRetList = new DBAppLogList();
            TableScript = string.Empty;
            Table smoTargetTable = null;

            try
            {
                // Valid Table name
                if (string.IsNullOrEmpty(SourceTableName.Trim()))
                    throw new InvalidArgumentException("Source Table Name is required for scripting.");

                if ((ColFilterOption == ScriptColumnFilterOption.Include) && (string.IsNullOrEmpty(CommaSeparatedColumnNames.Trim())))
                    throw new InvalidArgumentException("Comma separated list of columns required for Including only specific columns in Table Script.");

                // get Source Table
                smoTargetTable = GetTable(sqlConnector, SourceTableName, TargetTableName, CommaSeparatedColumnNames, ColFilterOption);

                // Valid server
                if (smoTargetTable != null)
                {
                    // get script
                    TableScript = GetTableScript(smoTargetTable, true);
                }
                else
                {
                    objRetList.Add("Error getting Table:" + SourceTableName + " information from Server:" + sqlConnector.ToString());
                }

            }
            catch (Exception ex)
            {
                objRetList.Add(new DBAppLog("Error scripting.", ex, DBLogTypeEnum.Error));
                TableScript = string.Empty;
            }

            // return
            return objRetList;
        }


        /// <summary>
        /// Gets CREATE TABLE script based on query.
        /// All columns in query is included.
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SQLQuery"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScriptFromQuery(SQLConnector sqlConnector, string SQLQuery, string TargetTableName, out string TableScript)
        {
            // delegate call
            return GetTableScriptFromQuery(sqlConnector, SQLQuery, TargetTableName, string.Empty, ScriptColumnFilterOption.None, out TableScript);
        }


        /// <summary>
        /// Gets Create Table Script based on a query.
        /// You can exclude or include specific column
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SQLQuery"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableScript"></param>
        /// <returns></returns>
        public static DBAppLogList GetTableScriptFromQuery(SQLConnector sqlConnector
                                                            , string SQLQuery
                                                            , string TargetTableName
                                                            , string CommaSeparatedColumnNames
                                                            , ScriptColumnFilterOption ColFilterOption
                                                            , out string TableScript)
        {
            DBAppLogList RetList = new DBAppLogList();
            Exception outEx;
            TableScript = string.Empty;
            IList<string> strMsgList = null;

            try
            {
                // Valid Query
                if (string.IsNullOrEmpty(SQLQuery.Trim()))
                {
                    throw new InvalidArgumentException("SQL Query is required for scripting.");
                }

                // Valid connection
                // connect to server
                if ((sqlConnector != null) && (sqlConnector.IsValid(false, out strMsgList)))
                {
                    // Get Data table from Query
                    sqlConnector.SQLScript = SQLQuery;

                    // get data query
                    DataTable dt = sqlConnector.ExecuteDataTable(out outEx);
                    if (outEx != null)
                    {
                        throw outEx;
                    }

                    // Get Table
                    Table smoTargetTable = GetTable(sqlConnector, dt, TargetTableName, CommaSeparatedColumnNames, ColFilterOption, out outEx);
                    if (outEx != null)
                    {
                        throw outEx;
                    }
                    
                    // Get Script from DataTable
                    TableScript = GetTableScript(smoTargetTable, true);
                }
                else
                {
                    throw new InvalidArgumentException("SqlConnecter is null. Please pass in a valid connection");
                }

            }
            catch (Exception ex)
            {
                RetList.Add(new DBAppLog("Error in getting script from Query", ex, DBLogTypeEnum.Error));
                TableScript = string.Empty;
            }

            return RetList;
        }

        /// <summary>
        /// returns table script for given table.
        /// </summary>
        /// <param name="smoTable"></param>
        /// <param name="IncludeDrop"></param>
        /// <returns></returns>
        public static string GetTableScript(Table smoTable, bool IncludeDrop)
        {
            StringBuilder sb = new StringBuilder(256);
            StringCollection strCollection = null;

            if (smoTable != null)
            {
                // Set scripting options
                ScriptingOptions scriptOption = new ScriptingOptions();
                if (IncludeDrop)
                {
                    scriptOption.ScriptBatchTerminator = true;
                    scriptOption.IncludeIfNotExists = true;
                    scriptOption.ScriptDrops = true;

                    // Script table header and drop statement
                    strCollection = smoTable.Script(scriptOption);

                    // get string value
                    if (strCollection != null)
                    {
                        foreach (string str in strCollection)
                            sb.AppendLine(str);
                        sb.AppendLine("GO");
                    }
                }

                // scrip table
                strCollection = smoTable.Script();

                // get string value
                if (strCollection != null)
                {
                    foreach (string str in strCollection)
                        sb.AppendLine(str);
                    sb.AppendLine("GO");
                }
            }

            // return string
            return sb.ToString();
        }

        /// <summary>
        /// Gets SMO Server based on connection
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <returns></returns>
        public static Server GetServer(SQLConnector sqlConnector)
        {
            Server smoServer = null;

            // connect to server
            if (sqlConnector != null)
            {
                if (sqlConnector.UseIntegratedSecurity)
                    smoServer = new Server(sqlConnector.ServerName);
                else
                {
                    SqlConnectionInfo sqlConInfo = new SqlConnectionInfo(sqlConnector.ServerName, sqlConnector.UserName, sqlConnector.Password);
                    ServerConnection serverConn = new ServerConnection(sqlConInfo);
                    smoServer = new Server(serverConn);
                }
            }
            else
            {
                throw new InvalidArgumentException("SqlConnecter is null. Please pass in a valid connection");
            }
            // return server
            return smoServer;
        }

        /// <summary>
        /// Returns the Database for given server.
        /// </summary>
        /// <param name="sqlConnector">This should have both Server and database name in it.</param>
        /// <returns></returns>
        public static Database GetDatabase(SQLConnector sqlConnector)
        {
            Database db = null;

            try
            {
                // get server
                Server smoServer = GetServer(sqlConnector);

                // Valid server
                if (smoServer != null)
                {
                    // Valid database
                    if ((smoServer.Databases != null) && (smoServer.Databases.Contains(sqlConnector.DatabaseName) == true))
                    {
                        db = smoServer.Databases[sqlConnector.DatabaseName];
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // return db
            return db;
        }

        /// <summary>
        /// Returns the database table from Server.Database
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="TableName"></param>
        /// <returns></returns>
        public static Table GetTable(SQLConnector sqlConnector, string TableName)
        {
            Table table = null;

            if (string.IsNullOrEmpty(TableName.Trim()))
                throw new InvalidArgumentException("Table Name is required.");

            try
            {
                // get db
                Database db = GetDatabase(sqlConnector);

                // find table
                if (db != null)
                { 
                    if ((db.Tables != null) && (db.Tables.Contains(TableName)))
                    {
                        table = db.Tables[TableName];
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return table;
        }

        /// <summary>
        /// Returns whether a table exists in given SQL connection
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="TableName"></param>
        /// <returns></returns>
        public static bool TableExists(SQLConnector sqlConnector, string TableName)
        {
            bool blnRetVal = false;
            if (string.IsNullOrEmpty(TableName.Trim()))
                throw new InvalidArgumentException("Table Name is required.");

            try
            {
                // get db
                Database db = GetDatabase(sqlConnector);

                // find table
                if (db != null)
                {
                    if (db.Tables != null)
                        blnRetVal = db.Tables.Contains(TableName);
                }
                else
                {
                    throw new InvalidArgumentException("Database/Server doesn't exists." + sqlConnector.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blnRetVal;
        }


        /// <summary>
        /// Drop given table if exists
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="TableName"></param>
        /// <returns>Returns whether table was dropped or not.</returns>
        public static bool DropTable(SQLConnector sqlConnector, string TableName)
        {
            bool blnRetVal = false;
            bool blnTableExists = false;
            if (string.IsNullOrEmpty(TableName.Trim()))
                throw new InvalidArgumentException("Table Name is required.");

            try
            {
                // get db
                Database db = GetDatabase(sqlConnector);

                // find table
                if (db != null)
                {
                    if (db.Tables != null)
                        blnTableExists = db.Tables.Contains(TableName);

                    // if table exists then delete it
                    if (blnTableExists)
                    {
                        // drop table
                        db.Tables[TableName].Drop();
                        blnRetVal = true;
                    }
                    else
                    {
                        blnRetVal = blnTableExists;
                    }
                }
                else
                {
                    throw new InvalidArgumentException("Database/Server doesn't exists." + sqlConnector.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return blnRetVal;
        }


        /// <summary>
        /// Gets a Table based on source table, optionally filters out columns
        /// or includes only given columns
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetTableName">Target table name.</param>
        /// <param name="CommaSeparatedColumnNames">Columns to be included or excluded in target</param>
        /// <param name="ColFilterOption"></param>
        /// <returns></returns>
        public static Table GetTable(SQLConnector sqlConnector
                                    ,string SourceTableName
                                    ,string TargetTableName
                                    ,string CommaSeparatedColumnNames
                                    ,ScriptColumnFilterOption ColFilterOption)
        {
            Table smoTable = null;
            Table smoTargetTable = null;

            try
            {
                // Valid Table name
                if (string.IsNullOrEmpty(SourceTableName.Trim()))
                    throw new InvalidArgumentException("Source Table Name is required for scripting.");

                // valid target table
                if (string.IsNullOrEmpty(TargetTableName.Trim()))
                    throw new InvalidArgumentException("Target Table Name is required for scripting.");

                // valid filters
                if ((ColFilterOption == ScriptColumnFilterOption.Include) && (string.IsNullOrEmpty(CommaSeparatedColumnNames.Trim())))
                    throw new InvalidArgumentException("Comma separated list of columns required for Including only specific columns in Table Script.");

                // get Source Table
                smoTable = GetTable(sqlConnector, SourceTableName);

                // Valid server
                if (smoTable != null)
                {
                    // get list of strings.
                    char[] charSep = new char[] { ',' };
                    string[] strCols = CommaSeparatedColumnNames.Split(charSep, StringSplitOptions.RemoveEmptyEntries);

                    // create new table
                    Database smoTargetDB = GetDatabase(sqlConnector);
                    smoTargetTable = new Table(smoTargetDB, TargetTableName);

                    if (ColFilterOption != ScriptColumnFilterOption.None)
                    {
                        if (ColFilterOption == ScriptColumnFilterOption.Include)
                        {
                            // add column only if doesnt exists in given list
                            foreach (Column col in smoTable.Columns)
                            {
                                // check if it exists in the include list then add it
                                //if (Array.Exists<string>(strCols, element => element == col.Name))
                                if (strCols.Contains<string>(col.Name, StringComparer.CurrentCultureIgnoreCase))
                                {
                                    Column smoCol = new Column(smoTargetTable, col.Name, col.DataType);
                                    smoTargetTable.Columns.Add(smoCol);
                                }
                            }
                        }
                        else
                        {
                            // add column only if doesnt exists in given list
                            foreach (Column col in smoTable.Columns)
                            {
                                // check if it exists in the exclude list, if so skip
                                if (!strCols.Contains<string>(col.Name, StringComparer.CurrentCultureIgnoreCase))
                                {
                                    Column smoCol = new Column(smoTargetTable, col.Name, col.DataType);
                                    smoTargetTable.Columns.Add(smoCol);
                                }
                            }
                        }
                    }
                    else
                    {
                        // add column only if doesnt exists in given list
                        foreach (Column col in smoTable.Columns)
                        {
                            Column smoCol = new Column(smoTargetTable, col.Name, col.DataType);
                            smoTargetTable.Columns.Add(smoCol);
                        }
                    }
                }
                else
                {
                    throw new InvalidArgumentException("Error getting Table:" + SourceTableName + " information from Server:" + sqlConnector.ToString());
                }

            }
            catch (Exception ex)
            {
                smoTargetTable = null;
                throw ex;
            }

            return smoTargetTable;
        }


        /// <summary>
        /// Returns Table based on DataTable.
        /// All columns are included
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="DataTableToScript"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="outEx"></param>
        /// <returns></returns>
        public static Table GetTable(SQLConnector sqlConnector
                                    ,DataTable DataTableToScript
                                    ,string TargetTableName
                                    ,out Exception outEx)
        {
            // delegate call
            return GetTable(sqlConnector, DataTableToScript, TargetTableName, string.Empty, ScriptColumnFilterOption.None, out outEx);
        }

        /// <summary>
        /// Returns a DB Table based on DataTable
        /// Can include/exclude specific columns in Target table.
        /// </summary>
        /// <param name="sqlConnector"></param>
        /// <param name="DataTableToScript"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="CommaSeparatedColumnNames"></param>
        /// <param name="ColFilterOption"></param>
        /// <param name="outEx"></param>
        /// <returns></returns>
        public static Table GetTable(SQLConnector sqlConnector
                                        , DataTable DataTableToScript
                                        , string TargetTableName
                                        , string CommaSeparatedColumnNames
                                        , ScriptColumnFilterOption ColFilterOption
                                        , out Exception outEx)
        {
            string strTableScript = string.Empty;
            Column tempC = null;
            outEx = null;
            Table TempTable = null;
            bool blnAddColumn = false;
            string[] strCols = null;

            try
            {
                // Valid Target table name
                if (string.IsNullOrEmpty(TargetTableName.Trim()))
                    throw new InvalidArgumentException("Target Table name is required.");

                // valid target table
                if (DataTableToScript == null)
                    throw new InvalidArgumentException("No DataTable to script. A Valid Data Table is required to script.");

                // valid filters
                if ((ColFilterOption == ScriptColumnFilterOption.Include) && (string.IsNullOrEmpty(CommaSeparatedColumnNames.Trim())))
                    throw new InvalidArgumentException("Comma separated list of columns required for Including only specific columns in Table Script.");

                //Create a new SMO table
                Database smoTargetDB = GetDatabase(sqlConnector);
                TempTable = new Table(smoTargetDB, TargetTableName);

                // add or remove column based on list
                if (ColFilterOption != ScriptColumnFilterOption.None)
                {
                    // get list of strings.
                    char[] charSep = new char[] { ',' };
                    strCols = CommaSeparatedColumnNames.Split(charSep, StringSplitOptions.RemoveEmptyEntries);
                }

                //Add the column names and types from the datatable into the new table
                //Using the columns name and type property
                foreach (DataColumn dc in DataTableToScript.Columns)
                {
                    // initialize
                    blnAddColumn = false;
                    
                    // add or remove column based on list
                    if (ColFilterOption != ScriptColumnFilterOption.None)
                    {
                        // If include and column exists in array then add column
                        if (ColFilterOption == ScriptColumnFilterOption.Include)
                        {
                            blnAddColumn = strCols.Contains<string>(dc.ColumnName, StringComparer.CurrentCultureIgnoreCase);
                        }
                        // if exclude and column exists in array then don't add column
                        else
                        {
                            blnAddColumn = (!strCols.Contains<string>(dc.ColumnName, StringComparer.CurrentCultureIgnoreCase));
                        }
                    }
                    else
                    {
                        // if NONE then add column
                        blnAddColumn = true;
                    }

                    //Create columns from datatable column schema
                    if (blnAddColumn)
                    {
                        tempC = new Column(TempTable, dc.ColumnName);
                        tempC.DataType = GetDataType(dc);
                        
                        // add column
                        TempTable.Columns.Add(tempC);
                    }
                }
            }
            catch(Exception ex)
            {
                outEx = ex;
                TempTable = null;
            }

            return TempTable;
        }

        /// <summary>
        /// returns SQL Data Type for given System Type based on DataColumn
        /// </summary>
        /// <param name="dataColumn"></param>
        /// <returns></returns>
        private static DataType GetDataType(DataColumn dataColumn)
        {
            string dataType = dataColumn.DataType.ToString();
            int intMaxLen = -1;
            if (dataType.CompareTo("System.String") == 0)
            {
                if ((dataColumn.MaxLength > 0) && (dataColumn.MaxLength < 4000))
                    intMaxLen = dataColumn.MaxLength;
            }

            DataType DTTemp = null;

            switch (dataType)
            {
                case ("System.Decimal"):
                    DTTemp = DataType.Decimal(2, 18);
                    break;
                case ("System.String"):
                    DTTemp = DataType.NVarChar(intMaxLen);
                    break;
                case ("System.Int16"):
                    DTTemp = DataType.SmallInt;
                    break;
                case ("System.Int32"):
                    DTTemp = DataType.Int;
                    break;
                case("System.Int64"):
                    DTTemp = DataType.BigInt;
                    break;
                case("System.DateTime"):
                    DTTemp = DataType.DateTime;
                    break;
                case("System.Boolean"):
                    DTTemp = DataType.Bit;
                    break;
                case("System.Single"):
                    DTTemp = DataType.Float;
                    break;
                case ("System.Double"):
                    DTTemp = DataType.Float;
                    break;
                case ("System.Byte"):
                    DTTemp = DataType.TinyInt;
                    break;
                case ("System.Char"):
                    DTTemp = DataType.Char(dataColumn.MaxLength);
                    break;
                case ("System.Guid"):
                    DTTemp = DataType.UniqueIdentifier;
                    break;
                default:
                    DTTemp = DataType.NVarChar(-1);
                    break;

            }
            return DTTemp;
        }

    }
}
