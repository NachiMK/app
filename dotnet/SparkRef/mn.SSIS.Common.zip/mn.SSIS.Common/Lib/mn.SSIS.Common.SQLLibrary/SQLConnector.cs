﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace mn.SSIS.Common.SQLLibrary
{
    public class SQLConnector
    {
        #region static Constructors

        public static SQLConnector NewSQLConnector(string TheServerName, string TheDBName, string TheScript, string TheUserName, string ThePassword, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            SQLConnector RetSQLConnector = new SQLConnector(TheServerName, TheDBName, TheScript, TheUserName, ThePassword);

            if (!RetSQLConnector.IsValid(true, out TheValidationMessages))
                RetSQLConnector = null;

            return RetSQLConnector;
        }

        /// <summary>
        /// Overloaded method to create a new Export To File object using Integrated Security
        /// </summary>
        /// <param name="TheServerName"></param>
        /// <param name="TheDBName"></param>
        /// <param name="TheScript"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static SQLConnector NewSQLConnector(string TheServerName, string TheDBName, string TheScript, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            SQLConnector RetSQLConnector = new SQLConnector(TheServerName, TheDBName, TheScript);

            if (!RetSQLConnector.IsValid(true, out TheValidationMessages))
                RetSQLConnector = null;

            return RetSQLConnector;
        }

        /// <summary>
        /// Create a sQL Connector without a Script. This is generally used for testing connection
        /// </summary>
        /// <param name="TheServerName"></param>
        /// <param name="TheDBName"></param>
        /// <param name="TheScript"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static SQLConnector NewSQLConnector(string TheServerName, string TheDBName, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            SQLConnector RetSQLConnector = new SQLConnector(TheServerName, TheDBName, string.Empty);

            if (!RetSQLConnector.IsValid(false, out TheValidationMessages))
                RetSQLConnector = null;

            return RetSQLConnector;
        }

        /// <summary>
        /// Creates a SQL connector without script but with user name and password instead of integrated security
        /// </summary>
        /// <param name="TheServerName">DB Server Name</param>
        /// <param name="TheDBName"></param>
        /// <param name="TheUserName"></param>
        /// <param name="ThePassword"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static SQLConnector NewSQLConnector(string TheServerName, string TheDBName, string TheUserName, string ThePassword, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            SQLConnector RetSQLConnector = new SQLConnector(TheServerName, TheDBName, string.Empty, TheUserName, ThePassword);

            if (!RetSQLConnector.IsValid(false, out TheValidationMessages))
                RetSQLConnector = null;

            return RetSQLConnector;
        }

        #endregion

        #region private Fields

        private string _ServerName;
        private string _DatabaseName;
        private string _UserName;
        private string _Password;
        private bool _IntegratedSecurity;
        private string _SQLScript;


        #endregion

        #region public properties

        public string ServerName
        {
            get
            {
                return _ServerName;
            }
            set
            {
                _ServerName = value;
            }
        }

        public string DatabaseName
        {
            get
            {
                return this._DatabaseName;
            }
            set
            {
                _DatabaseName = value;
            }
        }

        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }

        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        public bool UseIntegratedSecurity
        {
            get
            {
                return this._IntegratedSecurity;
            }
            set
            {
                _IntegratedSecurity = value;
            }
        }

        public string SQLScript
        {
            get
            {
                return _SQLScript;
            }
            set
            {
                _SQLScript = value;
            }
        }

        #endregion

        #region private constructors
        internal SQLConnector()
        {
            this.ServerName = string.Empty;
            this.DatabaseName = string.Empty;
            this.UserName = string.Empty;
            this.Password = string.Empty;
            this.SQLScript = string.Empty;
        }

        internal SQLConnector(string TheServerName, string TheDBName, string TheScript, string TheUserName, string ThePassword)
        {
            this.ServerName = TheServerName;
            this.DatabaseName = TheDBName;
            this.SQLScript = TheScript;
            this.UserName = TheUserName;
            this.Password = ThePassword;
            this.UseIntegratedSecurity = false;
        }

        internal SQLConnector(string TheServerName, string TheDBName, string TheScript)
        {
            this.ServerName = TheServerName;
            this.DatabaseName = TheDBName;
            this.SQLScript = TheScript;
            this.UseIntegratedSecurity = true;
            this.UserName = string.Empty;
            this.Password = string.Empty;
        }

        #endregion

        #region Private Functions

        private bool IsValid(bool SQLScriptRequired)
        {
            bool RetVal = false;
            IList<string> ValidationMessageList = null;
            RetVal = IsValid(SQLScriptRequired, out ValidationMessageList);
            return RetVal;
        }

        #endregion

        #region Internal Functions

        /// <summary>
        /// This returns a Data Reader. Be Cautions, this leaves
        /// the SQL Connection open till the client consumes the
        /// data reader. So try not to pass it back to any
        /// UI layer.
        /// </summary>
        /// <param name="OutputEx"></param>
        /// <returns></returns>
        internal SqlDataReader ExecuteDataReader(out Exception OutputEx)
        {
            SqlDataReader RetSqlDr = null;
            OutputEx = null;

            if (this.IsValid(true))
            {
                try
                {
                    string connString = this.ConnectionString;

                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        SqlCommand cmd = conn.CreateCommand();
                        cmd.CommandText = this.SQLScript;
                        conn.Open();
                        // NOTE CONNECTION IS OPEN --- YUCK
                        RetSqlDr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    }

                }
                catch (Exception ex)
                {
                    OutputEx = ex;
                }
            }
            else
            {
                OutputEx = new ArgumentException("Invalid SQL Connection Information provided");
            }

            return RetSqlDr;
        }

        /// <summary>
        /// Returns connection string based on values
        /// provided during creation of object.
        /// </summary>
        public string ConnectionString
        {
            get
            {
                SqlConnectionStringBuilder sqlConnBuilder = new SqlConnectionStringBuilder();
                sqlConnBuilder.DataSource = this.ServerName;
                sqlConnBuilder.InitialCatalog = this.DatabaseName;

                if (this.UseIntegratedSecurity)
                    sqlConnBuilder.IntegratedSecurity = true;
                else
                {
                    sqlConnBuilder.UserID = this.UserName;
                    sqlConnBuilder.Password = this.Password;
                }

                return sqlConnBuilder.ConnectionString;
            }
        }

        #endregion

        #region public functions


        /// <summary>
        /// Returns True if all values provided pass
        /// basic validation.
        /// 
        /// A Valid object doesn't mean an active SQL connection can be made.
        /// 
        /// Use TestConnection method to make sure the connection works.
        /// </summary>
        /// <param name="ValidationMessageList"></param>
        /// <returns></returns>
        public bool IsValid(bool ScriptRequired, out IList<string> ValidationMessageList)
        {
            bool RetVal = false;
            ValidationMessageList = new List<string>(20);

            if (this.ServerName.Length == 0)
                ValidationMessageList.Add("Server Name is required. Please enter a Valid Server Name.");
            if (this.DatabaseName.Length == 0)
                ValidationMessageList.Add("Database Name is required. Please enter a Valid Database Name.");
            if ((this.UserName.Length == 0) && (!this.UseIntegratedSecurity))
                ValidationMessageList.Add("User Name is required. Please enter a valid User name.");
            if ((this.Password.Length == 0) && (!this.UseIntegratedSecurity))
                ValidationMessageList.Add("Password is required. Please enter a valid Password.");
            if ((ScriptRequired) && (string.IsNullOrEmpty(this.SQLScript)))
                ValidationMessageList.Add("SQL Script is required. Please enter a valid SQL Script.");

            RetVal = ((ValidationMessageList != null) && (ValidationMessageList.Count == 0)) ? true : false;

            return RetVal;
        }

        /// <summary>
        /// Returns True if given connection string is valid
        /// connection.
        /// </summary>
        /// <param name="OutputMsg"></param>
        /// <returns></returns>
        public bool IsValidConnection(out string OutputMsg)
        {
            bool RetVal = false;
            OutputMsg = string.Empty;

            if (!this.IsValid(false))
            {
                OutputMsg = "ConnectionString Information is not complete. Please provide all Connection details.";
                return RetVal;
            }

            if (this.ConnectionString.Length > 0)
            {
                try
                {
                    string connString = this.ConnectionString;
                    // open a connection to test.
                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        conn.Open();
                        // valid connection.
                        if (conn.State == ConnectionState.Open)
                            RetVal = true;
                        else
                            OutputMsg = "Found Server. But, Connection state not open. Check DB.";
                    }
                }
                catch (SqlException sqlEx)
                {
                    OutputMsg = "Test Connection Failed!! with SQL Ex:" + System.Environment.NewLine + sqlEx.Message;
                }
                catch (Exception ex)
                {
                    OutputMsg = "Test Connection Failed!! with unknown Exception:" + System.Environment.NewLine + ex.Message;
                }
            }
            else
            {
                OutputMsg = "Connection string is not valid.";
            }

            RetVal = (OutputMsg.Length == 0) ? true : false;

            return RetVal;
        }


        /// <summary>
        /// Returns all results based on SQL query provided.
        /// 
        /// If there are any errors then it is returned in the OutputEx variable.
        /// 
        /// If Connection string is not valid then a default ArgumentException is returned.
        /// </summary>
        /// <param name="OutputEx"></param>
        /// <returns></returns>
        public DataTable ExecuteDataTable(out Exception OutputEx)
        {
            DataTable RetDataTable = null;
            OutputEx = null;

            if (this.IsValid(true))
            {
                try
                {
                    string connString = this.ConnectionString;

                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        SqlCommand cmd = conn.CreateCommand();
                        cmd.CommandText = this.SQLScript;
                        conn.Open();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        RetDataTable = new DataTable("ExportToFileResultSet");
                        sda.Fill(RetDataTable);
                    }
                }
                catch (Exception ex)
                {
                    OutputEx = ex;
                    RetDataTable = null;
                }
            }
            else
            {
                OutputEx = new ArgumentException("Invalid SQL Connection Information provided." + this.ToString());
            }
            return RetDataTable;
        }

        #endregion

        #region Override methods

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(250);

            sb.AppendLine("SQL Connector..");
            sb.AppendLine(string.Format("ServerName:{0}", this.ServerName));
            sb.AppendLine(string.Format("DatabaseName:{0}", this.DatabaseName));
            sb.AppendLine(string.Format("UseIntegratedSecurity:{0}", this.UseIntegratedSecurity));
            sb.AppendLine(string.Format("UserName:{0}", this.UserName));
            sb.AppendLine(string.Format("Password:{0}", this.Password));
            sb.AppendLine("----- ------SCRIPT ------- -----");
            sb.AppendLine(this.SQLScript);
            sb.AppendLine("----- ------SCRIPT ------- -----");
            return sb.ToString();
        }

        #endregion
    }
}
