﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.IO;
using System.IO.Compression;
using System.Data;

namespace mn.SSIS.Common.FTPLibrary
{
    public partial class SystemHelper
    {
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString FormatDate(SqlDateTime dtDate, SqlString formatString)
        {
            Int16 errSeverity = 16;
            SqlString retDate = "";

            try
            {
                DateTime sourceDate = dtDate.Value;
                retDate = new SqlString(sourceDate.ToString(formatString.ToString()));
            }
            catch (Exception ex)
            {
                // Connect to server in event of error
                SqlConnection conn = new SqlConnection("context connection=true");
                conn.Open();

                // Generate error response to SQL Server
                string msg = string.Format("RAISERROR('{0}',{1},1)", ex.Message.Replace('\'', ' '), errSeverity);
                SqlCommand cmd = new SqlCommand(msg, conn);

                try
                {
                    // Execute error on SQL Server
                    SqlPipe sqlpipe = SqlContext.Pipe;
                    sqlpipe.ExecuteAndSend(cmd);
                    Exception newEx = new Exception(msg);
                    throw newEx;
                }
                catch { } // Prevent error duplication
            }

            return retDate;
        }

        public static void ThrowErrorToSql(string exMsg, int errSeverity)
        {
            /*
            SqlConnection conn = new SqlConnection("context connection=true");
            conn.Open();

            string msg = string.Format("RAISERROR('{0}',{1},1)", exMsg.Replace('\'', ' '), errSeverity);
            SqlCommand cmd = new SqlCommand(msg, conn);

            try
            {
                SqlPipe sqlpipe = SqlContext.Pipe;
                sqlpipe.ExecuteAndSend(cmd);
            }
            catch { }
             * /
             */

            throw new Exception(exMsg);
        }

    }
}
