﻿using System;
using System.Collections.Generic;
using System.Text;
using Renci.SshNet;
using System.Collections;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using System.Data;
using System.IO;

namespace mn.SSIS.Common.FTPLibrary
{
    public partial class SFTPClient
    {
        public static bool CheckValidInput(string UserId, string Pwd, string Host, string Port
            , string FTPFolder
            , string Protocol
            )
        {
            string strMsg = "";
            bool blnRetval = CheckValidInput(UserId, Pwd, Host, Port, FTPFolder, Protocol, string.Empty, false, out strMsg);
            return blnRetval;
        }

            public static bool CheckValidInput(string UserId, string Pwd, string Host, string Port
                , string FTPFolder, string Protocol
                , string FileToExport, bool CheckFileName
                , out string ValidationMessage)
        {
            bool blnRetval = false;
            string strMsg = "";

            string strFileName = FileToExport;
            string strHostName = Host;
            int intPort;

            if (strHostName.Length == 0)
                strMsg = "Please enter valid FTP Host name!";
            else if (string.IsNullOrEmpty(Protocol))
                strMsg = "Please select a FTP Protocol!";
            else if (string.IsNullOrEmpty(UserId))
                strMsg = "Please enter a valid Username!";
            else if (string.IsNullOrEmpty(Pwd))
                strMsg = "Please enter a valid Password!";
            else if ((CheckFileName == true) && (strFileName.Length == 0))
                strMsg = "Please enter valid File to Upload!";
            else if (!string.IsNullOrEmpty(Port))
            {
                // should be a number
                if (!int.TryParse(Port, out intPort))
                    strMsg = "Port Number should be only integers.";
            }

            blnRetval = (strMsg.Length == 0) ? true : false;
            ValidationMessage = strMsg;

            return blnRetval;
        }

        public static bool FileExistsInHost(string UserId, string Pwd, string Host, string Port
            , string FTPFolder
            , string Protocol
            , string FileToExport
            , out DBAppLogList Log)
        {
            bool blnRetVal = false;
            Log = new DBAppLogList();
            bool blnValid = CheckValidInput(UserId, Pwd, Host, Port, FTPFolder, Protocol);
            if (blnValid)
            {
                try
                {
                    if (Protocol == "FTP")
                    {
                        FTPclient ftpClient = new FTPclient(Host, UserId, Pwd);
                        List<string> strDirectoryList = ftpClient.ListDirectory(FTPFolder);
                        if (strDirectoryList.Exists(file => file.Equals(FileToExport, StringComparison.CurrentCultureIgnoreCase)))
                        {
                            Log.Add("File:" + FileToExport + " exists in SFTP folder");
                            blnRetVal = true;
                        }
                    }
                    else if (Protocol == "SFTP")
                    {
                        int intPort = 22;
                        int.TryParse(Port, out intPort);
                        DataTable dt = SFTPClient.ListFiles(UserId, Pwd, Host, intPort, FTPFolder);
                        if (dt != null)
                        {
                            foreach (DataRow dr in dt.Rows)
                            {
                                string strFileName = dr["FileName"].ToString();
                                strFileName = System.IO.Path.GetFileName(strFileName);

                                if (strFileName.Equals(FileToExport, StringComparison.CurrentCultureIgnoreCase))
                                {
                                    Log.Add("File:" + FileToExport + " exists in SFTP folder");
                                    blnRetVal = true;
                                    break;
                                }
                            }

                            if (!blnRetVal)
                                Log.Add("File:" + FileToExport + " doesnt exists in FTP folder");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Add("Error in Finding file." + ex.Message);    
                }

            }

            return blnRetVal;
        }


        /// <summary>
        /// lists files in given directory
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="Pwd"></param>
        /// <param name="Host"></param>
        /// <param name="Port"></param>
        /// <param name="FTPFolder"></param>
        /// <returns></returns>
        public static DataTable ListFiles(string UserId, string Pwd, string Host, int Port, string FTPFolder)
        {
            DataTable retVal = null;

            retVal = new DataTable("Files");
            retVal.Columns.Add("FileName", typeof(string));
            retVal.Columns.Add("FileSize", typeof(long));
            retVal.Columns.Add("CreateDate", typeof(DateTime));
            retVal.Columns.Add("IsDirectory", typeof(bool));

            try
            {
                using (var sftp = new SftpClient(Host, Port, UserId, Pwd))
                {
                    // connect
                    sftp.Connect();
                    // list files
                    var files = sftp.ListDirectory(FTPFolder);
                    foreach (var file in files)
                    {
                        // get attributes
                        Renci.SshNet.Sftp.SftpFileAttributes sftatt = file.Attributes;
                        // add a row
                        retVal.Rows.Add(file.Name, sftatt.Size, file.LastWriteTime, file.IsDirectory);

                    }
                    // disconnect
                    sftp.Disconnect();
                }
            }
            catch (Exception ex)
            {
                retVal = null;
                throw ex;
            }
            return retVal;
        }

        /// <summary>
        /// Returns True if connection succeeded
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="Pwd"></param>
        /// <param name="Host"></param>
        /// <param name="Port"></param>
        /// <param name="FTPFolder"></param>
        /// <returns></returns>
        public static bool TestConnection(string UserId, string Pwd, string Host, int Port, string FTPFolder)
        {
            bool retVal = false;

            try
            {
                // get object
                using (var sftp = new SftpClient(Host, Port, UserId, Pwd))
                {
                    // connect
                    sftp.Connect();
                    // connect
                    retVal = sftp.IsConnected;
                    // disconnect
                    sftp.Disconnect();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return retVal;
        }


        /// <summary>
        ///  Uploads a given file and returns true if successfully uploaded.
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="Pwd"></param>
        /// <param name="Host"></param>
        /// <param name="Port"></param>
        /// <param name="FTPFolder"></param>
        /// <param name="sourceFilePath"></param>
        /// <param name="overwrite"></param>
        /// <returns></returns>
        public static bool UploadFile(string UserId, string Pwd, string Host, int Port, string FTPFolder, string sourceFilePath, bool overwrite)
        {
            bool retVal = false;

            try
            {
                using (var sftp = new SftpClient(Host, Port, UserId, Pwd))
                {
                    // onnect
                    sftp.Connect();

                    // change to directory
                    if (FTPFolder.Length > 0)
                        sftp.ChangeDirectory(FTPFolder);

                    // open stream to upload
                    using (Stream destFile = File.OpenRead(sourceFilePath))
                    {
                        sftp.UploadFile(destFile, Path.GetFileName(sourceFilePath), overwrite);
                        destFile.Close();
                    }

                    // check if file exists after upload
                    if (sftp.Exists(Path.GetFileName(sourceFilePath)))
                        retVal = true;

                    sftp.Disconnect();

                }
            }
            catch (Exception ex)
            {
                retVal = false;
                throw ex;
            }

            return retVal;
        }

        /// <summary>
        /// downloads a give file
        /// </summary>
        /// <param name="UserId"></param>
        /// <param name="Pwd"></param>
        /// <param name="Host"></param>
        /// <param name="Port"></param>
        /// <param name="SFTPFolder"></param>
        /// <param name="SFTPFileName"></param>
        /// <param name="destinationFilePath"></param>
        /// <param name="delete"></param>
        /// <returns></returns>
        public static int SFTPDownloadFile(string UserId, string Pwd, string Host, int Port, string SFTPFolder, string SFTPFileName, string destinationFilePath, bool delete)
        {
            int retVal = -1;

            try
            {
                if (File.Exists(destinationFilePath))
                    throw new Exception("Destination file exists!");

                using (var sftp = new SftpClient(Host, Port, UserId, Pwd))
                {
                    sftp.Connect();
                    if (SFTPFolder.Length > 0)
                        sftp.ChangeDirectory(SFTPFolder);

                    using (Stream destFile = File.Create(destinationFilePath))
                    {
                        sftp.DownloadFile(SFTPFileName, destFile);
                        destFile.Close();
                    }

                    if (delete)
                        sftp.DeleteFile(SFTPFileName);

                    sftp.Disconnect();
                    retVal = 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return retVal;
        }

        [Microsoft.SqlServer.Server.SqlProcedure]
        public static SqlInt32 SFTPListFiles(SqlString _SFTPUserId, SqlString _SFTPUserPsw, SqlString _SFTPServer, SqlInt32 _SFTPPort, SqlString _SFTPFolder)
        {
            SqlInt32 retVal = -1;
            SqlPipe pipe = SqlContext.Pipe;
            SqlMetaData[] cols = new SqlMetaData[4];
            cols[0] = new SqlMetaData("FileName", SqlDbType.NVarChar, 260);
            cols[1] = new SqlMetaData("FileSize", SqlDbType.BigInt);
            cols[2] = new SqlMetaData("CreateDate", SqlDbType.DateTime);
            cols[3] = new SqlMetaData("IsDirectory", SqlDbType.Bit);

            try
            {
                using (var sftp = new SftpClient(_SFTPServer.Value, _SFTPPort.Value, _SFTPUserId.Value, _SFTPUserPsw.Value))
                {
                    sftp.Connect();
                    var files = sftp.ListDirectory(_SFTPFolder.Value);

                    SqlDataRecord rec = new SqlDataRecord(cols);
                    pipe.SendResultsStart(rec);
                    foreach (var file in files)
                    {
                        Renci.SshNet.Sftp.SftpFileAttributes sftatt = file.Attributes;
                        
                        rec.SetSqlString(0, new SqlString(file.Name));
                        rec.SetInt64(1, sftatt.Size);
                        rec.SetDateTime(2, file.LastWriteTime);
                        rec.SetBoolean(3, file.IsDirectory);

                        pipe.SendResultsRow(rec);
                    }
                    pipe.SendResultsEnd();

                    sftp.Disconnect();
                    retVal = 0;
                }
            }
            catch (Exception ex)
            {
                SystemHelper.ThrowErrorToSql(ex.Message, 16);
            }

            return retVal;
        }

        [Microsoft.SqlServer.Server.SqlProcedure]
        public static SqlInt32 SFTPDownloadFile(SqlString _SFTPUserId, SqlString _SFTPUserPsw, SqlString _SFTPServer, SqlInt32 _SFTPPort, SqlString _SFTPFolder, SqlString _SFTPFileName, SqlString _destinationFilePath, SqlBoolean _delete)
        {
            SqlInt32 retVal = -1;

            try
            {
                if (File.Exists(_destinationFilePath.Value))
                    throw new Exception("Destination file exists!");

                using (var sftp = new SftpClient(_SFTPServer.Value, _SFTPPort.Value, _SFTPUserId.Value, _SFTPUserPsw.Value))
                {
                    sftp.Connect();
                    if (_SFTPFolder.Value.Length > 0)
                        sftp.ChangeDirectory(_SFTPFolder.Value);

                    using (Stream destFile = File.Create(_destinationFilePath.Value))
                    {
                        sftp.DownloadFile(_SFTPFileName.Value, destFile);
                        destFile.Close();
                    }

                    if (_delete.Value)
                        sftp.DeleteFile(_SFTPFileName.Value);

                    sftp.Disconnect();
                    retVal = 0;
                }
            }
            catch (Exception ex)
            {
                SystemHelper.ThrowErrorToSql(ex.Message, 16);
            }

            return retVal;
        }

        [Microsoft.SqlServer.Server.SqlProcedure]
        public static SqlInt32 SFTPDownloadFiles(SqlString _SFTPUserId, SqlString _SFTPUserPsw, SqlString _SFTPServer, SqlInt32 _SFTPPort, SqlString _SFTPFolder, SqlString _destinationFolder, SqlBoolean _delete)
        {
            SqlInt32 retVal = -1;

            try
            {
                using (var sftp = new SftpClient(_SFTPServer.Value, _SFTPPort.Value, _SFTPUserId.Value, _SFTPUserPsw.Value))
                {
                    
                    sftp.Connect();

                    var files = sftp.ListDirectory(_SFTPFolder.Value);

                    if (_SFTPFolder.Value.Length > 0)
                        sftp.ChangeDirectory(_SFTPFolder.Value);

                    if (!Directory.Exists(_destinationFolder.Value))
                        throw new Exception("Destination folder does not exists!");

                    foreach (var file in files)
                    {
                        if (!file.Name.StartsWith("."))
                        {
                            if (File.Exists(_destinationFolder.Value + "\\" + file.Name))
                                throw new Exception("Destination file \"" + _destinationFolder.Value + "\\" + file.Name + "\" exists!");
                        }
                    }

                    foreach (var file in files)
                    {
                        if (!file.Name.StartsWith("."))
                        {
                            using (Stream destFile = File.Create(Path.Combine(_destinationFolder.Value, file.Name)))
                            {
                                sftp.DownloadFile(file.Name, destFile);
                                destFile.Close();
                            }

                            if (_delete.Value)
                                sftp.DeleteFile(file.Name);
                        }
                    }

                    sftp.Disconnect();
                    retVal = 0;
                }
            }
            catch (Exception ex)
            {
                SystemHelper.ThrowErrorToSql(ex.Message, 16);
            }

            return retVal;
        }

        [Microsoft.SqlServer.Server.SqlProcedure]
        public static SqlInt32 SFTPUploadFile(SqlString _SFTPUserId, SqlString _SFTPUserPsw, SqlString _SFTPServer, SqlInt32 _SFTPPort, SqlString _SFTPFolder, SqlString _sourceFilePath, SqlBoolean _overwrite)
        {
            SqlInt32 retVal = -1;

            try
            {
                using (var sftp = new SftpClient(_SFTPServer.Value, _SFTPPort.Value, _SFTPUserId.Value, _SFTPUserPsw.Value))
                {
                    sftp.Connect();

                    if (_SFTPFolder.Value.Length > 0)
                        sftp.ChangeDirectory(_SFTPFolder.Value);

                    using (Stream destFile = File.OpenRead(_sourceFilePath.Value))
                    {
                        sftp.UploadFile(destFile, Path.GetFileName(_sourceFilePath.Value), _overwrite.Value);
                        destFile.Close();
                    }

                    sftp.Disconnect();
                    retVal = 0;
                }
            }
            catch (Exception ex)
            {
                SystemHelper.ThrowErrorToSql(ex.Message, 16);
            }

            return retVal;
        }

        /*
        [Microsoft.SqlServer.Server.SqlFunction(FillRowMethodName = "ListSFTPFiles", DataAccess=DataAccessKind.Read, TableDefinition = "FileName nvarchar(500), FileSize bigint, CreationTime datetime, IsDirectory bit")]
        public static IEnumerable SFTPListFilesFN(SqlString _userId, SqlString _userPsw, SqlString _SFTPServer, SqlInt32 _port, SqlString _sftpFolder)
        {
            ArrayList fileNames = new ArrayList();

            try
            {
                using (var sftp = new SftpClient(_SFTPServer.Value, _port.Value, _userId.Value, _userPsw.Value))
                {
                    sftp.Connect();
                    var files = sftp.ListDirectory(_sftpFolder.Value);
                    foreach (var file in files)
                    {
                        Renci.SshNet.Sftp.SftpFileAttributes sftatt = file.Attributes;
                        fileNames.Add(new SFTPFileProperties(file.Name, sftatt.Size, file.LastWriteTime, file.IsDirectory));
                    }
                }

            }
            catch (Exception ex)
            {
                Int16 errSeverity = 16;
                SqlConnection conn = new SqlConnection("context connection=true");
                conn.Open();

                string msg = string.Format("RAISERROR('{0}',{1},1)", ex.Message.Replace('\'', ' '), errSeverity);
                SqlCommand cmd = new SqlCommand(msg, conn);

                //try
                //{
                SqlPipe sqlpipe = SqlContext.Pipe;
                sqlpipe.ExecuteAndSend(cmd);
                   
                //}
                //catch { }
            }

            return fileNames;
        }

        public static void ListSFTPFiles(object objFileProperties, out SqlString fileName, out SqlDouble fileSize, out SqlDateTime creationTime, out SqlBoolean isDirectory)
        {
            //I'm using here the FileProperties class defined above
            SFTPFileProperties fileProperties = (SFTPFileProperties)objFileProperties;
            fileName = fileProperties.FileName;
            fileSize = fileProperties.FileSize;
            creationTime = fileProperties.CreationTime;
            isDirectory = fileProperties.IsDirectory;

        }

        private class SFTPFileProperties
        {
            public SqlString FileName;
            public SqlDouble FileSize;
            public SqlDateTime CreationTime;
            public SqlBoolean IsDirectory;
            public SFTPFileProperties(SqlString fileName, SqlDouble fileSize,
            SqlDateTime creationTime, SqlBoolean isDirectory)
            {
                FileName = fileName;
                FileSize = fileSize;
                CreationTime = creationTime;
                IsDirectory = isDirectory;
            }
        }
        */
    }
}
