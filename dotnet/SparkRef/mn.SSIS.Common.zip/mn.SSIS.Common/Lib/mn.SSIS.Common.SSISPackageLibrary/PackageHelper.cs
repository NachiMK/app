﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Tasks.ScriptTask;

namespace mn.SSIS.Common.SSISPackageLibrary
{
    public static class PackageHelper
    {
        public static void AddInformation(ScriptObjectModel Dts, string subComponent, string LogMessage)
        {
            bool boolfireAgain = false;
            Dts.Events.FireInformation(0, subComponent, LogMessage, "", 0, ref boolfireAgain);
        }

        public static void AddInformation(ScriptObjectModel Dts, string subComponent, IList<object> LogMessages)
        {
            foreach (object obj in LogMessages)
                AddInformation(Dts, subComponent, obj.ToString());
        }

        public static void AddInformation(ScriptObjectModel Dts, string LogMessage)
        {
            AddInformation(Dts, string.Empty, LogMessage);
        }

        public static void AddError(ScriptObjectModel Dts, string ErrorMessage)
        {
            AddError(Dts,string.Empty, ErrorMessage);
        }

        public static void AddError(ScriptObjectModel Dts, string subComponent, string ErrorMessage)
        {
            Dts.Events.FireError(0, subComponent, ErrorMessage, "", 0);
        }

        public static void AddError(ScriptObjectModel Dts, string subComponent, Exception ex)
        {
            string ErrorMessage = (ex != null) ? ex.Message : string.Empty;

            if (!string.IsNullOrEmpty(ErrorMessage))
                Dts.Events.FireError(0, subComponent, ErrorMessage, "", 0);
        }

        public static void AddError(ScriptObjectModel Dts, Exception ex)
        {
            AddError(Dts, string.Empty, ex);
        }
    }
}
