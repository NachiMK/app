﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Xml;

namespace mn.SSIS.Common.XMLLibrary
{
    public static class XMLHelper
    {
        public static void MergeXML(ref StringBuilder TargetXML, string XMLstringToMerge)
        {
            if (TargetXML == null)
                TargetXML = new StringBuilder(256);

            if (TargetXML.Length > 0)
            {
                var TargetXMLDoc = GetXDocument(TargetXML.ToString());

                if (TargetXML == null)
                    throw new ArgumentException("Invalid TargetXML. TargetXML string couldnt be parsed. Merge was aborted");

                var SourceXMLDoc = GetXDocument(XMLstringToMerge);
                if (SourceXMLDoc == null)
                    throw new ArgumentException("Invalid XMLStringToMerge. XMLStringToMerge string couldnt be parsed. Merge was aborted");

                TargetXMLDoc.Root.Add(SourceXMLDoc.Root.Elements());
                TargetXML.Clear();
                TargetXML.Append(TargetXMLDoc.Declaration);
                TargetXML.AppendLine(TargetXMLDoc.ToString());
            }
            else
            {
                TargetXML.Append(XMLstringToMerge);
            }

        }

        public static bool HasElements(string XMLString)
        {
            if (string.IsNullOrEmpty(XMLString))
                return false;

            XDocument xmlDoc = GetXDocument(XMLString);
                
            if (xmlDoc != null)
            {
                IEnumerable<XElement> xeElements = xmlDoc.Elements();
                if ((xeElements != null) && (xeElements.ElementAt<XElement>(0) != null))
                    return (xeElements.ElementAt<XElement>(0).Nodes().Count<XNode>() > 0);
            }

            return false;
        }

        public static XDocument GetXDocument(string XMLAsString)
        {
            XDocument xmlDoc = null;
            try
            {
                xmlDoc = XDocument.Parse(XMLAsString);
            }
            catch
            {
                xmlDoc = null;
            }

            return xmlDoc;
        }

        public static string Transform(string XMLAsString, string XSLT, bool PreserveDeclaration = true)
        {
            StringWriter stringWriter = new StringWriter();
            StringBuilder strXMLBuilder = new StringBuilder(256);
            XmlWriterSettings xmlSettings = null;

            if (PreserveDeclaration)
            {
                xmlSettings = new XmlWriterSettings();
                xmlSettings.OmitXmlDeclaration = false;
                xmlSettings.ConformanceLevel = ConformanceLevel.Document;
                xmlSettings.Encoding = UTF8Encoding.UTF8;
            }

            XmlWriter xmlWriter = XmlWriter.Create(strXMLBuilder, xmlSettings);

            using (XmlReader xmlTextReader = new XmlTextReader(new StringReader(XMLAsString)))
            {
                using (StringXMLTextReader xReader = new StringXMLTextReader(XSLT))
                {
                    //xReader.StringTextReader.Read();
                    XslCompiledTransform xslt = new XslCompiledTransform();
                    xslt.Load(xReader.xmlTextReader);
                    xslt.Transform(xmlTextReader, null, xmlWriter);
                }
            }

            return strXMLBuilder.ToString();
        }

        public static void RemoveAllAttributes(XDocument xmlDoc)
        {
            if (xmlDoc != null)
            {
                foreach (var descendants in xmlDoc.Descendants())
                    descendants.RemoveAttributes();
            }
        }

        public static string RemoveAllAttributes(string XMLAsString)
        {
            XDocument xmlDoc = GetXDocument(XMLAsString);
            RemoveAllAttributes(xmlDoc);

            if (xmlDoc != null)
                return xmlDoc.Declaration + System.Environment.NewLine + xmlDoc.ToString();
            else
                return XMLAsString;
        }

        private static XPathDocument GetXPathDoc(string XMLAsString)
        {
            XPathDocument XPathDoc = null;
            using (TextReader textReader = new StringReader(XMLAsString))
            {
                XPathDoc = new XPathDocument(textReader);
            }
            return XPathDoc;
        }

    }

    public class StringXMLTextReader : IDisposable
    {
        public TextReader StringTextReader { get; private set;}
        public XmlTextReader xmlTextReader { get; private set; }

        public void Dispose()
        {
            xmlTextReader.Dispose();
            StringTextReader.Dispose();
        }

        private StringXMLTextReader()
        {
            StringTextReader = new StringReader(string.Empty);
            xmlTextReader = new XmlTextReader(StringTextReader);
        }

        public StringXMLTextReader(string XMLAsString)
        {
            if (!string.IsNullOrEmpty(XMLAsString))
            {
                StringTextReader = new StringReader(XMLAsString);
                xmlTextReader = new XmlTextReader(StringTextReader);
            }
        }
    }
}
