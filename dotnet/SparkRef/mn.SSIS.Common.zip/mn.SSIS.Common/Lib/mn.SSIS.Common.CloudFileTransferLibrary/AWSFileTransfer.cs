﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common.CloudFileTransferLibrary
{
    /// <summary>
    /// Class to upload/manupulate/download files
    /// from S3
    /// </summary>
    public class AWSFileTransfer : ICloudFileTransfer
    {
        private static IAmazonS3 _awsClient;

        private AWSFileTransfer() { }

        /// <summary>
        /// Initializes a new connection to AWS if proper
        /// configuration values are given
        /// </summary>
        /// <param name="Config">This parameter should have two Name value pairs called AWSProfileName and AWSProfilesLocation. NOte the spelling and case</param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public static AWSFileTransfer CreateNewByProfile(DBAppParamList Config, out DBAppLogList OutputList)
        {
            AWSFileTransfer awsFileTransfer = new AWSFileTransfer();
            awsFileTransfer.Init(Config, out OutputList);

            if ((OutputList != null) && (OutputList.HasError))
                return null;

            return awsFileTransfer;
        }

        /// <summary>
        /// Creates a new AWS client based on App.Config values
        /// 
        /// If you calling this from SSIS you may not have a App.Config and this will 
        /// through an error. So for SSIS use other CreateNew methods don't use this one.
        /// </summary>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public static AWSFileTransfer CreateNewDefaultProfile(out DBAppLogList OutputList)
        {
            AWSFileTransfer awsFileTransfer = new AWSFileTransfer();
            awsFileTransfer.Init(out OutputList);

            if ((OutputList != null) && (OutputList.HasError))
                return null;

            return awsFileTransfer;
        }

        /// <summary>
        /// Creates new AWS client based on AWS Profile name
        /// and Profiles Location passed in as parameter
        /// 
        /// Use this for SSIS implementations. But, make sure the JSON file is created
        /// and accessible by SSIS.
        /// 
        /// JSON file should have the Profile name you passing in with the access key and secret key.
        /// </summary>
        /// <param name="AWSProfileName"></param>
        /// <param name="AWSProfilesLocation">Location of the JSON file that has the Access key and secret.</param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public static AWSFileTransfer CreateNewByProfile(string AWSProfileName, string AWSProfilesLocation, string AWSRegion, out DBAppLogList OutputList)
        {
            string profileName = AWSProfileName;
            string profileLocation = AWSProfilesLocation;

            DBAppParamList dbParamList = new DBAppParamList();
            dbParamList.Add("AWSProfileName", profileName);
            dbParamList.Add("AWSProfilesLocation", profileLocation);
            dbParamList.Add("AWSRegion", AWSRegion);

            AWSFileTransfer awsFileTransfer = new AWSFileTransfer();
            awsFileTransfer.Init(dbParamList, out OutputList);

            if ((OutputList != null) && (OutputList.HasError))
                return null;

            return awsFileTransfer;
        }

        /// <summary>
        /// Creates a New S3 Client based on provided
        /// access key, secret key, region.
        /// 
        /// If those values are empty or null then null value is returned.
        /// 
        /// IF error creating a S3 client due to network or credential issues then null is returned.
        /// </summary>
        /// <param name="AccessKey"></param>
        /// <param name="SecretKey"></param>
        /// <param name="Region"></param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public static AWSFileTransfer CreateNew(string AccessKey, string SecretKey, string Region, out DBAppLogList OutputList)
        {
            // initialize and delegate call.
            AWSFileTransfer awsFileTransfer = new AWSFileTransfer();
            awsFileTransfer.Init(AccessKey, SecretKey, Region, out OutputList);

            if ((OutputList != null) && (OutputList.HasError))
                return null;

            return awsFileTransfer;
        }


        /// <summary>
        /// Creates a AWS client for transfering files.
        /// 
        /// Create a Config Parameter, add AWSProfileName, AWSProfilesLocation, and AWSRegion
        /// as "key" name and whatever values as per your needs.
        /// </summary>
        /// <param name="Config"></param>
        /// <param name="OutputList"></param>
        public void Init(DBAppParamList Config, out DBAppLogList OutputList)
        {
            OutputList = new DBAppLogList();
            try
            {
                string profileName = Config["AWSProfileName"];
                string profileLocation = Config["AWSProfilesLocation"];
                string regionName = Config["AWSRegion"];
                RegionEndpoint regionEndPoint = null;

                if (profileName.Length == 0)
                    OutputList.Add(String.Format("Profile Name with AWSProfileName :{0} in Config parameter is Missing.", profileName));
                else
                    OutputList.Add(new DBAppLog(String.Format("Profile Name in Config is :{0}", profileName)));

                if (profileLocation.Length == 0)
                    OutputList.Add(String.Format("Profile Location with AWSProfilesLocation :{0} in Config is Missing.", profileLocation));
                else
                    OutputList.Add(String.Format("Profile Location in Config is :{0}", profileLocation));

                if (regionName.Length == 0)
                    OutputList.Add(String.Format("Region name with key region :{0} in Config is Missing.", regionName));
                else
                {
                    regionEndPoint = RegionEndpoint.GetBySystemName(regionName);
                    if (regionEndPoint == null)
                        OutputList.Add(String.Format("Region :{0} is Missing or not a valid value from allowed list of AWS RegionEndPoints. Check help @ http://docs.aws.amazon.com/sdkfornet1/latest/apidocs/html/T_Amazon_RegionEndpoint.htm.", regionName));
                    else
                        OutputList.Add(String.Format("Region provided is :{0}", regionName));
                }

                // create credentials from profile
                StoredProfileAWSCredentials cred = new StoredProfileAWSCredentials(profileName, profileLocation);
                OutputList.Add("AWS Credentials Created.");

                // create client
                _awsClient = new AmazonS3Client(cred, regionEndPoint);
                OutputList.Add("Connection to S3 Established.");
            }
            catch (Exception ex)
            {
                OutputList.Add("Error creating AWS S3 Client", DBLogTypeEnum.Error, ex);
            }
        }

        /// <summary>
        /// Reads AWS configuraiton infomration from AWS profile location
        /// and App.Config and creates a AWS Client.
        /// 
        /// If calling from SSIS this may not be ideal because we cannot specify
        /// App.Config.
        /// </summary>
        /// <param name="OutputList"></param>
        public void Init(out DBAppLogList OutputList)
        {
            OutputList = new DBAppLogList();

            try
            {
                string profileName = AWSConfigs.AWSProfileName;
                string profileLocation = AWSConfigs.AWSProfilesLocation;
                string regionName = AWSConfigs.RegionEndpoint.SystemName;

                DBAppParamList dbParamList = new DBAppParamList();
                dbParamList.Add("AWSProfileName", profileName);
                dbParamList.Add("AWSProfilesLocation", profileLocation);
                dbParamList.Add("AWSRegion", regionName);

                // delegate call
                Init(null, out OutputList);
            }
            catch (Exception ex)
            {
                OutputList.Add("Error creating AWS S3 Client", DBLogTypeEnum.Error, ex);
            }
        }

        /// <summary>
        /// Creates a New S3 Client based on Access Key, Secret Key and region.
        /// 
        /// If one of them is missing, empty, or null then an exception is returned
        /// </summary>
        /// <param name="AccessKey"></param>
        /// <param name="SecretKey"></param>
        /// <param name="Region"></param>
        /// <param name="OutputList"></param>
        public void Init(string AccessKey, string SecretKey, string Region, out DBAppLogList OutputList)
        {
            OutputList = new DBAppLogList();

            try
            {
                string strAccessKey = AccessKey;
                string strSecretKey = SecretKey;
                string strRegion = Region;
                RegionEndpoint regionEndPoint = null;

                if (strAccessKey.Length == 0)
                    OutputList.Add(String.Format("Access Key :{0} is Missing. Please provide a valid key", strAccessKey));
                else
                    OutputList.Add(new DBAppLog(String.Format("Access Key provided is :{0}", strAccessKey)));

                if (strSecretKey.Length == 0)
                    OutputList.Add(String.Format("Secret Key :{0} is Missing.", strSecretKey));
                else
                    OutputList.Add(String.Format("Secret key provided is :{0}", strSecretKey));

                if (strRegion.Length == 0)
                    OutputList.Add(String.Format("Region :{0} is Missing", strRegion));
                else
                {
                    regionEndPoint = RegionEndpoint.GetBySystemName(strRegion);
                    if (regionEndPoint == null)
                        OutputList.Add(String.Format("Region :{0} is Missing or not a valid value from allowed list of AWS RegionEndPoints. Check help @ http://docs.aws.amazon.com/sdkfornet1/latest/apidocs/html/T_Amazon_RegionEndpoint.htm.", strRegion));
                    else
                        OutputList.Add(String.Format("Region provided is :{0}", strRegion));
                }
                
                // create client
                _awsClient = new AmazonS3Client(AccessKey, SecretKey, RegionEndpoint.GetBySystemName(Region));
                OutputList.Add("Connection to S3 Established.");
            }
            catch (Exception ex)
            {
                OutputList.Add("Error creating AWS S3 Client", DBLogTypeEnum.Error, ex);
            }

        }


        /// <summary>
        /// Uploads a given file to given S3 bucket (DestinationPath).
        /// 
        /// If KeyName is provided as part of optional parameter list then the file
        /// will be uploaded with the key name.
        /// </summary>
        /// <param name="FileToUpload">File to upload. Caller should have access to this location.</param>
        /// <param name="BucketName">S3 Bucket Name</param>
        /// <param name="OptionalParamList">A dictionary that has "KeyName" as a key and appropriate value for it.</param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public bool UploadFile(string FileToUpload, string BucketName, DBAppParamList OptionalParamList, out DBAppLogList OutputList)
        {
            bool RetVal = false;
            OutputList = new DBAppLogList();

            string strBucketName = BucketName;
            string KeyName = string.Empty;

            if (_awsClient == null)
            {
                OutputList.Add("S3 Connection not established. Check AWSProfileName, AWSProfilesLocation, Data inside the Profiles Location", DBLogTypeEnum.Error, new ArgumentNullException("Call CreateNew with proper parameters to initialize AWSClient"));
                return false;
            }

            try
            {
                // get additional values
                if (OptionalParamList != null)
                {
                    // key name
                    if (OptionalParamList["KeyName"] != null)
                        KeyName = OptionalParamList["KeyName"];
                    else if(OptionalParamList["FilePrefix"] != null)
                        KeyName = OptionalParamList["FilePrefix"];
                    else if (OptionalParamList["SubFolder"] != null)
                        KeyName = OptionalParamList["SubFolder"];
                }

                // add a slash at end if it doesn't exists
                if (!string.IsNullOrEmpty(KeyName))
                    if (!KeyName.EndsWith("/"))
                        KeyName = KeyName + "/";


                // check if source file exists before uploading
                if (!System.IO.File.Exists(FileToUpload))
                {
                    OutputList.Add(String.Format("File to upload {0} is NOT FOUND...", FileToUpload), DBLogTypeEnum.Error, new System.IO.FileNotFoundException("File to upload to S3 not found."));
                    return RetVal;
                }
                
                // add file name to key
                KeyName = KeyName + System.IO.Path.GetFileName(FileToUpload);

                // simple object put
                PutObjectRequest request = new PutObjectRequest()
                {
                    FilePath = FileToUpload,
                    BucketName = strBucketName,
                    Key = KeyName,
                    ServerSideEncryptionMethod = ServerSideEncryptionMethod.AES256
                };
                OutputList.Add(String.Format("Uploading File {0} to Bucket:{1}, KeyName:{2} Started...", FileToUpload, strBucketName, KeyName));

                System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                PutObjectResponse response = null;
                sw.Start();
                try
                {
                    response = _awsClient.PutObject(request);
                    sw.Stop();
                    // mark as successfully uploaded
                    RetVal = true;

                    OutputList.Add(string.Format("Successfully uploaded File!! Time to upload:<seconds>{0}<seconds>", sw.Elapsed.TotalSeconds.ToString()));
                    OutputList.Add(string.Format("HttpStatusCode:{0}, response:", response.HttpStatusCode.ToString(), response.ToString()));
                }
                catch (Exception ex)
                {
                    sw.Stop();
                    OutputList.Add("File upload Failed! Seconds elapsed before failing:" + sw.Elapsed.TotalSeconds.ToString(), DBLogTypeEnum.Error, ex);
                }
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId") ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    OutputList.Add("Please check the provided AWS Credentials. If you haven't signed up for Amazon S3, please visit http://aws.amazon.com/s3", DBLogTypeEnum.Error, amazonS3Exception);
                }
                else
                {
                    OutputList.Add("An error occurred when writing an object", DBLogTypeEnum.Error, amazonS3Exception);
                }
            }

            return RetVal;
        }

        /// <summary>
        /// Uploads given file to Bucket/Subfolder.
        /// </summary>
        /// <param name="FileToUpload"></param>
        /// <param name="BucketName"></param>
        /// <param name="SubFolderPath"></param>
        /// <param name="OptionalParamList"></param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public bool UploadFile(string FileToUpload, string BucketName, string SubFolderPath, out DBAppLogList OutputList)
        {
            string strSubFolderPath = SubFolderPath;
            DBAppParamList dbParamList = new DBAppParamList();
            dbParamList.Add("FilePrefix", strSubFolderPath);
            return UploadFile(FileToUpload, BucketName, dbParamList, out OutputList);
        }

        /// <summary>
        /// UPloads a file to given bucket
        /// </summary>
        /// <param name="FileToUpload"></param>
        /// <param name="BucketName"></param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public bool UploadFile(string FileToUpload, string BucketName, out DBAppLogList OutputList)
        {
            DBAppParamList dbParamList = null;
            return UploadFile(FileToUpload, BucketName, dbParamList, out OutputList);
        }

        /// <summary>
        /// Returns list of files in given S3 Bucket.
        /// 
        /// Set Folder Path to S3 Bucket name
        /// </summary>
        /// <param name="BucketName">Set it to S3 Bucket Name</param>
        /// <param name="OptionalParamList">To Filter by FilePrefix, add a Name value pair with Name as "FilePrefix" and whatever value you want</param>
        /// <param name="OutputList">Any errors or info messages are retrned</param>
        /// <returns>List of file names in the bucket</returns>
        public List<string> ListFiles(string BucketName, DBAppParamList OptionalParamList, out DBAppLogList OutputList)
        {
            string FilePrefix = string.Empty;
            OutputList = new DBAppLogList();
            List<string> retList = new List<string>(100);

            // valid client exists
            if (_awsClient == null)
            {
                OutputList.Add("S3 Connection not established. Check AWSProfileName, AWSProfilesLocation, Data inside the Profiles Location", DBLogTypeEnum.Error, new ArgumentNullException("Call CreateNew with proper parameters to initialize AWSClient"));
                return null;
            }

            // valid parameters
            if (string.IsNullOrEmpty(BucketName))
            {
                OutputList.Add(String.Format("Bucket Name: {0} to list is empty...", BucketName), DBLogTypeEnum.Error, new ArgumentNullException("Bucket Name to List is empty."));
                return null;
            }

            // get additional values
            if (OptionalParamList != null)
            {
                // key name
                if (OptionalParamList["FilePrefix"] != null)
                    FilePrefix = OptionalParamList["FilePrefix"];
                else if (OptionalParamList["KeyName"] != null)
                    FilePrefix = OptionalParamList["KeyName"];
                else if (OptionalParamList["SubFolder"] != null)
                    FilePrefix = OptionalParamList["SubFolder"];
            }

            // setup bucket name
            ListObjectsRequest request = new ListObjectsRequest();
            request.BucketName = BucketName;

            ListObjectsResponse response = null;
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            try
            {
                OutputList.Add("Calling List Objects for S3....");
                sw.Start();

                // filter by file prefix if one is provided
                if (FilePrefix.Length == 0)
                    response = _awsClient.ListObjects(request);
                else
                    response = _awsClient.ListObjects(BucketName, FilePrefix);

                sw.Stop();

                if (response == null)
                    OutputList.Add(String.Format("No Files to List in Bucket {0}, Prefile {1}, Time Elapsed:{2}", BucketName, FilePrefix, sw.Elapsed.TotalSeconds.ToString()));
                else
                    OutputList.Add(string.Format("Successfully found Files in list!! Time to List:<seconds>{0}<seconds>", sw.Elapsed.TotalSeconds.ToString()));

                // add files to return object
                foreach (S3Object entry in response.S3Objects)
                {
                    retList.Add(entry.Key);
                }
            }
            catch (Exception ex)
            {
                OutputList.Add("Error Listing Files", DBLogTypeEnum.Error, ex);
            }

            return retList;
        }

        /// <summary>
        /// Lists files in given bucket/sub folder
        /// </summary>
        /// <param name="BucketName"></param>
        /// <param name="SubFolderPath"></param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public List<string> ListFiles(string BucketName, string SubFolderPath, out DBAppLogList OutputList)
        {
            string strSubFolderPath = SubFolderPath;
            DBAppParamList dbParamList = new DBAppParamList();
            dbParamList.Add("FilePrefix", strSubFolderPath);
            return ListFiles(BucketName, dbParamList, out OutputList);
        }

        /// <summary>
        /// List files in given Bucket.
        /// </summary>
        /// <param name="BucketName">Name of Bucket</param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public List<string> ListFiles(string BucketName, out DBAppLogList OutputList)
        {
            DBAppParamList dbParamList = null;
            return ListFiles(BucketName, dbParamList, out OutputList);
        }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="OutputList"></param>
        /// <returns></returns>
        public bool CheckFileExists(string BucketName, string FileName, out DBAppLogList OutputList)
        {
            bool result = false;
            string strFileFullName = string.Empty;
            OutputList = new DBAppLogList();

            OutputList.Add("Create S3FileInfo....");

            Amazon.S3.IO.S3FileInfo s3FileInfo = new Amazon.S3.IO.S3FileInfo(_awsClient, BucketName, FileName);
            if (s3FileInfo.Exists)
                result = true;

            if (result)
                OutputList.Add("Element starting with : " + FileName + " exists in Bucket:" + BucketName + " full File name is:" + strFileFullName, DBLogTypeEnum.Info);
            else
                OutputList.Add("Element starting with : " + FileName + " DOES NOT exists in Bucket:" + BucketName, DBLogTypeEnum.Info);

            return result;
        }

        /// <summary>
        /// Not Implemented
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="FileDeleted"></param>
        /// <returns></returns>
        public DBAppLogList DeleteFile(string FileName, out bool FileDeleted)
        {
            throw new NotImplementedException();
        }
    }
}
