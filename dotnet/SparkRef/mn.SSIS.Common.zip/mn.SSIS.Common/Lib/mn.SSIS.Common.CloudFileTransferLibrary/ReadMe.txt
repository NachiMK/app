﻿*****************************************************
****** DO NOT USE THIS TOOL IN PRODUCTION ***********
*****************************************************

/****************************************/
        Test Harness Application
		To test 
			-S3 connection
			-Upload Files to S3
			-Look at file uploaded to S3
/****************************************/


Access:
- Make sure you have Access to the S3 Bucket you are trying to test with.
- Get your Access Key and Secret Key from AWS Console (Talk to Sys Eng.) and update in the aws-spark-data-services.json file (at time of building this app the file had Nachi's Keys)
- If you want to use a different AWS profile, please update the first line in the aws-spark-data-services.json file and as well the AWSPRofileName attribute in the App.COnfig
- If you want to use a Profile file from different location, then update the location in App.Config unders <aws> node profileLocation attribute.

Tools Required:
- To compile this you need to install AWS SDK for .NET at the time of building this app, it was available @ http://sdk-for-net.amazonwebservices.com/latest/AWSToolsAndSDKForNet.msi
- Of course .NET 4.5 and Visual Studio 2013 is required as well.


Callouts
- This application was build to test only with S3 bucket "spark-data-services". It may work for other buckets if you have permissions but it was not tested.
- This application doesn't do any validations. It is upto the user to enter correct values.




