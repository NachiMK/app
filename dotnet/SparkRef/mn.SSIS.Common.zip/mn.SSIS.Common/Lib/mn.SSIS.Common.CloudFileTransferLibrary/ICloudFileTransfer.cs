﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace mn.SSIS.Common.CloudFileTransferLibrary
{
    public interface ICloudFileTransfer
    {
        void Init(DBAppParamList Config, out DBAppLogList OutputList);

        void Init(string AccessKey, string SecretKey, string Region, out DBAppLogList OutputList);

        void Init(out DBAppLogList OutputList);

        bool UploadFile(string FileToUpload, string BucketName, DBAppParamList OptionalParamList, out DBAppLogList OutputList);

        bool UploadFile(string FileToUpload, string BucketName, string SubFolderPath, out DBAppLogList OutputList);

        bool UploadFile(string FileToUpload, string BucketName, out DBAppLogList OutputList);

        List<string> ListFiles(string BucketName, DBAppParamList OptionalParamList, out DBAppLogList OutputList);

        List<string> ListFiles(string BucketName, string SubFolderPath, out DBAppLogList OutputList);

        List<string> ListFiles(string BucketName, out DBAppLogList OutputList);

        bool CheckFileExists(string BucketName, string FileName, out DBAppLogList OutputList);

        DBAppLogList DeleteFile(string FileName, out bool FileDeleted);
    }
}
