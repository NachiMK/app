﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mn.SSIS.Common;
using mn.SSIS.Common.SMOLibrary;

namespace mn.SSIS.Common.BulkCopyLibrary
{
    public enum CopyTableOption
    {
        CreateIfNotExistsAndCopy = 2,
        DropCreateAndCopy = 3,
        BackupCreateAndCopy = 4,
        Append = 5
    }

    public class BulkCopyResults
    {
        public bool RowsAdded { get; set; }
        public int RowCountBeforeCopy { get; set; }
        public int RowCountAfterCopy { get; set; }
        public bool TableCreated { get; set; }
        public bool TableBackedUp { get; set; }
        public string BackupTableName { get; set; }
        public Exception ExceptionDuringCopy { get; set; }
    }

    /// <summary>
    /// Class used for copying tables from one SQL Server to another.
    /// It uses DataTable to copy. So there is a limitation on number
    /// of rows that can be copied.
    /// </summary>
    public class BulkCopyHelper
    {
        /// <summary>
        /// Copies given table to target.
        /// </summary>
        /// <param name="SourceSQLConnector"></param>
        /// <param name="SourceTableName"></param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="copyTableOption"></param>
        /// <param name="CommaSeparatedColumnNames">Comma separated columns</param>
        /// <param name="ColFilterOption">Include/exclude columns</param>
        /// <param name="TableCopied">Indicates whether data was copied.</param>
        /// <returns></returns>
        public DBAppLogList CopyTable(SQLConnector SourceSQLConnector
                                     ,string SourceTableName
                                     ,SQLConnector TargetConnector
                                     ,string TargetTableName
                                     ,CopyTableOption copyTableOption
                                     ,string CommaSeparatedColumnNames
                                     ,ScriptColumnFilterOption ColFilterOption
                                     ,out BulkCopyResults TableCopyResults)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Copies output of given query to target table.
        /// </summary>
        /// <param name="SourceSQLConnector">This should have the script to excute</param>
        /// <param name="TargetConnector"></param>
        /// <param name="TargetTableName"></param>
        /// <param name="copyTableOption">Default is Create If Not exists and copy.</param>
        /// <param name="CommaSeparatedColumnNames">Comma separated columns. Can be Empty if Next CopyFilterOption is None</param>
        /// <param name="ColFilterOption"></param>
        /// <param name="TableCopied"></param>
        /// <returns></returns>
        public DBAppLogList CopyTableFromQuery(SQLConnector SourceSQLConnector
                                              ,SQLConnector TargetConnector
                                              ,string TargetTableName
                                              ,CopyTableOption copyTableOption
                                              ,string CommaSeparatedColumnNames
                                              ,ScriptColumnFilterOption ColFilterOption
                                              ,out BulkCopyResults TableCopyResults)
        {
            throw new NotImplementedException();
        }


    }
}
