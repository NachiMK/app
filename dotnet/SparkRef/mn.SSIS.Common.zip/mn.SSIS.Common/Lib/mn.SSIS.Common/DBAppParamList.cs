﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common
{
    public class DBAppParamList : NameValueCollection 
    {
        public void Add(string name, int value)
        {
            base.Add(name, value.ToString());
        }

        public void Add(string name, DateTime dt)
        {
            base.Add(name, dt.Ticks.ToString());
        }

        public int IntValue(string Key)
        {
            int RetVal;
            if (Int32.TryParse(this[Key], out RetVal))
                return RetVal;
            else
                return default(int);
        }

        public DateTime DateTimeValue(string Key)
        {
            long lTicks;
            DateTime d = default(DateTime);
            if (long.TryParse(this[Key], out lTicks))
                d = new DateTime(lTicks);

            return d;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(100);

            for (int intIdx = 0; intIdx < this.Count; intIdx++)
            {
                sb.AppendLine(string.Format("ID:{0}, Name:{1}, Value:{2}", intIdx.ToString(), this.GetKey(intIdx), this[intIdx]));
            }

            return sb.ToString();
        }
    }
}
