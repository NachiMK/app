﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common
{
    public class DBAppLogList : List<DBAppLog>
    {
        public bool HasError
        {
            get
            {
                bool Retval = false;

                foreach (DBAppLog l in this)
                {
                    if ((l.LogException != null) || (l.LogMessageType == DBLogTypeEnum.Error))
                    {
                        Retval = true;
                        break;
                    }
                }

                // return
                return Retval;
            }
        }

        /// <summary>
        /// adds a output message of type Info with no exceptions 
        /// attached to it.
        /// </summary>
        /// <param name="Message"></param>
        public void Add(string Message)
        {
            this.Add(Message, DBLogTypeEnum.Info, null);
        }

        /// <summary>
        /// adds a output message with given type
        /// but with no exceptions
        /// </summary>
        /// <param name="Message"></param>
        /// <param name="LogType"></param>
        public void Add(string Message, DBLogTypeEnum LogType)
        {
            this.Add(Message, LogType, null);
        }

        /// <summary>
        /// Adds a output with given message, type, and exception
        /// </summary>
        /// <param name="Message"></param>
        /// <param name="LogType"></param>
        /// <param name="ex"></param>
        public void Add(string Message, DBLogTypeEnum LogType, Exception ex)
        {
            this.Add(new DBAppLog(Message, ex, LogType));
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(200);
            int i = 1;
            sb.AppendLine("DBAppLogList: No of Logs:" + this.Count.ToString());
            foreach (DBAppLog e in this)
            {
                sb.AppendLine("Log #:" + i.ToString());
                sb.AppendLine(e.ToString());
                i++;
            }

            // return list
            return sb.ToString();
        }
    }
}
