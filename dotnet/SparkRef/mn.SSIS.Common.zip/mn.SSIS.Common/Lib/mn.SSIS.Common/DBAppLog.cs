﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common
{
    public enum DBLogTypeEnum
    {
        Info = 0,
        Warning,
        Error,
        ValidationMessage
    }


    public class DBAppLog
    {
        public string LogMessage { get; set; }
        public Exception LogException { get; set; }
        public DBLogTypeEnum LogMessageType { get; set; }
        public DateTime LogTime { get; internal set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(20);
            sb.AppendLine("Log Message:" + LogMessage);
            if (LogException != null)
                sb.AppendLine("Exception:" + LogException.Message);
            else
                sb.AppendLine("Exception:" + "None");
            sb.AppendLine("Message Type:" + LogMessageType.ToString());
            sb.AppendLine("Log Time:" + LogTime.ToString(""));
            return sb.ToString();
        }

                #region constructors

        public DBAppLog() 
        {
            InitializeExportResult();
        }

        public DBAppLog(string Msg)
            : this(Msg, null, DBLogTypeEnum.Info)
        { }

        public DBAppLog(string Msg, Exception LogEx)
            : this(Msg, LogEx, DBLogTypeEnum.Info)
        { }

        public DBAppLog(string Msg, DBLogTypeEnum MsgType)
            : this(Msg, null, MsgType)
        { }

        public DBAppLog(string Msg, Exception LogEx, DBLogTypeEnum LogMsgType)
        {
            InitializeExportResult();
            this.LogMessage = Msg;
            this.LogException = LogEx;
            this.LogMessageType = LogMsgType;
        }



        #endregion

        #region Private Members

        private void InitializeExportResult()
        {
            LogMessage = string.Empty;
            LogException = null;
            LogMessageType = DBLogTypeEnum.Info;
            LogTime = DateTime.Now;
        }

        #endregion


    }
}
