﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common
{
    internal class DBAppParam
    {
        public string ParaName { internal get; set; }
        public string ParamValue { internal get; set; }

        internal DBAppParam() { }

        public DBAppParam(string Name, string Value)
        {
            this.ParaName = Name;
            this.ParamValue = Value;
        }

        public override string ToString()
        {
            return string.Format("Param Name:{0}, Value:{1}:", this.ParaName, this.ParamValue);
        }
    }
}
