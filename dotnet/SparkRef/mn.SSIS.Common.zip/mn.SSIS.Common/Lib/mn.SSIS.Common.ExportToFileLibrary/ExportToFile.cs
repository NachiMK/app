﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mn.SSIS.Common;

namespace mn.SSIS.Common.ExportToFile
{

   /// <summary>
    /// Export a given SQL output to a file.
    /// It can compress the files as well.
    /// </summary>
    public class ExportToFile
    {

        #region static Constructors
        
        /// <summary>
        /// Returns a ExportToFile object if required SQL Connector information is passed in.
        /// </summary>
        /// <param name="TheServerName"></param>
        /// <param name="TheDBName"></param>
        /// <param name="TheScript"></param>
        /// <param name="TheUserName"></param>
        /// <param name="ThePassword"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static ExportToFile NewExportToFile(string TheServerName, string TheDBName, string TheScript, string TheUserName, string ThePassword, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            ExportToFile RetExportToFile = new ExportToFile(TheServerName, TheDBName, TheScript, TheUserName, ThePassword);

            if (!RetExportToFile.IsValid(out TheValidationMessages))
                RetExportToFile = null;

            return RetExportToFile;
        }

        /// <summary>
        /// Overloaded method to create a new Export To File object using Integrated Security
        /// </summary>
        /// <param name="TheServerName"></param>
        /// <param name="TheDBName"></param>
        /// <param name="TheScript"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static ExportToFile NewExportToFile(string TheServerName, string TheDBName, string TheScript, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            ExportToFile RetExportToFile = new ExportToFile(TheServerName, TheDBName, TheScript);

            if (!RetExportToFile.IsValid(out TheValidationMessages))
                RetExportToFile = null;

            return RetExportToFile;
        }

        /// <summary>
        /// Returns a New ExportToFile object with SQL connector object information
        /// </summary>
        /// <param name="TheSQLConnector"></param>
        /// <param name="TheValidationMessages"></param>
        /// <returns></returns>
        public static ExportToFile NewExportToFile(SQLConnector TheSQLConnector, out IList<string> TheValidationMessages)
        {
            TheValidationMessages = null;
            ExportToFile RetExportToFile = new ExportToFile(TheSQLConnector);

            if (!RetExportToFile.IsValid(out TheValidationMessages))
                RetExportToFile = null;

            return RetExportToFile;
        }

        #endregion

        #region Public Properties

        public static int ChunkSize
        {
            get
            {
                return 100000;
            }
        }

        public bool IncludeHeaders
        {
            get
            {
                return _IncludeHeader;
            }
            set
            {
                _IncludeHeader = value;
            }
        }

        public bool IncludeTextQualifiers
        {
            get
            {
                return _IncludeTextQual;
            }
            set
            {
                _IncludeTextQual = value;
            }
        }
        
        public ColumnDelimiter ColDelimiter
        {
            get
            {
                return _ColumnDelimiter;
            }
            set
            {
                _ColumnDelimiter = value;
            }
        }

        public string ColDelimiterString
        {
            get
            {
                return ColumnDelimiterToString(_ColumnDelimiter);
            }
        }

        public RowDelimiters RowDelimiter
        {
            get
            {
                return _RowDelimiter;
            }
            set
            {
                _RowDelimiter = value;
            }
        }

        public string RowDelimiterString
        {
            get
            {
                return RowDelimiterToString(_RowDelimiter);
            }
        }

        public bool SplitFiles
        {
            get
            {
                return _SplitFiles;
            }
            set
            {
                _SplitFiles = value;
            }
        }

        public int BatchSize
        {
            get
            {
                return _BatchSize;
            }
            set
            {
                _BatchSize = value;
            }
        }

        public FileCompressionTypeEnum CompressionType
        {
            get
            {
                return _CompressionType;
            }
            set
            {
                _CompressionType = value;
            }
        }

        public string CompressionTypeToString
        {
            get
            {
                string strRet = string.Empty;
                if (ExportToFileCommon.CompressionFileTypeStrings()[(int)_CompressionType] != null)
                    strRet = ExportToFileCommon.CompressionFileTypeStrings()[(int)_CompressionType];

                // return finded value
                return strRet;
            }
        }


        public string FilePrefix
        {
            get
            {
                return _FilePrefix;
            }
            set
            {
                _FilePrefix = value;
            }
        }

        public bool AppendDateFormat
        {
            get
            {
                return _AppendDateFormat;
            }
            set
            {
                _AppendDateFormat = value;
            }
        }

        public string FileDateFormat
        {
            get
            {
                return _FileDateFormatType;
            }
            set
            {
                _FileDateFormatType = value;
            }
        }

        public string StagingFileLocation
        {
            get
            {
                return _FileStagingLocation;
            }
            set
            {
                _FileStagingLocation = value;
            }
        }

        public string DestinationLocation
        {
            get
            {
                return _DestinationLocation;
            }
            set
            {
                _DestinationLocation = value;
            }
        }
        

        public ExportToFileTypeEnum ExportToFileType
        {
            get
            { 
                return _ExportToFile; 
            }
            set
            {
                _ExportToFile = value;
            }
        }
        public string ExportToFileTypeToString
        {
            get
            {
                string strRet = string.Empty;
                if (ExportToFile.ExportToFileStrings()[(int)_ExportToFile] != null)
                    strRet = ExportToFile.ExportToFileStrings()[(int)_ExportToFile];

                // return finded value
                return strRet;
            }
        }

        public Encoding FileEncoding
        { 
            get
            {
                return _Encoding;
            }
            set
            {
                _Encoding = value;
            }
        }

        public string FileEncodingString
        { 
            get
            {
                //string strRet = string.Empty;
                //if (ExportToFile.FileEncodingTypeStrings()[(int)_Encoding] != null)
                //    strRet = ExportToFile.FileEncodingTypeStrings()[(int)_Encoding];

                // return finded value
                return _Encoding.EncodingName;
            }
        }

        public SQLConnector SQLHelper
        {
            get
            {
                return _SQLConnector;
            }
            set
            {
                _SQLConnector = value;
            }
        }

        public DBAppLogList ExportResults
        {
            get
            {
                return _ExportResultList;
            }
        }

        #endregion

        #region public Functions

        /// <summary>
        /// Returns True if the properties have valid values, if not returns a list of errors
        /// </summary>
        /// <param name="ValidationMessageList"></param>
        /// <returns></returns>
        public bool IsValid(out IList<string> ValidationMessageList)
        {
            bool RetVal = false;
            ValidationMessageList = new List<string>(20);

            // Find if SQL Connector is valid
            if (SQLHelper != null)
            {
                this.SQLHelper.IsValid(true, out ValidationMessageList);
            }
            else
                ValidationMessageList.Add("SQL Connection information is required. Please provide it.");

            if (this.StagingFileLocation.Length > 0)
            {
                if (!System.IO.Directory.Exists(this.StagingFileLocation))
                    ValidationMessageList.Add(string.Format("Directory {0} does not exists. Please provide valid staging directory.", this.StagingFileLocation));
            }

            if (this.DestinationLocation.Length > 0)
            {
                if (!System.IO.Directory.Exists(this.DestinationLocation))
                    ValidationMessageList.Add(string.Format("Directory {0} does not exists. Please provide valid Destination directory.", this.DestinationLocation));
            }

            if (this.AppendDateFormat && (this.FileDateFormat.Length > 0))
            {
                string str = ExportToFile.DateFormatStrings()[this.FileDateFormat];
                if (str.Length == 0)
                    ValidationMessageList.Add(String.Format("File Date Format: {0} is not valie. Please provide a Valid File Date Format", this.FileDateFormat));
            }

            if (this.SplitFiles && (this.BatchSize <= 0))
            {
                ValidationMessageList.Add(String.Format("Batch Size for Spliting Files is : {0}. Please provide a Valid Batch Size of 1 or more", this.BatchSize.ToString()));
            }

            RetVal = ((ValidationMessageList != null) && (ValidationMessageList.Count == 0)) ? true : false;

            return RetVal;
        }

        /// <summary>
        /// Exports the output of given SQL
        /// into one or more files.
        /// 
        /// Files may be compressed and copied to staging location
        /// 
        /// if those values were configured.
        /// 
        /// The return list has any messages and errors that ocurred during the entire export process.
        /// </summary>
        /// <param name="FileList"></param>
        /// <returns></returns>
        public DBAppLogList Export(out ExportFileList FileList)
        {
            FileList = null;
            Exception outEx;

            // clear logs
            this.ExportResults.Clear();
            // log
            this.ExportResults.Add(new DBAppLog("Export Files Started.."));

            if (this.IsValid())
            {
                // Log that validation has passed
                this.ExportResults.Add(new DBAppLog("Valid Export Object.."));
                _ExportDataTable.Table = SQLHelper.ExecuteDataTable(out outEx);
                // throw exception if we got one from SQL layer
                if (outEx != null)
                {
                    this.ExportResults.Add(new DBAppLog("Error Executing SQL Query.", outEx, DBLogTypeEnum.Error));
                    throw outEx;
                }
                else
                {
                    // log successful call to SQL
                    this.ExportResults.Add(new DBAppLog("Executed SQL Query Successfully!!"));

                    // create a file and export it
                    FileList = CreateFiles();
                    
                    // Flag success
                    this.ExportResults.Add(new DBAppLog("Created Files Successfully!!"));
                }
            }
            else
            {
                // log validation message
                this.ExportResults.Add(new DBAppLog("Invalid ExportToFile Object. Please check all Parameters/Validation Messages"));
            }

            // return
            return this.ExportResults;
        }

        public bool ExportDataReader()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Public Static Members

        /// <summary>
        /// Provides a list of Valid Date Formats allowed.
        /// </summary>
        /// <returns></returns>
        public static SortedDictionary<string, string> DateFormatStrings()
        {
            SortedDictionary<string, string> fileformatList = new SortedDictionary<string, string>();

            fileformatList.Add("None", "None");
            fileformatList.Add("MMddyyyyHHmmssfff", "MMddyyyyHHmmssfff");
            fileformatList.Add("MMddyyyyHHmmss", "MMddyyyyHHmmss");
            fileformatList.Add("MMddyyyy", "MMddyyyy");
            fileformatList.Add("yyyy-MM-dd", "yyyy-MM-dd");
            fileformatList.Add("yyyy-MM-dd HHmmssfff", "yyyy-MM-dd HHmmssfff");
            fileformatList.Add("yyyyMMdd", "yyyyMMdd");
            fileformatList.Add("yyyyMMddHHmmssfff", "yyyyMMddHHmmssfff");

            return fileformatList;
        }

        public static SortedDictionary<int, string>FileEncodingTypeStrings()
        {
            SortedDictionary<int, string> RetDictionary = new SortedDictionary<int, string>();

            foreach (System.Text.EncodingInfo e in System.Text.Encoding.GetEncodings())
            {
                if (ExportToFile.SupportedEncoding().Contains(e.DisplayName))
                    RetDictionary.Add(e.CodePage, e.DisplayName);
            }

            return RetDictionary;
        }

        private static List<string> SupportedEncoding()
        {
            List<string> AllowedEncodingList = new List<string>(10);
            AllowedEncodingList.Add("Unicode (UTF-7)");
            AllowedEncodingList.Add("Unicode (UTF-8)");
            AllowedEncodingList.Add("Unicode (Big-Endian)");
            AllowedEncodingList.Add("Unicode");
            AllowedEncodingList.Add("Unicode (UTF-32)");
            AllowedEncodingList.Add("US-ASCII");

            // return
            return AllowedEncodingList;
        }

        public static SortedDictionary<int, string> ExportToFileStrings()
        {
            SortedDictionary<int, string> RetDictionary = new SortedDictionary<int, string>();
            RetDictionary.Add((int)ExportToFileTypeEnum.csv, ".csv");
            RetDictionary.Add((int)ExportToFileTypeEnum.txt, ".txt");
            RetDictionary.Add((int)ExportToFileTypeEnum.json, ".json");

            return RetDictionary;
        }

        public static SortedDictionary<int, string> ColumnDelimiterStrings()
        {
            SortedDictionary<int, string> RetDictionary = new SortedDictionary<int, string>();
            RetDictionary.Add((int)ColumnDelimiter.NONE, "1.None");
            RetDictionary.Add((int)ColumnDelimiter.CarriageReturnLineFeed, "2.{CR}{LF}");
            RetDictionary.Add((int)ColumnDelimiter.CarriageReturn, "3.{CR}");
            RetDictionary.Add((int)ColumnDelimiter.LineFeed, "4.{LF}");
            RetDictionary.Add((int)ColumnDelimiter.Semicolon, "5.Semicolon {;}");
            RetDictionary.Add((int)ColumnDelimiter.Colon, "6.Colon {:}");
            RetDictionary.Add((int)ColumnDelimiter.Comma, "7.Comma {,}");
            RetDictionary.Add((int)ColumnDelimiter.Tab, "8.Tab {t}");
            RetDictionary.Add((int)ColumnDelimiter.VerticalBar, "9.Vertical Bar {|}");

            return RetDictionary;
        }

        public static SortedDictionary<int, string> RowDelimiterStrings()
        {
            SortedDictionary<int, string> RetDictionary = new SortedDictionary<int, string>();
            RetDictionary.Add((int)RowDelimiters.NONE, "1.None");
            RetDictionary.Add((int)RowDelimiters.CarriageReturnLineFeed, "2.{CR}{LF}");
            RetDictionary.Add((int)RowDelimiters.CarriageReturn, "3.{CR}");
            RetDictionary.Add((int)RowDelimiters.LineFeed, "4.{LF}");
            RetDictionary.Add((int)RowDelimiters.Semicolon, "5.Semicolon {;}");
            RetDictionary.Add((int)RowDelimiters.Colon, "6.Colon {:}");
            RetDictionary.Add((int)RowDelimiters.Comma, "7.Comma {,}");
            RetDictionary.Add((int)RowDelimiters.Tab, "8.Tab {t}");
            RetDictionary.Add((int)RowDelimiters.VerticalBar, "9.Vertical Bar {|}");

            return RetDictionary;
        }

        public static string ColumnDelimiterToString(ColumnDelimiter Coldelimiter)
        {
            string strRet = string.Empty;

            switch(Coldelimiter)
            {
                case ColumnDelimiter.CarriageReturnLineFeed:
                    strRet = System.Environment.NewLine;
                    break;
                case ColumnDelimiter.CarriageReturn:
                    strRet = "\r";
                    break;
                case ColumnDelimiter.LineFeed:
                    strRet = "\n";
                    break;
                case ColumnDelimiter.Semicolon:
                    strRet = ";";
                    break;
                case ColumnDelimiter.Colon:
                    strRet = ":";
                    break;
                case ColumnDelimiter.Comma:
                    strRet = ",";
                    break;
                case ColumnDelimiter.Tab:
                    strRet = "\t";
                    break;
                case ColumnDelimiter.VerticalBar:
                    strRet = "|";
                    break;
                default:
                    strRet = "";
                    break;
            }

            return strRet;
        }

        public static string RowDelimiterToString(RowDelimiters Rowdelimiter)
        {
            string strRet = string.Empty;

            switch (Rowdelimiter)
            {
                case RowDelimiters.CarriageReturnLineFeed:
                    strRet = System.Environment.NewLine;
                    break;
                case RowDelimiters.CarriageReturn:
                    strRet = "\r";
                    break;
                case RowDelimiters.LineFeed:
                    strRet = "\n";
                    break;
                case RowDelimiters.Semicolon:
                    strRet = ";";
                    break;
                case RowDelimiters.Colon:
                    strRet = ":";
                    break;
                case RowDelimiters.Comma:
                    strRet = ",";
                    break;
                case RowDelimiters.Tab:
                    strRet = "\t";
                    break;
                case RowDelimiters.VerticalBar:
                    strRet = "|";
                    break;
                default:
                    strRet = "";
                    break;
            }

            return strRet;
        }

        #endregion

        #region System Overloaded methods

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(250);
            if (SQLHelper != null)
                sb.AppendLine(SQLHelper.ToString());
            else
                sb.AppendLine("SQL Connector is null!!");

            sb.AppendLine("ExportToFile Parameters");
            sb.AppendLine(string.Format("AppendDateFormat:{0}", this.AppendDateFormat));
            sb.AppendLine(string.Format("BatchSize:{0}", this.BatchSize.ToString()));
            sb.AppendLine(string.Format("CompressionType:{0}", this.CompressionTypeToString));
            sb.AppendLine(string.Format("ExportToFileType:{0}", this.ExportToFileTypeToString));
            sb.AppendLine(string.Format("ColDelimiterChar:{0}", this.ColDelimiterString));
            sb.AppendLine(string.Format("RowDelimiterChar:{0}", this.RowDelimiterString));
            sb.AppendLine(string.Format("FileDateFormat:{0}", this.FileDateFormat));
            sb.AppendLine(string.Format("FileEncoding:{0}", this.FileEncodingString));
            sb.AppendLine(string.Format("FilePrefix:{0}", this.FilePrefix));
            sb.AppendLine(string.Format("IncludeHeaders:{0}", this.IncludeHeaders));
            sb.AppendLine(string.Format("IncludeTextQualifiers:{0}", this.IncludeTextQualifiers));
            sb.AppendLine(string.Format("SplitFiles:{0}", this.SplitFiles));
            sb.AppendLine(string.Format("StagingFile Location:{0}", this.StagingFileLocation));

            return sb.ToString();
        }

        #endregion

        #region Internal Methods
        internal string DataTableToString()
        {
            /*
                StringBuilder sb = new StringBuilder(); 

                IEnumerable<string> columnNames = dt.Columns.Cast<DataColumn>().
                                                  Select(column => column.ColumnName);
                sb.AppendLine(string.Join(",", columnNames));

                foreach (DataRow row in dt.Rows)
                {
                    IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                    sb.AppendLine(string.Join(",", fields));
                }

                File.WriteAllText("test.csv", sb.ToString());

                foreach (DataRow row in dt.Rows)
                {
                    IEnumerable<string> fields = row.ItemArray.Select(field => 
                      string.Concat("\"", field.ToString().Replace("\"", "\"\""), "\""));
                    sb.AppendLine(string.Join(",", fields));
                }
             */

            /*
            StringBuilder sbData = new StringBuilder(1000);
            string strTextQual = this.IncludeTextQualifiers ? "\"" : "";

            if (_ExportDataTable != null)
            {
                // Only return Null if there is no structure.
                if (_ExportDataTable.Columns.Count == 0)
                    return null;

                // Create Header if needed
                if (IncludeHeaders)
                {
                    foreach (var col in _ExportDataTable.Columns)
                    {
                        if (col == null)
                            sbData.Append(this.ColDelimiter);
                        else
                            // Text Qualify and Escape double quotes
                            sbData.Append(TextQualifyAndEscape(col));
                    }
                    
                    // Replace last Comma with New Line
                    sbData.Replace(this.ColDelimiter.ToString(), System.Environment.NewLine, sbData.Length - 1, 1);
                }


                // Convert column data into CSV/Txt rows.
                foreach (DataRow dr in _ExportDataTable.Rows)
                {
                    foreach (var column in dr.ItemArray)
                    {
                        if (column == null)
                            sbData.Append(this.ColDelimiter);
                        else
                            // Text Qualify and escapte double quotes
                            sbData.Append(TextQualifyAndEscape(column));
                    }
                    sbData.Replace(this.ColDelimiter.ToString(), System.Environment.NewLine, sbData.Length - 1, 1);
                }
            }

            // return string
            return sbData.ToString();

            */
            throw new NotImplementedException();
        }

        #endregion

        #region Hide constructors
        private ExportToFile()
        {
            _SQLConnector = null;

            InitializeExportToFile();
        }

        private ExportToFile(string TheServerName, string TheDBName, string TheScript, string TheUserName, string ThePassword)
        {
            IList<string> MsgList = null;
            _SQLConnector = SQLConnector.NewSQLConnector(TheServerName, TheDBName, TheScript, TheUserName, ThePassword, out MsgList);
            InitializeExportToFile();
        }

        private ExportToFile(string TheServerName, string TheDBName, string TheScript)
        {
            IList<string> MsgList = null;
            _SQLConnector = SQLConnector.NewSQLConnector(TheServerName, TheDBName, TheScript, out MsgList);
            InitializeExportToFile();
        }

        private ExportToFile(SQLConnector TheSQLConnector)
        {
            _SQLConnector = TheSQLConnector;
            InitializeExportToFile();
        }

        #endregion

        #region Private Fields

        private bool _IncludeHeader;
        private bool _IncludeTextQual;
        private ColumnDelimiter _ColumnDelimiter;
        private RowDelimiters _RowDelimiter;
        private bool _SplitFiles;
        private int _BatchSize;
        private FileCompressionTypeEnum _CompressionType;
        private string _FilePrefix;
        private string _FileStagingLocation;
        private string _DestinationLocation;
        private bool _AppendDateFormat;
        private string _FileDateFormatType;
        private ExportToFileTypeEnum _ExportToFile;
        private Encoding _Encoding;
        private SQLConnector _SQLConnector;
        private ExportDataTable _ExportDataTable;
        private DBAppLogList _ExportResultList = new DBAppLogList();

        #endregion

        #region Private Members

        /// <summary>
        /// Based on Data Table and configuration provided
        /// it creates all required files and compresses them if needed.
        /// </summary>
        /// <returns></returns>
        private ExportFileList CreateFiles()
        {
            ExportFileList exportFileList = null;

            if ((_ExportDataTable != null) && (_ExportDataTable.Table != null))
            {
                // How many files?
                // File Names.
                int intTotalRows = _ExportDataTable.Table.Rows.Count;
                int intBatchSize = 0;
                // Log Export Data Started
                this.ExportResults.Add(new DBAppLog("Export Data Started. Rows to export:" + intTotalRows.ToString()));
                
                // figure out batch size
                if (this.SplitFiles)
                {
                    intBatchSize = BatchSize;
                    this.ExportResults.Add(new DBAppLog("Exporting to Multiple files. BatchSize:" + intBatchSize.ToString()));
                }
                else // single file
                {
                    intBatchSize = intTotalRows;
                    this.ExportResults.Add(new DBAppLog("Exporting to Single file. BatchSize:" + intBatchSize.ToString()));
                }

                // Append Date format                    
                if (this.AppendDateFormat)
                    exportFileList = new ExportFileList(this.StagingFileLocation, this.FilePrefix, intTotalRows, intBatchSize, this.FileDateFormat, this.ExportToFileTypeToString, this.CompressionType);
                else
                    exportFileList = new ExportFileList(this.StagingFileLocation, this.FilePrefix, intTotalRows, intBatchSize, this.ExportToFileTypeToString, this.CompressionType);

                if (exportFileList != null)
                {
                    this.ExportResults.Add(new DBAppLog("# files to Export." + exportFileList.Count.ToString()));

                    // FOR EACH FILE
                    foreach (var e in exportFileList)
                    {
                        this.ExportResults.Add(new DBAppLog("Creating File:" + e.Value.ToString()));

                        // Add Encoding information if needed
                        // Create a new Stream
                        Encoding encoding = this.FileEncoding;

                        // change encoding for UTF-8
                        //if (this.FileEncoding == Encoding.UTF8)
                       //     encoding = new UTF8Encoding(false);

                        // Split the file writing into chunks in case it is too big.
                        int intChunkBatchSize = ExportToFile.ChunkSize;
                        if (e.Value.NoOfRows > intChunkBatchSize)
                        {
                            for (int intChunkStart = 1; intChunkStart <= e.Value.NoOfRows; )
                            {
                                // Dont add header for each batch
                                bool blnInclHeader = (intChunkStart == 1) ? this.IncludeHeaders : false;

                                // Rows to be added for each file.
                                using (MemoryStream memStream = _ExportDataTable.RowsToStream(ColDelimiterString, IncludeTextQualifiers, intChunkStart, intChunkBatchSize, encoding, blnInclHeader, RowDelimiterString))
                                {
                                    this.ExportResults.Add(new DBAppLog("Converting DataTable in chucks To File for file." + e.Value.FileName + "at rows:" + intChunkStart.ToString()));
                                    // write to file.
                                    ExportFileHelper.CreateFile(e.Value.FileName, memStream, this.CompressionType);
                                }

                                // next set
                                intChunkStart += intChunkBatchSize;
                            }
                        }
                        else
                        {
                            // Add Header for each file if needed
                            // Rows to be added for each file.
                            using (MemoryStream memStream = _ExportDataTable.RowsToStream(ColDelimiterString, IncludeTextQualifiers, e.Value.StartRow, e.Value.NoOfRows, encoding, this.IncludeHeaders, RowDelimiterString))
                            {
                                this.ExportResults.Add(new DBAppLog("Converted DataTable To File for file." + e.Value.FileName));
                                // write to file.
                                ExportFileHelper.CreateFile(e.Value.FileName, memStream, this.CompressionType);
                            }
                        }

                        // Verify file exists and delete
                        if (this.CompressionType == FileCompressionTypeEnum.None)
                        {
                            if (ExportFileHelper.CheckFileExists(e.Value.FileName))
                            {
                                // Mark as file created
                                e.Value.Created = true;
                                this.ExportResults.Add(new DBAppLog("File:" + e.Value.FileName + " exists"));
                            }
                            else
                            {
                                Exception fileNotFoundex = new FileNotFoundException("File didnt get created!", e.Value.FileName);
                                this.ExportResults.Add(new DBAppLog("File:" + e.Value.FileName + " DID NOT GET CREATED.", fileNotFoundex, DBLogTypeEnum.Error));
                            }
                        }
                        else 
                        {
                            if (ExportFileHelper.CheckFileExists(e.Value.CompressedFileName))
                            {
                                // Mark as file created
                                e.Value.Created = true;
                                // Mark as compressed
                                e.Value.Compressed = true;
                                this.ExportResults.Add(new DBAppLog("Compressed File:" + e.Value.CompressedFileName + " exists"));
                            }
                            else
                            {
                                Exception fileNotFoundex = new FileNotFoundException("File didnt get created!", e.Value.CompressedFileName);
                                this.ExportResults.Add(new DBAppLog("Compressed File:" + e.Value.CompressedFileName + " DID NOT GET CREATED.", fileNotFoundex, DBLogTypeEnum.Error));
                            }
                        }

                        // if file exists then export it
                        if ((e.Value.Created) && (this.DestinationLocation.Length > 0))
                        {
                            // copy file to destination
                            DBAppLog CopyResult = null;
                            if (e.Value.CompressionRequired)
                            {
                                this.ExportResults.Add(new DBAppLog("About to Move Compressed File"));
                                CopyResult = ExportFileHelper.CopyFileTo(e.Value.CompressedFileName, this.DestinationLocation);
                            }
                            else
                            {
                                this.ExportResults.Add(new DBAppLog("About to Move File"));
                                CopyResult = ExportFileHelper.CopyFileTo(e.Value.FileName, this.DestinationLocation);
                            }
                            // add restults
                            if (CopyResult != null)
                                this.ExportResults.Add(CopyResult);

                            // Copied file to destination
                            e.Value.ExportedFileName = string.Empty;
                            if ((CopyResult.LogException == null) && (CopyResult.LogMessageType != DBLogTypeEnum.Error))
                            {
                                if (!string.IsNullOrEmpty(StagingFileLocation))
                                {
                                    if (e.Value.Compressed)
                                        e.Value.ExportedFileName = e.Value.CompressedFileName.Replace(StagingFileLocation, "");
                                    else
                                        e.Value.ExportedFileName = e.Value.FileName.Replace(StagingFileLocation, "");
                                }
                                else
                                {
                                    if (e.Value.Compressed)
                                        e.Value.ExportedFileName =  e.Value.CompressedFileName;
                                    else
                                        e.Value.ExportedFileName = e.Value.FileName;
                                }
                                e.Value.ExportedFileName = DestinationLocation + e.Value.ExportedFileName;
                                e.Value.Exported = true;
                            }
                        }
                    }
                }
                else
                {
                    Exception ex = new InvalidDataException("Export File List is null");
                    this.ExportResults.Add(new DBAppLog("Export File List is null", ex, DBLogTypeEnum.Error));
                    throw ex;
                }
            }
            else
            {
                Exception ex = new ArgumentNullException("Data Table missing", "Data Table to export data is null");
                this.ExportResults.Add(new DBAppLog("SQL was executed by Data Table is NULL", ex, DBLogTypeEnum.Error));
                throw ex;
            }

            // return file list and status
            return exportFileList;
        }

        /// <summary>
        /// Is Valid used for internal validation before 
        /// exporting
        /// </summary>
        /// <returns></returns>
        private bool IsValid()
        {
            bool RetVal = false;
            IList<string> ValidationMessageList = null;
            RetVal = this.IsValid(out ValidationMessageList);

            AddValidationMsgToResults(ValidationMessageList);

            // return results
            return RetVal;
        }

        private void AddValidationMsgToResults(IList<string> ValidationMessageList)
        {
            if ((ValidationMessageList != null) && (ValidationMessageList.Count > 0))
                foreach (string s in ValidationMessageList)
                    this.ExportResults.Add(new DBAppLog(s, DBLogTypeEnum.ValidationMessage));
        }

        /// <summary>
        /// Initialize the object with default values
        /// </summary>
        private void InitializeExportToFile()
        {
            this._SplitFiles = false;
            this.BatchSize = 100000;

            this.CompressionType = FileCompressionTypeEnum.None;
            this.ExportToFileType = ExportToFileTypeEnum.csv;
            this.ColDelimiter = ColumnDelimiter.Comma;
            this.RowDelimiter = RowDelimiters.CarriageReturnLineFeed;

            this.AppendDateFormat = false;
            this.FileDateFormat = DateFormatStrings()["None"];

            this.FilePrefix = string.Empty;
            this.StagingFileLocation = string.Empty;
            this.DestinationLocation = string.Empty;
            this.IncludeHeaders = true;
            this.IncludeTextQualifiers = true;

            this._ExportDataTable = new ExportDataTable();
        }


        /// <summary>
        /// Text Qualify if needed and escape double quotes
        /// </summary>
        /// <param name="TheColumn"></param>
        /// <returns></returns>
        private string TextQualifyAndEscape(object TheColumn)
        {
            string strTextQual = this.IncludeTextQualifiers ? "\"" : "";
            return strTextQual + TheColumn.ToString().Replace("\"", "\"\"") + strTextQual + this.ColDelimiterString;
        }

        #endregion
    
    }
}
