﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common.ExportToFile
{
    public enum FileCompressionTypeEnum
    {
        None = 0,
        gzip
        //zip ,
        //lzop
    }

    public enum ExportToFileTypeEnum
    {
        csv = 0,
        txt,
        json
    }

    public enum FileEncodingTypeEnum
    {
        None = 0,
        UTF8
    }

    public enum ColumnDelimiter
    {
         NONE = 0
        ,CarriageReturnLineFeed
        ,CarriageReturn
        ,LineFeed
        ,Semicolon
        ,Colon
        ,Comma
        ,Tab
        ,VerticalBar
    }

    public enum RowDelimiters
    {
         NONE = 0
        ,CarriageReturnLineFeed
        ,CarriageReturn
        ,LineFeed
        ,Semicolon
        ,Colon
        ,Comma
        ,Tab
        ,VerticalBar
    }

    public class ExportToFileCommon
    {
        public static SortedDictionary<int, string> CompressionFileTypeStrings()
        {
            SortedDictionary<int, string> FileCmpDictionary = new SortedDictionary<int, string>();
            FileCmpDictionary.Add((int)FileCompressionTypeEnum.None, "None");
            FileCmpDictionary.Add((int)FileCompressionTypeEnum.gzip, ".gz");
            //FileCmpDictionary.Add((int)FileCompressionTypeEnum.lzop, ".lzop");
            //FileCmpDictionary.Add((int)FileCompressionTypeEnum.zip, ".zip" );

            return FileCmpDictionary;
        }
    }
}
