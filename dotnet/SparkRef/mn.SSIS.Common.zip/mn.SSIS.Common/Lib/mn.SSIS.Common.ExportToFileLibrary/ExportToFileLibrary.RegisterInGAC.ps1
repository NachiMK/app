#
# mn.SSIS.Common.ExportToFileLibrary.ps1
# Script to register this Assembly in GAC

#Load System.EnterpriseServices assembly as it contain classes to handle GAC
[Reflection.Assembly]::LoadWithPartialName("System.EnterpriseServices")
 
#Create instance of Publish class which can handle GAC Installation and/or removal
[System.EnterpriseServices.Internal.Publish] $publish = new-object System.EnterpriseServices.Internal.Publish;

#Install mn.SSIS.Common.dll into GAC using GacInstall method (Provide full path to the assembly - Usually our assemblies are save in C:\Matchnet folder)
$publish.GacInstall("C:\Matchnet\mn.SSIS.Common\mn.SSIS.Common.dll");
 
#Install mn.SSIS.Common.ExportToFileLibrary.dll into GAC using GacInstall method (Provide full path to the assembly) - Usually our assemblies are save in C:\Matchnet folder
$publish.GacRemove("C:\Matchnet\mn.SSIS.Common\mn.SSIS.Common.ExportToFileLibrary.dll");
$publish.GacInstall("C:\Matchnet\mn.SSIS.Common\mn.SSIS.Common.ExportToFileLibrary.dll");
