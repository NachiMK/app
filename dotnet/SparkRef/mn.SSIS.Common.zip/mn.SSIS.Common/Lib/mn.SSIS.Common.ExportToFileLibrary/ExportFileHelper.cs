﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common.ExportToFile
{
    public static class ExportFileHelper
    {
        public static void CreateFile(string FileName, StringBuilder DataToWrite)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Writes a given Memory stream into a file.
        /// </summary>
        /// <param name="FilEncoding"></param>
        /// <param name="FileName"></param>
        /// <param name="DataToWrite"></param>
        public static void CreateFile(string FileName, MemoryStream DataMemoryStream, FileCompressionTypeEnum CompressionType)
        {
            // get compression file extension
            string compressedFileExt = ExportToFileCommon.CompressionFileTypeStrings()[(int)CompressionType];

            // DataMemoryStream.Position = 0;
            // return File(DataMemoryStream, "text/plain", FileName);
            if (DataMemoryStream == null)
                DataMemoryStream = new MemoryStream();
            // Create File
            try
            {
                // open a File Stream
                if (CompressionType == FileCompressionTypeEnum.None)
                {
                    using (FileStream fs = new FileStream(FileName, FileMode.Append, FileAccess.Write))
                    {
                        //Write data in memory to file.
                        DataMemoryStream.WriteTo(fs);
                    }
                }
                else if (CompressionType == FileCompressionTypeEnum.gzip)
                {
                    // open compressed file
                    string strFileName = FileName + compressedFileExt;
                    using (FileStream compressedFStream = new FileStream(strFileName, FileMode.Append, FileAccess.Write))
                    //using (FileStream compressedFileStream = File.Create(FileName + compressedFileExt))
                    {
                        // compressions stream
                        using (GZipStream compressionStream = new GZipStream(compressedFStream, CompressionMode.Compress))
                        {
                            // write and compress at the same time
                            DataMemoryStream.WriteTo(compressionStream);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                DataMemoryStream.Dispose();
                throw ex;
            }
        }

        public static void CompressFile(string FileName, FileCompressionTypeEnum CompressionType)
        {
            // get file details for file to be compressed
            FileInfo fileToCompress = new FileInfo(FileName);

            // get compression file extension
            string compressedFileExt = ExportToFileCommon.CompressionFileTypeStrings()[(int)CompressionType];

            // open the given file as a stream
            using (FileStream originalFileStream = new FileStream(FileName, FileMode.Open, FileAccess.Read))
            {
                // open a compression file
                using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + compressedFileExt))
                {
                    // open a gzip stream
                    using (GZipStream compressionStream = new GZipStream(compressedFileStream,
                        CompressionMode.Compress))
                    {
                        // write to compressed stream
                        originalFileStream.CopyTo(compressionStream);
                    } // auto close
                } // auto close
            }
        }

        /// <summary>
        /// Makes sure both source and destination file exists and if it 
        /// does it will copy it.
        /// 
        /// Once source file is copied. It is automatically deleted from source.
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="DestinationPath"></param>
        public static DBAppLog CopyFileTo(string FileName, string DestinationPath)
        {
            return CopyFileTo(FileName, DestinationPath, true, true);
        }

        /// <summary>
        /// Checks to see if source file and desitnation path exists. If
        /// exists then the file is copied.
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="DestinationPath"></param>
        /// <param name="DeleteAfterCopy">If true then the source file is deleted after successfully copying file</param>
        /// <param name="Overwrite">If true and if the file already exists in destination it will overwritten with source file. if false no action is taken</param>
        /// <returns>ExportResult will contain any exception happened. if File or path doesnt exists then file or path not found error is returned.</returns>
        public static DBAppLog CopyFileTo(string FileName, string DestinationPath, bool DeleteAfterCopy, bool Overwrite)
        {
            DBAppLog retExportResult = null;
            // Check if source file exists
            if (CheckFileExists(FileName))
            {
                // check if desitnation path exists
                if (CheckDirectoryExists(DestinationPath))
                {
                    string strSlash = (DestinationPath.Substring(DestinationPath.Length - 1, 1) == "\\") ? "" : "\\";
                    // get just file name from given full path name
                    string strFileName = Path.GetFileName(FileName);
                    // create destination file path
                    string strDestinationFile = Path.Combine(DestinationPath, strFileName);
                    bool DestFileExists = CheckFileExists(strDestinationFile) ;
                    try
                    {
                        // check if file already exists in desitnation
                        if (((DestFileExists) && (Overwrite)) || (!DestFileExists))
                        {
                            // copy file
                            File.Copy(FileName, strDestinationFile, Overwrite);

                            // check if file exists
                            if (CheckFileExists(strDestinationFile))
                            {
                                // setup success message
                                retExportResult = new DBAppLog(string.Format("Copied File {0} to {1} successfully", FileName, strDestinationFile), DBLogTypeEnum.Info);
                                // delete source file
                                if (DeleteAfterCopy)
                                    File.Delete(FileName);
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        // catch and return exception
                        retExportResult = new DBAppLog(string.Format("Copying File {0} to {1} Failed", FileName, strDestinationFile), ex, DBLogTypeEnum.Error);
                    }

                }
                else 
                {
                    // return error if Destination path not found in source
                    retExportResult = new DBAppLog("Destination path:" + DestinationPath + " not found.", new DirectoryNotFoundException(), DBLogTypeEnum.Error);
                }
            }
            else
            {
                // return error if file not found in source
                retExportResult = new DBAppLog("Source File:" + FileName + " not found", new FileNotFoundException(), DBLogTypeEnum.Error);
            }

            // return
            return retExportResult;
        }

        /// <summary>
        /// returns true if file exists.
        /// If any errors occur then false is returend
        /// </summary>
        /// <param name="FileName"></param>
        /// <returns></returns>
        public static bool CheckFileExists(string FileName)
        {
            bool retVal = false;
            try
            {
                // if given file name is empty string return false. no point in checking
                if (string.IsNullOrEmpty(FileName))
                    retVal = false;
                // if given file name is empty string return false. no point in checking
                else if (FileName.Length == 0)
                    retVal = false;
                else if (File.Exists(FileName))
                    retVal = true;
            }
            catch
            {
                retVal = false;
            }
            return retVal;
        }

        /// <summary>
        /// returns true if directory exists.
        /// If any errors occur then false is returend
        /// </summary>
        /// <param name="DirectoryPath"></param>
        /// <returns></returns>
        public static bool CheckDirectoryExists(string DirectoryPath)
        {
            bool retVal = false;
            try
            {
                // if given file name is empty string return false. no point in checking
                if (string.IsNullOrEmpty(DirectoryPath))
                    retVal = false;
                // if given file name is empty string return false. no point in checking
                else if (DirectoryPath.Length == 0)
                    retVal = false;
                // check if exists
                else if (Directory.Exists(DirectoryPath))
                    retVal = true;
            }
            catch
            {
                retVal = false;
            }
            return retVal;
        }

    }
}
