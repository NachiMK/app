﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mn.SSIS.Common.ExportToFile
{
    public class ExportFile
    {
        public string FileName { get; set; }
        public int StartRow { get; set; }
        public int EndRow { get; set; }
        public int NoOfRows 
        { 
            get 
            {
                int rowCount = 0;
                if (EndRow > StartRow)
                    rowCount = (EndRow - StartRow) + 1;
                else
                    rowCount = EndRow;
                // return
                return rowCount;
            } 
        }
        public bool Created { get; set; }
        public bool Compressed { get; set; }
        public bool Exported { get; set; }
        public string ExportedFileName { get; set; }

        public string CompressedFileName 
        { 
            get
            {
                if (CompressionType == FileCompressionTypeEnum.None)
                    return string.Empty;
                else
                    return this.FileName + ExportToFileCommon.CompressionFileTypeStrings()[(int)CompressionType];
            }
        }
        public FileCompressionTypeEnum CompressionType { get; set; }
        public bool CompressionRequired
        {
            get
            {
                return (this.CompressionType != FileCompressionTypeEnum.None) ? true : false;
            }
        }

        #region Constructor

        internal ExportFile(string fileName, int startRow, int endRow, FileCompressionTypeEnum CompressType)
        {
            NewExportFile(fileName, startRow, endRow, CompressType);
        }

        public ExportFile(string filePrefix, string FileExtension)
        {
            string strFileName = filePrefix + FileExtension;
            NewExportFile(strFileName, -1, -1, FileCompressionTypeEnum.None);
        }

        public ExportFile(string filePrefix, string appendDateFormat, string fileExtension)
        {
            string strFileName = filePrefix + DateTime.Now.ToString(appendDateFormat) + fileExtension;
            NewExportFile(strFileName, -1, -1, FileCompressionTypeEnum.None);
        }

        public ExportFile(string filePrefix, string appendDateFormat, string fileExtension, FileCompressionTypeEnum CompressType)
        {
            // update file name
            string strFileName = filePrefix + DateTime.Now.ToString(appendDateFormat) + fileExtension;
            NewExportFile(strFileName, -1, -1, CompressType);
        }

        #endregion

        #region private members

        private void NewExportFile(string fileName, int startRow, int endRow, FileCompressionTypeEnum CompressType)
        {
            this.FileName = fileName;
            this.StartRow = startRow;
            this.EndRow = endRow;
            //default flags
            this.Compressed = false;
            this.Created = false;
            this.Exported = false;
            this.CompressionType = CompressType;
        }

        private void InitializeExportFile()
        {
            this.FileName = string.Empty;
            this.StartRow = -1;
            this.EndRow = -1;
            this.Compressed = false;
            this.Created = false;
            this.Exported = false;
        }

        #endregion

        #region public overrides

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(100);
            sb.AppendLine(string.Format("FileName :{0}", this.FileName));
            sb.AppendLine(string.Format("StartRow:{0}", this.StartRow.ToString()));
            sb.AppendLine(string.Format("EndRow:{0}", this.EndRow.ToString()));
            sb.AppendLine(string.Format("Created:{0}", this.Created));
            sb.AppendLine(string.Format("Compressed:{0}", this.Compressed));
            sb.AppendLine(string.Format("Exported:{0}", this.Exported));
            sb.AppendLine(string.Format("CompressedFileName:{0}", this.CompressedFileName));

            return sb.ToString();
        }

        #endregion
    }


    public class ExportFileList : SortedDictionary<int, ExportFile>
    {
        #region constructors

        internal ExportFileList() : base()
        { }

        /// <summary>
        /// Creates required number of Export File objects and populates with default values
        /// by default all files will have a unique sequence number at the end.
        /// </summary>
        /// <param name="filePrefix">Prefix you want to specify for the file</param>
        /// <param name="totalRows">Total # of rows in the entire export</param>
        /// <param name="batchSize"># of rows per batch</param>
        /// <param name="appenDateFormat">Date time format to append to file name</param>
        /// <param name="fileExtension"></param>
        public ExportFileList(string filePath, string filePrefix, int totalRows, int batchSize, string appenDateFormat, string fileExtension, FileCompressionTypeEnum CompressType)
        {
            int intKey = 1;
            // should we append date format
            bool AppendDateFlag = ((!string.IsNullOrEmpty(appenDateFormat)) && (appenDateFormat.Length > 0)) ? true : false;
            if (totalRows > 0)
            {
                for (int intIdx = 1; intIdx <= totalRows; intIdx = intIdx + batchSize)
                {
                    // get file name
                    string strDate = AppendDateFlag ? ExportHelper.GetFormattedDate(appenDateFormat, 2) : string.Empty;
                    string strFileName = filePrefix + strDate + "." + intKey.ToString() + fileExtension;
                    strFileName = System.IO.Path.Combine(filePath, strFileName);
                    // get end row
                    int intEndRow = intIdx + batchSize - 1;
                    // if end row spills more than total rows then reset it to total rows.
                    intEndRow = (totalRows < intEndRow) ? totalRows : intEndRow;
                    // add export file object
                    this.Add(intKey, new ExportFile(strFileName, intIdx, intEndRow, CompressType));
                    intKey++;
                }
            }
        }

        /// <summary>
        /// Creates required number of export files objects without appending date format to file name
        /// </summary>
        /// <param name="filePrefix"></param>
        /// <param name="totalRows"></param>
        /// <param name="batchSize"></param>
        /// <param name="fileExtension"></param>
        public ExportFileList(string filePath, string filePrefix, int totalRows, int batchSize, string fileExtension)
            : this(filePath, filePrefix, totalRows, batchSize, string.Empty, fileExtension, FileCompressionTypeEnum.None)
        {
        }

        public ExportFileList(string filePath, string filePrefix, int totalRows, int batchSize, string fileExtension, FileCompressionTypeEnum CompressType)
            : this(filePath, filePrefix, totalRows, batchSize, string.Empty, fileExtension, CompressType)
        {
        }

        #endregion

        #region public object overriders

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(100);

            sb.AppendLine(string.Format("ExportFileList, No of items:{0}", this.Count.ToString()));
            // loop throug and add string
            foreach(var obj in this)
            {
                sb.AppendLine(string.Format("Export File Key:{0}", obj.Key.ToString()));
                sb.AppendLine(obj.Value.ToString());
            }
            
            return sb.ToString();
        }

        #endregion
    }

    static class ExportHelper
    { 
        /// <summary>
        /// This method returns a Date Time formatted in given
        /// format. It can wait for a few milliseconds before generating a Date time string.
        /// 
        /// Useful if using the timestamp to generate a unique file.
        /// </summary>
        /// <param name="DateFormatString"></param>
        /// <returns></returns>
        public static string GetFormattedDate(string DateFormatString, short MillisecondsToWait)
        {
            System.Threading.Thread.Sleep(MillisecondsToWait);
            return DateTime.Now.ToString(DateFormatString);
        }

        /// <summary>
        /// Gives a date formatted string as per format
        /// without waiting.
        /// </summary>
        /// <param name="DateFormatString"></param>
        /// <returns></returns>
        public static string GetFormattedDate(string DateFormatString)
        {
            return ExportHelper.GetFormattedDate(DateFormatString, 0);
        }
    }
}
