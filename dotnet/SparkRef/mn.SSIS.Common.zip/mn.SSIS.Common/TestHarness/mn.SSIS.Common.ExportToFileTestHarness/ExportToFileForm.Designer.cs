﻿namespace mn.SSIS.Common.ExportToFile.TestHarness
{
    partial class ExportToFileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.IncludeHeaderChkBox = new System.Windows.Forms.CheckBox();
            this.ServerNameTxtBox = new System.Windows.Forms.TextBox();
            this.UserNameTxtBox = new System.Windows.Forms.TextBox();
            this.PasswordTxtBox = new System.Windows.Forms.TextBox();
            this.TextQualChkBox = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DBNameTxtBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.BatchSizeNumUpDwn = new System.Windows.Forms.NumericUpDown();
            this.IntegratedSecurityChkBox = new System.Windows.Forms.CheckBox();
            this.CompressTypeCbBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.StageLocationTxtBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.FileNamePrefixTxtBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.FileDateFormatCbBox = new System.Windows.Forms.ComboBox();
            this.SQLTxtBox = new System.Windows.Forms.TextBox();
            this.ResultsDataGridVw = new System.Windows.Forms.DataGridView();
            this.ResultsTxtBox = new System.Windows.Forms.TextBox();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DestinationTextBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.AppendDtFormatChkBox = new System.Windows.Forms.CheckBox();
            this.MultipleFileRdBtn = new System.Windows.Forms.RadioButton();
            this.SingleFileRdBtn = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.EncodingTypeCbBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.FileTypeCbBox = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ExportBtn = new System.Windows.Forms.Button();
            this.ViewDataBtn = new System.Windows.Forms.Button();
            this.TestConnBtn = new System.Windows.Forms.Button();
            this.ColDelimiterCbBox = new System.Windows.Forms.ComboBox();
            this.RowDelimiterCbBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BatchSizeNumUpDwn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResultsDataGridVw)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(280, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Database Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "User Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(280, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "SQL Script";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 540);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 16);
            this.label6.TabIndex = 16;
            this.label6.Text = "Data Grid";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(8, 794);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 16);
            this.label7.TabIndex = 18;
            this.label7.Text = "Results";
            // 
            // IncludeHeaderChkBox
            // 
            this.IncludeHeaderChkBox.AutoSize = true;
            this.IncludeHeaderChkBox.Location = new System.Drawing.Point(15, 22);
            this.IncludeHeaderChkBox.Name = "IncludeHeaderChkBox";
            this.IncludeHeaderChkBox.Size = new System.Drawing.Size(110, 17);
            this.IncludeHeaderChkBox.TabIndex = 0;
            this.IncludeHeaderChkBox.Text = "Include Headers?";
            this.IncludeHeaderChkBox.UseVisualStyleBackColor = true;
            // 
            // ServerNameTxtBox
            // 
            this.ServerNameTxtBox.Location = new System.Drawing.Point(113, 7);
            this.ServerNameTxtBox.Name = "ServerNameTxtBox";
            this.ServerNameTxtBox.Size = new System.Drawing.Size(161, 20);
            this.ServerNameTxtBox.TabIndex = 1;
            // 
            // UserNameTxtBox
            // 
            this.UserNameTxtBox.Location = new System.Drawing.Point(113, 32);
            this.UserNameTxtBox.Name = "UserNameTxtBox";
            this.UserNameTxtBox.Size = new System.Drawing.Size(161, 20);
            this.UserNameTxtBox.TabIndex = 6;
            // 
            // PasswordTxtBox
            // 
            this.PasswordTxtBox.Location = new System.Drawing.Point(407, 32);
            this.PasswordTxtBox.Name = "PasswordTxtBox";
            this.PasswordTxtBox.Size = new System.Drawing.Size(138, 20);
            this.PasswordTxtBox.TabIndex = 8;
            // 
            // TextQualChkBox
            // 
            this.TextQualChkBox.AutoSize = true;
            this.TextQualChkBox.Location = new System.Drawing.Point(15, 45);
            this.TextQualChkBox.Name = "TextQualChkBox";
            this.TextQualChkBox.Size = new System.Drawing.Size(94, 17);
            this.TextQualChkBox.TabIndex = 1;
            this.TextQualChkBox.Text = "Text Qualifier?";
            this.TextQualChkBox.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(163, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Col. Delimiter";
            // 
            // DBNameTxtBox
            // 
            this.DBNameTxtBox.Location = new System.Drawing.Point(407, 6);
            this.DBNameTxtBox.Name = "DBNameTxtBox";
            this.DBNameTxtBox.Size = new System.Drawing.Size(138, 20);
            this.DBNameTxtBox.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(21, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Rows in File:";
            // 
            // BatchSizeNumUpDwn
            // 
            this.BatchSizeNumUpDwn.Increment = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.BatchSizeNumUpDwn.Location = new System.Drawing.Point(174, 129);
            this.BatchSizeNumUpDwn.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.BatchSizeNumUpDwn.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BatchSizeNumUpDwn.Name = "BatchSizeNumUpDwn";
            this.BatchSizeNumUpDwn.Size = new System.Drawing.Size(109, 20);
            this.BatchSizeNumUpDwn.TabIndex = 9;
            this.BatchSizeNumUpDwn.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // IntegratedSecurityChkBox
            // 
            this.IntegratedSecurityChkBox.AutoSize = true;
            this.IntegratedSecurityChkBox.Location = new System.Drawing.Point(560, 7);
            this.IntegratedSecurityChkBox.Name = "IntegratedSecurityChkBox";
            this.IntegratedSecurityChkBox.Size = new System.Drawing.Size(115, 17);
            this.IntegratedSecurityChkBox.TabIndex = 4;
            this.IntegratedSecurityChkBox.Text = "Integrated Security";
            this.IntegratedSecurityChkBox.UseVisualStyleBackColor = true;
            this.IntegratedSecurityChkBox.CheckedChanged += new System.EventHandler(this.IntegratedSecurityChkBox_CheckedChanged);
            // 
            // CompressTypeCbBox
            // 
            this.CompressTypeCbBox.FormattingEnabled = true;
            this.CompressTypeCbBox.Location = new System.Drawing.Point(288, 66);
            this.CompressTypeCbBox.Name = "CompressTypeCbBox";
            this.CompressTypeCbBox.Size = new System.Drawing.Size(127, 21);
            this.CompressTypeCbBox.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(161, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "Compress Type";
            // 
            // StageLocationTxtBox
            // 
            this.StageLocationTxtBox.Location = new System.Drawing.Point(142, 17);
            this.StageLocationTxtBox.Name = "StageLocationTxtBox";
            this.StageLocationTxtBox.Size = new System.Drawing.Size(276, 20);
            this.StageLocationTxtBox.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Stage Location";
            // 
            // FileNamePrefixTxtBox
            // 
            this.FileNamePrefixTxtBox.Location = new System.Drawing.Point(174, 103);
            this.FileNamePrefixTxtBox.Name = "FileNamePrefixTxtBox";
            this.FileNamePrefixTxtBox.Size = new System.Drawing.Size(109, 20);
            this.FileNamePrefixTxtBox.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(21, 104);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(149, 16);
            this.label12.TabIndex = 6;
            this.label12.Text = "File Name Starts As:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(309, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "Date Format";
            // 
            // FileDateFormatCbBox
            // 
            this.FileDateFormatCbBox.FormattingEnabled = true;
            this.FileDateFormatCbBox.Location = new System.Drawing.Point(312, 129);
            this.FileDateFormatCbBox.Name = "FileDateFormatCbBox";
            this.FileDateFormatCbBox.Size = new System.Drawing.Size(127, 21);
            this.FileDateFormatCbBox.TabIndex = 12;
            // 
            // SQLTxtBox
            // 
            this.SQLTxtBox.Location = new System.Drawing.Point(12, 241);
            this.SQLTxtBox.MaxLength = 327670;
            this.SQLTxtBox.Multiline = true;
            this.SQLTxtBox.Name = "SQLTxtBox";
            this.SQLTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SQLTxtBox.Size = new System.Drawing.Size(991, 296);
            this.SQLTxtBox.TabIndex = 15;
            // 
            // ResultsDataGridVw
            // 
            this.ResultsDataGridVw.AllowUserToAddRows = false;
            this.ResultsDataGridVw.AllowUserToDeleteRows = false;
            this.ResultsDataGridVw.AllowUserToOrderColumns = true;
            this.ResultsDataGridVw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ResultsDataGridVw.Location = new System.Drawing.Point(12, 560);
            this.ResultsDataGridVw.Name = "ResultsDataGridVw";
            this.ResultsDataGridVw.ReadOnly = true;
            this.ResultsDataGridVw.Size = new System.Drawing.Size(991, 231);
            this.ResultsDataGridVw.TabIndex = 17;
            // 
            // ResultsTxtBox
            // 
            this.ResultsTxtBox.Location = new System.Drawing.Point(8, 813);
            this.ResultsTxtBox.MaxLength = 327670;
            this.ResultsTxtBox.Multiline = true;
            this.ResultsTxtBox.Name = "ResultsTxtBox";
            this.ResultsTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ResultsTxtBox.Size = new System.Drawing.Size(993, 163);
            this.ResultsTxtBox.TabIndex = 19;
            // 
            // CloseBtn
            // 
            this.CloseBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseBtn.Location = new System.Drawing.Point(925, 980);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(75, 23);
            this.CloseBtn.TabIndex = 21;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(844, 980);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(75, 23);
            this.ResetBtn.TabIndex = 20;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DestinationTextBox);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.AppendDtFormatChkBox);
            this.groupBox1.Controls.Add(this.MultipleFileRdBtn);
            this.groupBox1.Controls.Add(this.SingleFileRdBtn);
            this.groupBox1.Controls.Add(this.FileNamePrefixTxtBox);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.StageLocationTxtBox);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.FileDateFormatCbBox);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.BatchSizeNumUpDwn);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(12, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(445, 160);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Output File Options";
            // 
            // DestinationTextBox
            // 
            this.DestinationTextBox.Location = new System.Drawing.Point(142, 44);
            this.DestinationTextBox.Name = "DestinationTextBox";
            this.DestinationTextBox.Size = new System.Drawing.Size(276, 20);
            this.DestinationTextBox.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 45);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 16);
            this.label16.TabIndex = 2;
            this.label16.Text = "Final Destination";
            // 
            // AppendDtFormatChkBox
            // 
            this.AppendDtFormatChkBox.AutoSize = true;
            this.AppendDtFormatChkBox.Location = new System.Drawing.Point(297, 71);
            this.AppendDtFormatChkBox.Name = "AppendDtFormatChkBox";
            this.AppendDtFormatChkBox.Size = new System.Drawing.Size(130, 17);
            this.AppendDtFormatChkBox.TabIndex = 10;
            this.AppendDtFormatChkBox.Text = "Append Date Format?";
            this.AppendDtFormatChkBox.UseVisualStyleBackColor = true;
            this.AppendDtFormatChkBox.CheckedChanged += new System.EventHandler(this.AppendDtFormatChkBox_CheckedChanged);
            // 
            // MultipleFileRdBtn
            // 
            this.MultipleFileRdBtn.AutoSize = true;
            this.MultipleFileRdBtn.Location = new System.Drawing.Point(101, 74);
            this.MultipleFileRdBtn.Name = "MultipleFileRdBtn";
            this.MultipleFileRdBtn.Size = new System.Drawing.Size(85, 17);
            this.MultipleFileRdBtn.TabIndex = 5;
            this.MultipleFileRdBtn.TabStop = true;
            this.MultipleFileRdBtn.Text = "Multiple Files";
            this.MultipleFileRdBtn.UseVisualStyleBackColor = true;
            this.MultipleFileRdBtn.CheckedChanged += new System.EventHandler(this.MultipleFileRdBtn_CheckedChanged);
            // 
            // SingleFileRdBtn
            // 
            this.SingleFileRdBtn.AutoSize = true;
            this.SingleFileRdBtn.Location = new System.Drawing.Point(21, 74);
            this.SingleFileRdBtn.Name = "SingleFileRdBtn";
            this.SingleFileRdBtn.Size = new System.Drawing.Size(73, 17);
            this.SingleFileRdBtn.TabIndex = 4;
            this.SingleFileRdBtn.TabStop = true;
            this.SingleFileRdBtn.Text = "Single File";
            this.SingleFileRdBtn.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(163, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 16);
            this.label14.TabIndex = 10;
            this.label14.Text = "Encoding";
            // 
            // EncodingTypeCbBox
            // 
            this.EncodingTypeCbBox.FormattingEnabled = true;
            this.EncodingTypeCbBox.Location = new System.Drawing.Point(288, 93);
            this.EncodingTypeCbBox.Name = "EncodingTypeCbBox";
            this.EncodingTypeCbBox.Size = new System.Drawing.Size(127, 21);
            this.EncodingTypeCbBox.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RowDelimiterCbBox);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.ColDelimiterCbBox);
            this.groupBox2.Controls.Add(this.FileTypeCbBox);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.TextQualChkBox);
            this.groupBox2.Controls.Add(this.EncodingTypeCbBox);
            this.groupBox2.Controls.Add(this.IncludeHeaderChkBox);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.CompressTypeCbBox);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(470, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 129);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Optional Properties";
            // 
            // FileTypeCbBox
            // 
            this.FileTypeCbBox.FormattingEnabled = true;
            this.FileTypeCbBox.Location = new System.Drawing.Point(15, 90);
            this.FileTypeCbBox.Name = "FileTypeCbBox";
            this.FileTypeCbBox.Size = new System.Drawing.Size(127, 21);
            this.FileTypeCbBox.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 16);
            this.label15.TabIndex = 2;
            this.label15.Text = "File Type";
            // 
            // ExportBtn
            // 
            this.ExportBtn.Location = new System.Drawing.Point(924, 128);
            this.ExportBtn.Name = "ExportBtn";
            this.ExportBtn.Size = new System.Drawing.Size(75, 52);
            this.ExportBtn.TabIndex = 13;
            this.ExportBtn.Text = "Export";
            this.ExportBtn.UseVisualStyleBackColor = true;
            this.ExportBtn.Click += new System.EventHandler(this.ExportBtn_Click);
            // 
            // ViewDataBtn
            // 
            this.ViewDataBtn.Location = new System.Drawing.Point(923, 72);
            this.ViewDataBtn.Name = "ViewDataBtn";
            this.ViewDataBtn.Size = new System.Drawing.Size(75, 46);
            this.ViewDataBtn.TabIndex = 12;
            this.ViewDataBtn.Text = "View";
            this.ViewDataBtn.UseVisualStyleBackColor = true;
            this.ViewDataBtn.Click += new System.EventHandler(this.ViewDataBtn_Click);
            // 
            // TestConnBtn
            // 
            this.TestConnBtn.Location = new System.Drawing.Point(560, 29);
            this.TestConnBtn.Name = "TestConnBtn";
            this.TestConnBtn.Size = new System.Drawing.Size(124, 23);
            this.TestConnBtn.TabIndex = 9;
            this.TestConnBtn.Text = "Test Connection";
            this.TestConnBtn.UseVisualStyleBackColor = true;
            this.TestConnBtn.Click += new System.EventHandler(this.TestConnBtn_Click);
            // 
            // ColDelimiterCbBox
            // 
            this.ColDelimiterCbBox.FormattingEnabled = true;
            this.ColDelimiterCbBox.Location = new System.Drawing.Point(288, 14);
            this.ColDelimiterCbBox.Name = "ColDelimiterCbBox";
            this.ColDelimiterCbBox.Size = new System.Drawing.Size(127, 21);
            this.ColDelimiterCbBox.TabIndex = 5;
            // 
            // RowDelimiterCbBox
            // 
            this.RowDelimiterCbBox.FormattingEnabled = true;
            this.RowDelimiterCbBox.Location = new System.Drawing.Point(288, 40);
            this.RowDelimiterCbBox.Name = "RowDelimiterCbBox";
            this.RowDelimiterCbBox.Size = new System.Drawing.Size(127, 21);
            this.RowDelimiterCbBox.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(163, 44);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 16);
            this.label17.TabIndex = 6;
            this.label17.Text = "Row Delimiter";
            // 
            // ExportToFileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CloseBtn;
            this.ClientSize = new System.Drawing.Size(1008, 1012);
            this.Controls.Add(this.TestConnBtn);
            this.Controls.Add(this.ViewDataBtn);
            this.Controls.Add(this.ExportBtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.ResultsTxtBox);
            this.Controls.Add(this.IntegratedSecurityChkBox);
            this.Controls.Add(this.ResultsDataGridVw);
            this.Controls.Add(this.SQLTxtBox);
            this.Controls.Add(this.PasswordTxtBox);
            this.Controls.Add(this.UserNameTxtBox);
            this.Controls.Add(this.DBNameTxtBox);
            this.Controls.Add(this.ServerNameTxtBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ExportToFileForm";
            this.ShowIcon = false;
            this.Text = "Expot to CSV Test Harness";
            this.Load += new System.EventHandler(this.ExportToCSVForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BatchSizeNumUpDwn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResultsDataGridVw)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox IncludeHeaderChkBox;
        private System.Windows.Forms.TextBox ServerNameTxtBox;
        private System.Windows.Forms.TextBox UserNameTxtBox;
        private System.Windows.Forms.TextBox PasswordTxtBox;
        private System.Windows.Forms.CheckBox TextQualChkBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox DBNameTxtBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown BatchSizeNumUpDwn;
        private System.Windows.Forms.CheckBox IntegratedSecurityChkBox;
        private System.Windows.Forms.ComboBox CompressTypeCbBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox StageLocationTxtBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox FileNamePrefixTxtBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox FileDateFormatCbBox;
        private System.Windows.Forms.TextBox SQLTxtBox;
        private System.Windows.Forms.DataGridView ResultsDataGridVw;
        private System.Windows.Forms.TextBox ResultsTxtBox;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox AppendDtFormatChkBox;
        private System.Windows.Forms.RadioButton MultipleFileRdBtn;
        private System.Windows.Forms.RadioButton SingleFileRdBtn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox EncodingTypeCbBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button ExportBtn;
        private System.Windows.Forms.Button ViewDataBtn;
        private System.Windows.Forms.Button TestConnBtn;
        private System.Windows.Forms.ComboBox FileTypeCbBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox DestinationTextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox ColDelimiterCbBox;
        private System.Windows.Forms.ComboBox RowDelimiterCbBox;
        private System.Windows.Forms.Label label17;
    }
}

