﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mn.SSIS.Common;
using mn.SSIS.Common.ExportToFile;

namespace mn.SSIS.Common.ExportToFile.TestHarness
{
    public partial class ExportToFileForm : Form
    {
        private ExportToFile _ExportToFile;
        private SQLConnector _SQLConnector;
        private BindingSource ResultsBindingSource = new BindingSource();

        private Binding CompressTypeBinding = null;
        private Binding FileDateFormatBinding = null;
        private Binding EncodingBinding = null;
        private Binding FileTypeBinding = null;


        public ExportToFileForm()
        {
            InitializeComponent();
            ResetForm(true);
        }

        private void ExportToCSVForm_Load(object sender, EventArgs e)
        {
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ResetForm(false);
        }

        private void ResetForm(bool InitialLoad)
        {
            this.ServerNameTxtBox.Text = "db3";
            this.DBNameTxtBox.Text = "canaryhealth";
            this.IntegratedSecurityChkBox.Checked = true;

            this.UserNameTxtBox.Text = "sql_reporting";
            this.PasswordTxtBox.Text = string.Empty;

            this.IncludeHeaderChkBox.Checked = true;
            this.TextQualChkBox.Checked = true;

            BindingSource bs = new BindingSource();

            //SortedDictionary<string, string> s = ExportToFile.DateFormatStrings();

            if (InitialLoad)
            {
                // Setup COmbo box - Compression Type
                //CompressTypeBinding = new Binding("Text", bs, "Format", true, DataSourceUpdateMode.OnPropertyChanged);
                //this.CompressTypeCbBox.DataBindings.Add(CompressTypeBinding);
                this.CompressTypeCbBox.DataSource = new BindingSource(ExportToFileCommon.CompressionFileTypeStrings(), null);
                this.CompressTypeCbBox.DisplayMember = "Value";
                this.CompressTypeCbBox.ValueMember = "Key";

                // Setup COmbo box - File Date Format
                //FileDateFormatBinding = new Binding("Text", bs, "Format", true, DataSourceUpdateMode.OnPropertyChanged);
                //this.FileDateFormatCbBox.DataBindings.Add(FileDateFormatBinding);
                this.FileDateFormatCbBox.DataSource = new BindingSource(ExportToFile.DateFormatStrings(), null);
                this.FileDateFormatCbBox.DisplayMember = "Value";
                this.FileDateFormatCbBox.ValueMember = "Key";

                // Setup COmbo box - Encoding
                //EncodingBinding = new Binding("Text", bs, "Format", true, DataSourceUpdateMode.OnPropertyChanged);
                //this.EncodingTypeCbBox.DataBindings.Add(EncodingBinding);
                this.EncodingTypeCbBox.DataSource = new BindingSource(ExportToFile.FileEncodingTypeStrings(), null);
                this.EncodingTypeCbBox.DisplayMember = "Value";
                this.EncodingTypeCbBox.ValueMember = "Key";

                // Setup COmbo box - File Type
                //FileTypeBinding = new Binding("Text", bs, "Format", true, DataSourceUpdateMode.OnPropertyChanged);
                //this.FileTypeCbBox.DataBindings.Add(FileTypeBinding);
                this.FileTypeCbBox.DataSource = new BindingSource(ExportToFile.ExportToFileStrings(), null);
                this.FileTypeCbBox.DisplayMember = "Value";
                this.FileTypeCbBox.ValueMember = "Key";

                this.ColDelimiterCbBox.DataSource = new BindingSource(ExportToFile.ColumnDelimiterStrings(), null);
                this.ColDelimiterCbBox.DisplayMember = "Value";
                this.ColDelimiterCbBox.ValueMember = "Key";

                this.RowDelimiterCbBox.DataSource = new BindingSource(ExportToFile.RowDelimiterStrings(), null);
                this.RowDelimiterCbBox.DisplayMember = "Value";
                this.RowDelimiterCbBox.ValueMember = "Key";

            }

            //default for COmpression type
            this.CompressTypeCbBox.SelectedIndex = 0;

            this.AppendDtFormatChkBox.Checked = false;
            this.FileDateFormatCbBox.Enabled = false;

            //default for File Date Format type
            this.FileDateFormatCbBox.SelectedIndex = -1;
            
            this.SingleFileRdBtn.Checked = true;
            this.BatchSizeNumUpDwn.Value = 100000;
            this.BatchSizeNumUpDwn.Enabled = false;

            // default for Encoding
            this.EncodingTypeCbBox.SelectedIndex = 0;

            // default File Type
            this.FileTypeCbBox.SelectedIndex = 0;

            this.ColDelimiterCbBox.SelectedIndex = 0;
            this.RowDelimiterCbBox.SelectedIndex = 0;

            this.SQLTxtBox.Text = string.Empty;
            this.ResultsTxtBox.Text = string.Empty;

            // Create default object
            CreateExportToFile(true);
        }

        private bool ValidateForm()
        {
            bool retval = false;
            string strMsg = string.Empty;

            if (ServerNameTxtBox.Text.Length == 0)
                strMsg = "Servername is required";

            if (strMsg.Length > 0)
                MessageBox.Show (strMsg, "Export to CSV Validation", MessageBoxButtons.OK, MessageBoxIcon.Hand);

            retval = (strMsg.Length == 0) ? true : false;

            return retval;
        }

        private void MultipleFileRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (MultipleFileRdBtn.Checked)
            {
                this.BatchSizeNumUpDwn.Value = 100000;
                this.BatchSizeNumUpDwn.Enabled = true;
            }
            else
            {
                this.BatchSizeNumUpDwn.Value = 100000;
                this.BatchSizeNumUpDwn.Enabled = false;
            }
        }

        private void AppendDtFormatChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (AppendDtFormatChkBox.Checked)
            {
                this.FileDateFormatCbBox.SelectedIndex = 0;
                this.FileDateFormatCbBox.Enabled = true;
            }
            else
            {
                this.FileDateFormatCbBox.SelectedIndex = -1;
                this.FileDateFormatCbBox.Enabled = false;
            }
        }

        /// <summary>
        /// Look at the data before exporting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ViewDataBtn_Click(object sender, EventArgs e)
        {
            Exception OutEx;

            try
            {
                this.Cursor = Cursors.WaitCursor;
                CreateExportToFile(true);
                if (_ExportToFile != null)
                {
                    // get data to view
                    DataTable ViewDataDT = _ExportToFile.SQLHelper.ExecuteDataTable(out OutEx);
                    if (OutEx == null)
                    {
                        // Bind source
                        ResultsBindingSource.DataSource = ViewDataDT;
                        // Resize the DataGridView columns to fit the newly loaded content.
                        this.ResultsDataGridVw.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);
                        // Add data table to DAta grid
                        this.ResultsDataGridVw.DataSource = ResultsBindingSource;
                    }
                    else
                    {
                        AddToResults(OutEx.Message);
                        MessageBox.Show("Error Getting data!", "View Data Results", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                }
            }
            catch(Exception ex)
            {
                AddToResults(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void ExportBtn_Click(object sender, EventArgs e)
        {
            ExportFileList FileList = null;
            try
            {
                this.Cursor = Cursors.WaitCursor;
                this.ResultsTxtBox.Text = string.Empty;
                CreateExportToFile(true);
                if (_ExportToFile != null)
                {
                    // Export data
                    DBAppLogList exportResults  = _ExportToFile.Export(out FileList);

                    // add results to text box.
                    if (exportResults != null)
                        AddToResults(exportResults.ToString());

                    // Add export data  to results
                    if (FileList != null)
                        AddToResults(FileList.ToString());
                }
            }
            catch (Exception ex)
            {
                AddToResults(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void TestConnBtn_Click(object sender, EventArgs e)
        {
            string strMsg = string.Empty;

             IList<string> validationMessages = null;
            if (!this.IntegratedSecurityChkBox.Checked)
                _SQLConnector = SQLConnector.NewSQLConnector(this.ServerNameTxtBox.Text
                                                            , this.DBNameTxtBox.Text
                                                            , this.UserNameTxtBox.Text
                                                            , this.PasswordTxtBox.Text
                                                            , out validationMessages);
            else
                _SQLConnector = SQLConnector.NewSQLConnector(this.ServerNameTxtBox.Text
                                                            , this.DBNameTxtBox.Text
                                                            , out validationMessages);

            if (_SQLConnector == null)
            {
                strMsg = String.Join(System.Environment.NewLine, validationMessages);
            }
            else
            {
                // Test COnnection
                if (_SQLConnector.IsValidConnection(out strMsg))
                    strMsg = "Connection Successfull!!";
            }

            // Connection results.
            if (strMsg.Length > 0)
                MessageBox.Show(strMsg, "Test Connection Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void IntegratedSecurityChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (IntegratedSecurityChkBox.Checked)
            {
                this.UserNameTxtBox.Text = "";
                this.PasswordTxtBox.Text = "";
                this.UserNameTxtBox.Enabled = false;
                this.PasswordTxtBox.Enabled = false;
            }
            else
            {
                this.UserNameTxtBox.Text = "";
                this.PasswordTxtBox.Text = "";
                this.UserNameTxtBox.Enabled = true;
                this.PasswordTxtBox.Enabled = true;
            }
        }

        /// <summary>
        /// Create the Export To File Type based on form parameters
        /// </summary>
        /// <param name="OutputObjectData"></param>
        private void CreateExportToFile(bool OutputObjectData)
        {
            IList<string> validationMessages = null;

            if (!this.IntegratedSecurityChkBox.Checked)
                _SQLConnector = SQLConnector.NewSQLConnector(this.ServerNameTxtBox.Text
                                                            ,this.DBNameTxtBox.Text
                                                            ,this.SQLTxtBox.Text
                                                            ,this.UserNameTxtBox.Text
                                                            ,this.PasswordTxtBox.Text
                                                            ,out validationMessages);
            else
                _SQLConnector = SQLConnector.NewSQLConnector(this.ServerNameTxtBox.Text
                                                            , this.DBNameTxtBox.Text
                                                            , this.SQLTxtBox.Text
                                                            , out validationMessages);

            if (_SQLConnector == null)
            {
                AddToResults(validationMessages);
            }
            else
            {
                _ExportToFile = ExportToFile.NewExportToFile(_SQLConnector, out validationMessages);
                if (_ExportToFile == null)
                    AddToResults(validationMessages);
                else
                {
                    // COPY OTHER VALUES FROM FORM TO OBJECT    
                    _ExportToFile.AppendDateFormat = (AppendDtFormatChkBox.Checked) ? true : false;
                    _ExportToFile.BatchSize = (MultipleFileRdBtn.Checked) ? (int)BatchSizeNumUpDwn.Value : _ExportToFile.BatchSize;
                    _ExportToFile.CompressionType = (FileCompressionTypeEnum)this.CompressTypeCbBox.SelectedValue;
                    _ExportToFile.ExportToFileType = (ExportToFileTypeEnum)this.FileTypeCbBox.SelectedValue;

                    _ExportToFile.ColDelimiter = (ColumnDelimiter)this.ColDelimiterCbBox.SelectedValue;
                    _ExportToFile.RowDelimiter = (RowDelimiters)this.RowDelimiterCbBox.SelectedValue;

                    if (_ExportToFile.AppendDateFormat)
                        _ExportToFile.FileDateFormat = this.FileDateFormatCbBox.SelectedValue.ToString();
                    _ExportToFile.FileEncoding = Encoding.GetEncoding((int)this.EncodingTypeCbBox.SelectedValue);
                    if (_ExportToFile.FileEncoding == Encoding.UTF8)
                    {
                        _ExportToFile.FileEncoding = new UTF8Encoding(false, false);
                    }
                    
                    _ExportToFile.FilePrefix = this.FileNamePrefixTxtBox.Text;
                    _ExportToFile.IncludeHeaders = (IncludeHeaderChkBox.Checked) ? true : false;
                    _ExportToFile.IncludeTextQualifiers = (TextQualChkBox.Checked) ? true : false;
                    _ExportToFile.SplitFiles = (MultipleFileRdBtn.Checked) ? true : false;
                    _ExportToFile.StagingFileLocation = this.StageLocationTxtBox.Text;
                    _ExportToFile.DestinationLocation = this.DestinationTextBox.Text;

                    if (OutputObjectData)
                        AddToResults(_ExportToFile.ToString());
                }
            }
        }

        private void SetFormData()
        {

        }

        private void AddToResults(string Msg)
        {
            this.ResultsTxtBox.AppendText(System.Environment.NewLine + Msg);
        }
        private void AddToResults(IList<string> MsgList)
        {
            if ((MsgList != null) && (MsgList.Count > 0))
                this.ResultsTxtBox.AppendText(System.Environment.NewLine + String.Join(System.Environment.NewLine, MsgList));
        }
    }
}
