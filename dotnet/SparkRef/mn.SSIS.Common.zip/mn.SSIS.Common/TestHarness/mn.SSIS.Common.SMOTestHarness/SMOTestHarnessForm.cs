﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mn.SSIS.Common;
using mn.SSIS.Common.SMOLibrary;

namespace mn.SSIS.Common.SMOTestHarness
{
    public partial class SMOTestHarnessForm : Form
    {

        private List<KeyValuePair<int, string>> objComboBoxItems = new List<KeyValuePair<int, string>>(5);
        private List<KeyValuePair<int, string>> CreateCopyComboBoxItems = new List<KeyValuePair<int, string>>(5);

        public SMOTestHarnessForm()
        {
            InitializeComponent();
            this.ResetForm();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SourceTestConnBtn_Click(object sender, EventArgs e)
        {
            if (this.SrcIntSecurityChkBox.Checked)
                TestConn(this.SourceServerTxtBox.Text, this.SourceDBTxtBox.Text);
            else
                TestConn(this.SourceServerTxtBox.Text, this.SourceDBTxtBox.Text, this.SourceUsrTxtBox.Text, this.SourcePwdTxtBox.Text);
        }

        private void TestConn(string TheServerName, string TheDBName)
        {
            string strMsg = string.Empty;
            SQLConnector _SQLSourceConnector;

            IList<string> validationMessages = null;
            _SQLSourceConnector = SQLConnector.NewSQLConnector(TheServerName, TheDBName, out validationMessages);
            if (_SQLSourceConnector == null)
            {
                strMsg = String.Join(System.Environment.NewLine, validationMessages);
            }
            else
            {
                // Test COnnection
                if (_SQLSourceConnector.IsValidConnection(out strMsg))
                    strMsg = "Connection Successfull!!";
            }

            // Connection results.
            if (strMsg.Length > 0)
                MessageBox.Show(strMsg, "Test Connection Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// To test connection with username/pasword
        /// </summary>
        /// <param name="TheServerName"></param>
        /// <param name="TheDBName"></param>
        /// <param name="TheUserName"></param>
        /// <param name="ThePwd"></param>
        private void TestConn(string TheServerName, string TheDBName, string TheUserName, string ThePwd)
        {
            string strMsg = string.Empty;
            SQLConnector _SQLSourceConnector;

            IList<string> validationMessages = null;
            _SQLSourceConnector = SQLConnector.NewSQLConnector(TheServerName, TheDBName, TheUserName, ThePwd, out validationMessages);
            if (_SQLSourceConnector == null)
            {
                strMsg = String.Join(System.Environment.NewLine, validationMessages);
            }
            else
            {
                // Test COnnection
                if (_SQLSourceConnector.IsValidConnection(out strMsg))
                    strMsg = "Connection Successfull!!";
            }

            // Connection results.
            if (strMsg.Length > 0)
                MessageBox.Show(strMsg, "Test Connection Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ResetForm()
        {
            this.SourceServerTxtBox.Text = "LACubeData01";
            this.SourceDBTxtBox.Text = "DataWarehouse";
            this.SourceUsrTxtBox.Text = "";
            this.SourcePwdTxtBox.Text = "";
            this.SrcIntSecurityChkBox.Checked = true;

            this.TableNameTxtBox.Text = string.Empty;
            this.TargetTableTxtBox.Text = string.Empty;
            
            // dest
            this.DestGroupBox.Enabled = false;

            // col opionts
            this.NoColsRdBtn.Checked = true;
            this.CommaSepColTextBox.Text = string.Empty;

            // clear results
            this.SQLTxtBox.Text = "";
            this.ResultsTxtBox.Text = "";

            AddActionOptions();
            this.ActionComboBox.SelectedIndex = -1;

            AddCreateCopyOption(true);
            this.CreateCopyComboBox.SelectedIndex = -1;
        }

        private void ResetDestParam()
        {
            this.DestServerTxtBox.Text = string.Empty;
            this.DestDBTxtBox.Text = string.Empty;
            this.DestUsrTxtBox.Text = string.Empty;
            this.DestPwdTxtBox.Text = string.Empty;
            this.DestIntSecurityChkBox.Checked = true;
        }

        private void ScriptActionBtn_Click(object sender, EventArgs e)
        {
            ScriptColumnFilterOption ColFilterOption;
            SMOAction smoAction = GetAction();
            CreateCopyOption createCopyOpt = GetCreateCopyOption();
            CreateTableOption createTableOption = CreateTableOption.CreateIfNotExists;

            try
            {
                this.Cursor = Cursors.WaitCursor;
                this.ResultsTxtBox.Text = string.Empty;

                string strMsg = string.Empty;
                string strTableScript = string.Empty;
                bool blnTableCreated = false;
                SQLConnector _SQLSourceConnector = null;
                SQLConnector _SQLTargetConnector = null;

                IList<string> validationMessages = null;
                DBAppLogList objSMOOutput = null;

                if (smoAction == SMOAction.None)
                {
                    AddToResults("Please choose a Action.");
                    return;
                }

                if ((smoAction != SMOAction.Script_Table) && (smoAction != SMOAction.Script_Query))
                {
                    if (createCopyOpt == CreateCopyOption.None)
                    {
                        AddToResults("Please choose a Create and Copy option.");
                        return;
                    }
                    else
                    {
                        // set create table option
                        if ((smoAction == SMOAction.Create_Table_From_Query) || (smoAction == SMOAction.Create_Table_From_Table))
                            if (createCopyOpt == CreateCopyOption.Create_DropAndCreate)
                                createTableOption = CreateTableOption.DropAndCreate;
                    }
                }
                else
                {
                    // clear option it doesnt matter
                    createCopyOpt = CreateCopyOption.None;
                }

                // filter option
                if (IncludeColRdBtn.Checked)
                    ColFilterOption = ScriptColumnFilterOption.Include;
                else
                    ColFilterOption = ScriptColumnFilterOption.Exclude;

                // SQL Connector
                if (this.SrcIntSecurityChkBox.Checked)
                    _SQLSourceConnector = SQLConnector.NewSQLConnector(this.SourceServerTxtBox.Text, this.SourceDBTxtBox.Text, out validationMessages);
                else
                    _SQLSourceConnector = SQLConnector.NewSQLConnector(this.SourceServerTxtBox.Text, this.SourceDBTxtBox.Text, this.SourceUsrTxtBox.Text, this.SourcePwdTxtBox.Text, out validationMessages);

                // valid source connection
                if ((_SQLSourceConnector == null) && (!_SQLSourceConnector.IsValidConnection(out strMsg)))
                {
                    AddToResults("Please enter a valid Source connection information." + strMsg);
                    return;
                }

                // Target Connector
                if ((smoAction != SMOAction.Script_Table) && (smoAction != SMOAction.Script_Query))
                {
                    if (this.DestIntSecurityChkBox.Checked)
                        _SQLTargetConnector = SQLConnector.NewSQLConnector(this.DestServerTxtBox.Text, this.DestDBTxtBox.Text, out validationMessages);
                    else
                        _SQLTargetConnector = SQLConnector.NewSQLConnector(this.DestServerTxtBox.Text, this.DestDBTxtBox.Text, this.DestUsrTxtBox.Text, this.DestPwdTxtBox.Text, out validationMessages);

                    // valid connection
                    if ((_SQLTargetConnector == null) || (!_SQLTargetConnector.IsValidConnection(out strMsg)))
                    {
                        AddToResults("Please enter a valid Destination connection information." + strMsg);
                        return;
                    }
                }

                // process based on option selected
                if (smoAction == SMOAction.Script_Table)
                {
                    if (!string.IsNullOrEmpty(TableNameTxtBox.Text.Trim()))
                    {
                        if (NoColsRdBtn.Checked)
                            objSMOOutput = SMOHelper.GetTableScript(_SQLSourceConnector, this.TableNameTxtBox.Text, out strTableScript);
                        else
                            // get script
                            objSMOOutput = SMOHelper.GetTableScript(_SQLSourceConnector, this.TableNameTxtBox.Text, this.CommaSepColTextBox.Text, ColFilterOption, out strTableScript);
                        
                        // table script
                        AddToResults("Table Script:" + strTableScript);
                    }
                    else
                    {
                        AddToResults("Please enter a valid Source TableName.");
                    }
                }
                else if (smoAction == SMOAction.Script_Query)
                {
                    // TODO
                    if (!string.IsNullOrEmpty(SQLTxtBox.Text.Trim()))
                    {
                        if (NoColsRdBtn.Checked)
                            objSMOOutput = SMOHelper.GetTableScriptFromQuery(_SQLSourceConnector, this.SQLTxtBox.Text, "StageTable", out strTableScript);
                        else
                            objSMOOutput = SMOHelper.GetTableScriptFromQuery(_SQLSourceConnector, this.SQLTxtBox.Text, "StageTable", CommaSepColTextBox.Text, ColFilterOption, out strTableScript);
                 
                        // table script
                        AddToResults("Table Script:" + strTableScript);
                    }
                    else
                    {
                        AddToResults("Please enter a valid SQL Query.");
                    }
                }
                else if (smoAction == SMOAction.Create_Table_From_Table)
                {
                    if (!string.IsNullOrEmpty(this.TargetTableTxtBox.Text.Trim()))
                    {
                        if (NoColsRdBtn.Checked)
                            objSMOOutput = SMOHelper.CreateTable(_SQLSourceConnector, this.TableNameTxtBox.Text, _SQLTargetConnector, this.TargetTableTxtBox.Text, createTableOption, out blnTableCreated);
                        else
                            // get script
                            objSMOOutput = SMOHelper.CreateTable(_SQLSourceConnector, this.TableNameTxtBox.Text, _SQLTargetConnector, this.TargetTableTxtBox.Text, createTableOption, this.CommaSepColTextBox.Text, ColFilterOption, out blnTableCreated);

                        // table script
                        AddToResults("Table Created:" + blnTableCreated);
                    }
                    else
                    {
                        AddToResults("Please enter a valid Target table name.");
                    }

                }
                else if (smoAction == SMOAction.Create_Table_From_Query)
                {
                    if (!string.IsNullOrEmpty(this.TargetTableTxtBox.Text.Trim()) && (!string.IsNullOrEmpty(this.SQLTxtBox.Text.Trim())))
                    {
                        // setup source query
                        _SQLSourceConnector.SQLScript = this.SQLTxtBox.Text;

                        if (NoColsRdBtn.Checked)
                            objSMOOutput = SMOHelper.CreateTableFromQuery(_SQLSourceConnector, _SQLTargetConnector, this.TargetTableTxtBox.Text, createTableOption, out blnTableCreated);
                        else
                            // get script
                            objSMOOutput = SMOHelper.CreateTableFromQuery(_SQLSourceConnector, _SQLTargetConnector, this.TargetTableTxtBox.Text, createTableOption, this.CommaSepColTextBox.Text, ColFilterOption, out blnTableCreated);

                        // table script
                        AddToResults("Table Created:" + blnTableCreated);
                    }
                    else
                    {
                        AddToResults("Please enter a valid Query and/or Target Table Name.");
                    }
                }
                else
                {
                    AddToResults("Choose one of 4 options Create Script/Create From...");
                }

                // add output if an action was taken
                if (objSMOOutput != null)
                    AddToResults(objSMOOutput.ToString());

            }
            catch (Exception ex)
            {
                AddToResults(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void AddToResults(string Msg)
        {
            this.ResultsTxtBox.AppendText(System.Environment.NewLine + Msg);
        }
        private void AddToResults(IList<string> MsgList)
        {
            if ((MsgList != null) && (MsgList.Count > 0))
                this.ResultsTxtBox.AppendText(System.Environment.NewLine + String.Join(System.Environment.NewLine, MsgList));
        }

        private void SrcIntSecurityChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (SrcIntSecurityChkBox.Checked)
            {
                this.SourceUsrTxtBox.Text = "";
                this.SourcePwdTxtBox.Text = "";
                this.SourceUsrTxtBox.Enabled = false;
                this.SourcePwdTxtBox.Enabled = false;
            }
            else
            {
                this.SourceUsrTxtBox.Text = "";
                this.SourcePwdTxtBox.Text = "";
                this.SourceUsrTxtBox.Enabled = true;
                this.SourcePwdTxtBox.Enabled = true;
            }
        }

        private void DestIntSecurityChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (DestIntSecurityChkBox.Checked)
            {
                this.DestUsrTxtBox.Text = "";
                this.DestPwdTxtBox.Text = "";
                this.DestUsrTxtBox.Enabled = false;
                this.DestPwdTxtBox.Enabled = false;
            }
            else
            {
                this.DestUsrTxtBox.Text = "";
                this.DestPwdTxtBox.Text = "";
                this.DestUsrTxtBox.Enabled = true;
                this.DestPwdTxtBox.Enabled = true;
            }
        }

        private void DestTestConnBtn_Click(object sender, EventArgs e)
        {
            if (this.DestIntSecurityChkBox.Checked)
                TestConn(DestServerTxtBox.Text, DestDBTxtBox.Text);
            else
                TestConn(this.DestServerTxtBox.Text, this.DestDBTxtBox.Text, this.DestUsrTxtBox.Text, this.DestPwdTxtBox.Text);

            
        }

        private void NoColsRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (NoColsRdBtn.Checked)
            {
                this.CommaSepColTextBox.Text = string.Empty;
                this.CommaSepColTextBox.Enabled = false;
            }
            else
            {
                this.CommaSepColTextBox.Enabled = true;
            }
        }

        private void ScriptTableRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            ScriptOrCreateButtonChanged();
        }

        private void CreateFromTableRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            ScriptOrCreateButtonChanged();
        }

        private void CreateFromQryRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            ScriptOrCreateButtonChanged();
        }

        private void ScriptQueryRdBtn_CheckedChanged(object sender, EventArgs e)
        {
            ScriptOrCreateButtonChanged();
        }

        private void ScriptOrCreateButtonChanged()
        {
            SMOAction smoAction = GetAction();

            this.SQLTxtBox.Enabled = false;
            this.TableNameTxtBox.Enabled = false;
            this.TargetTableTxtBox.Enabled = false;
            this.DestGroupBox.Enabled = false;

            switch(smoAction)
            {
                case SMOAction.Script_Table:
                        this.TableNameTxtBox.Enabled = true;
                        this.TableNameTxtBox.Text = string.Empty;
                    break;
                case SMOAction.Script_Query:
                        this.SQLTxtBox.Enabled = true;
                    break;
                case SMOAction.Create_Table_From_Table:
                        this.TableNameTxtBox.Enabled = true;
                        this.TargetTableTxtBox.Enabled = true;
                        this.TargetTableTxtBox.Text = string.Empty;
                        this.DestGroupBox.Enabled = true;
                    break;
                case SMOAction.Create_Table_From_Query:
                        this.SQLTxtBox.Enabled = true;
                        this.TargetTableTxtBox.Enabled = true;
                        this.TargetTableTxtBox.Text = string.Empty;
                        this.DestGroupBox.Enabled = true;
                    break;
                case SMOAction.Copy_Table_From_Table:
                    break;
                case SMOAction.Copy_Table_From_Query:
                    break;
            }
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void ActionComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ScriptOrCreateButtonChanged();

            SMOAction smoAction = GetAction();

            if ((smoAction == SMOAction.Create_Table_From_Table) || (smoAction == SMOAction.Create_Table_From_Query))
            {
                this.CreateCopyComboBox.Enabled = true;
                AddCreateCopyOption(true);
            }
            else if ((smoAction == SMOAction.Copy_Table_From_Query) || (smoAction == SMOAction.Copy_Table_From_Table))
            {
                this.CreateCopyComboBox.Enabled = true;
                AddCreateCopyOption(false);
            }
            else
            {
                AddCreateCopyOption(true);
                this.CreateCopyComboBox.Enabled = false;
            }
        }
    
        private void AddActionOptions()
        {
            this.ActionComboBox.Items.Clear();
            
            objComboBoxItems.Clear();
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Script_Table, "Script Table"));
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Script_Query, "Script Query"));
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Create_Table_From_Query, "Create Table (From Table)"));
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Create_Table_From_Query, "Create Table (From Query)"));
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Copy_Table_From_Table, "Copy Table (From Table)"));
            objComboBoxItems.Add(new KeyValuePair<int, string>((int)SMOAction.Copy_Table_From_Query, "Copy Table (From Query)"));

            // add options
            this.ActionComboBox.DataSource = objComboBoxItems;
            this.ActionComboBox.ValueMember = "Key";
            this.ActionComboBox.DisplayMember = "Value";

            this.ActionComboBox.SelectedIndex = 0;
        }

        private void AddCreateCopyOption(bool CreateOptionsOnly)
        {
            this.CreateCopyComboBox.DataSource = null;
            this.CreateCopyComboBox.Items.Clear();

            CreateCopyComboBoxItems.Clear();
            if (CreateOptionsOnly)
            {
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Create_CreateIfNotExists, "Create If Not Exists"));
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Create_DropAndCreate, "Drop and Create"));
            }
            else
            {
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Copy_CreateIfNotExistsAndCopy, "Create If Not Exists and Copy"));
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Copy_DropCreateAndCopy, "Drop Target, Create, and Copy"));
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Copy_BackupCreateAndCopy, "Backup Target, Create, and Copy"));
                CreateCopyComboBoxItems.Add(new KeyValuePair<int, string>((int)CreateCopyOption.Copy_Append, "Append to Target"));
            }

            this.CreateCopyComboBox.DataSource = CreateCopyComboBoxItems;
            this.CreateCopyComboBox.ValueMember = "Key";
            this.CreateCopyComboBox.DisplayMember = "Value";

            this.CreateCopyComboBox.SelectedIndex = -1;
        }

        private SMOAction GetAction()
        {
            SMOAction smoAction = SMOAction.None;

            if (this.ActionComboBox.SelectedIndex >= 0)
            {
                int intSelIdx = this.ActionComboBox.SelectedIndex;
                smoAction = (SMOAction)intSelIdx;
            }

            return smoAction;
        }

        private CreateCopyOption GetCreateCopyOption()
        {
            CreateCopyOption retOption = CreateCopyOption.None;

            if (this.CreateCopyComboBox.SelectedIndex >= 0)
            {
                int intSelIdx = this.CreateCopyComboBox.SelectedIndex;
                retOption = (CreateCopyOption)intSelIdx;
            }

            return retOption;
        }

        private enum SMOAction
        {
            None = -1,
            Script_Table  = 0,
            Script_Query= 1,
            Create_Table_From_Table = 2,
            Create_Table_From_Query = 3,
            Copy_Table_From_Table = 4,
            Copy_Table_From_Query = 5
        }

        private enum CreateCopyOption
        {
            None = -1,
            // create options
            Create_CreateIfNotExists = 0,
            Create_DropAndCreate = 1,
            // copy options
            Copy_CreateIfNotExistsAndCopy = 2,
            Copy_DropCreateAndCopy = 3,
            Copy_BackupCreateAndCopy = 4,
            Copy_Append = 5
        }
    }
}
