﻿namespace mn.SSIS.Common.SMOTestHarness
{
    partial class SMOTestHarnessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ResetBtn = new System.Windows.Forms.Button();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.SourceTestConnBtn = new System.Windows.Forms.Button();
            this.ResultsTxtBox = new System.Windows.Forms.TextBox();
            this.SrcIntSecurityChkBox = new System.Windows.Forms.CheckBox();
            this.SQLTxtBox = new System.Windows.Forms.TextBox();
            this.SourcePwdTxtBox = new System.Windows.Forms.TextBox();
            this.SourceUsrTxtBox = new System.Windows.Forms.TextBox();
            this.SourceDBTxtBox = new System.Windows.Forms.TextBox();
            this.SourceServerTxtBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SourceGroupBox = new System.Windows.Forms.GroupBox();
            this.DestGroupBox = new System.Windows.Forms.GroupBox();
            this.DestTestConnBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.DestIntSecurityChkBox = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.DestPwdTxtBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.DestUsrTxtBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DestDBTxtBox = new System.Windows.Forms.TextBox();
            this.DestServerTxtBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TargetTableTxtBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TableNameTxtBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ScriptActionBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.NoColsRdBtn = new System.Windows.Forms.RadioButton();
            this.CommaSepColTextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ExcludeColRdBtn = new System.Windows.Forms.RadioButton();
            this.IncludeColRdBtn = new System.Windows.Forms.RadioButton();
            this.ActionComboBox = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.CreateCopyComboBox = new System.Windows.Forms.ComboBox();
            this.SourceGroupBox.SuspendLayout();
            this.DestGroupBox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(762, 739);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(74, 33);
            this.ResetBtn.TabIndex = 9;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseBtn.Location = new System.Drawing.Point(842, 739);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(82, 33);
            this.CloseBtn.TabIndex = 10;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // SourceTestConnBtn
            // 
            this.SourceTestConnBtn.Location = new System.Drawing.Point(328, 68);
            this.SourceTestConnBtn.Name = "SourceTestConnBtn";
            this.SourceTestConnBtn.Size = new System.Drawing.Size(124, 23);
            this.SourceTestConnBtn.TabIndex = 9;
            this.SourceTestConnBtn.Text = "Test Connection";
            this.SourceTestConnBtn.UseVisualStyleBackColor = true;
            this.SourceTestConnBtn.Click += new System.EventHandler(this.SourceTestConnBtn_Click);
            // 
            // ResultsTxtBox
            // 
            this.ResultsTxtBox.Location = new System.Drawing.Point(10, 431);
            this.ResultsTxtBox.MaxLength = 327670;
            this.ResultsTxtBox.Multiline = true;
            this.ResultsTxtBox.Name = "ResultsTxtBox";
            this.ResultsTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ResultsTxtBox.Size = new System.Drawing.Size(913, 302);
            this.ResultsTxtBox.TabIndex = 8;
            // 
            // SrcIntSecurityChkBox
            // 
            this.SrcIntSecurityChkBox.AutoSize = true;
            this.SrcIntSecurityChkBox.Location = new System.Drawing.Point(12, 68);
            this.SrcIntSecurityChkBox.Name = "SrcIntSecurityChkBox";
            this.SrcIntSecurityChkBox.Size = new System.Drawing.Size(115, 17);
            this.SrcIntSecurityChkBox.TabIndex = 8;
            this.SrcIntSecurityChkBox.Text = "Integrated Security";
            this.SrcIntSecurityChkBox.UseVisualStyleBackColor = true;
            this.SrcIntSecurityChkBox.CheckedChanged += new System.EventHandler(this.SrcIntSecurityChkBox_CheckedChanged);
            // 
            // SQLTxtBox
            // 
            this.SQLTxtBox.Location = new System.Drawing.Point(10, 274);
            this.SQLTxtBox.MaxLength = 327670;
            this.SQLTxtBox.Multiline = true;
            this.SQLTxtBox.Name = "SQLTxtBox";
            this.SQLTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.SQLTxtBox.Size = new System.Drawing.Size(913, 131);
            this.SQLTxtBox.TabIndex = 5;
            // 
            // SourcePwdTxtBox
            // 
            this.SourcePwdTxtBox.Location = new System.Drawing.Point(326, 41);
            this.SourcePwdTxtBox.Name = "SourcePwdTxtBox";
            this.SourcePwdTxtBox.Size = new System.Drawing.Size(126, 20);
            this.SourcePwdTxtBox.TabIndex = 7;
            // 
            // SourceUsrTxtBox
            // 
            this.SourceUsrTxtBox.Location = new System.Drawing.Point(105, 41);
            this.SourceUsrTxtBox.Name = "SourceUsrTxtBox";
            this.SourceUsrTxtBox.Size = new System.Drawing.Size(114, 20);
            this.SourceUsrTxtBox.TabIndex = 5;
            // 
            // SourceDBTxtBox
            // 
            this.SourceDBTxtBox.Location = new System.Drawing.Point(326, 15);
            this.SourceDBTxtBox.Name = "SourceDBTxtBox";
            this.SourceDBTxtBox.Size = new System.Drawing.Size(126, 20);
            this.SourceDBTxtBox.TabIndex = 3;
            // 
            // SourceServerTxtBox
            // 
            this.SourceServerTxtBox.Location = new System.Drawing.Point(105, 16);
            this.SourceServerTxtBox.Name = "SourceServerTxtBox";
            this.SourceServerTxtBox.Size = new System.Drawing.Size(114, 20);
            this.SourceServerTxtBox.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 412);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Results";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 252);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Query";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(238, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "User Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(238, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Source DB";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server";
            // 
            // SourceGroupBox
            // 
            this.SourceGroupBox.Controls.Add(this.SourcePwdTxtBox);
            this.SourceGroupBox.Controls.Add(this.SourceTestConnBtn);
            this.SourceGroupBox.Controls.Add(this.label1);
            this.SourceGroupBox.Controls.Add(this.label2);
            this.SourceGroupBox.Controls.Add(this.SrcIntSecurityChkBox);
            this.SourceGroupBox.Controls.Add(this.label3);
            this.SourceGroupBox.Controls.Add(this.label4);
            this.SourceGroupBox.Controls.Add(this.SourceServerTxtBox);
            this.SourceGroupBox.Controls.Add(this.SourceUsrTxtBox);
            this.SourceGroupBox.Controls.Add(this.SourceDBTxtBox);
            this.SourceGroupBox.Location = new System.Drawing.Point(10, 12);
            this.SourceGroupBox.Name = "SourceGroupBox";
            this.SourceGroupBox.Size = new System.Drawing.Size(458, 119);
            this.SourceGroupBox.TabIndex = 0;
            this.SourceGroupBox.TabStop = false;
            this.SourceGroupBox.Text = "Source Server";
            // 
            // DestGroupBox
            // 
            this.DestGroupBox.Controls.Add(this.DestTestConnBtn);
            this.DestGroupBox.Controls.Add(this.label10);
            this.DestGroupBox.Controls.Add(this.DestIntSecurityChkBox);
            this.DestGroupBox.Controls.Add(this.label11);
            this.DestGroupBox.Controls.Add(this.DestPwdTxtBox);
            this.DestGroupBox.Controls.Add(this.label9);
            this.DestGroupBox.Controls.Add(this.DestUsrTxtBox);
            this.DestGroupBox.Controls.Add(this.label8);
            this.DestGroupBox.Controls.Add(this.DestDBTxtBox);
            this.DestGroupBox.Controls.Add(this.DestServerTxtBox);
            this.DestGroupBox.Location = new System.Drawing.Point(10, 138);
            this.DestGroupBox.Name = "DestGroupBox";
            this.DestGroupBox.Size = new System.Drawing.Size(458, 96);
            this.DestGroupBox.TabIndex = 2;
            this.DestGroupBox.TabStop = false;
            this.DestGroupBox.Text = "Destination Server";
            // 
            // DestTestConnBtn
            // 
            this.DestTestConnBtn.Location = new System.Drawing.Point(328, 68);
            this.DestTestConnBtn.Name = "DestTestConnBtn";
            this.DestTestConnBtn.Size = new System.Drawing.Size(124, 23);
            this.DestTestConnBtn.TabIndex = 9;
            this.DestTestConnBtn.Text = "Test Connection";
            this.DestTestConnBtn.UseVisualStyleBackColor = true;
            this.DestTestConnBtn.Click += new System.EventHandler(this.DestTestConnBtn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(238, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Dest DB";
            // 
            // DestIntSecurityChkBox
            // 
            this.DestIntSecurityChkBox.AutoSize = true;
            this.DestIntSecurityChkBox.Location = new System.Drawing.Point(12, 68);
            this.DestIntSecurityChkBox.Name = "DestIntSecurityChkBox";
            this.DestIntSecurityChkBox.Size = new System.Drawing.Size(115, 17);
            this.DestIntSecurityChkBox.TabIndex = 8;
            this.DestIntSecurityChkBox.Text = "Integrated Security";
            this.DestIntSecurityChkBox.UseVisualStyleBackColor = true;
            this.DestIntSecurityChkBox.CheckedChanged += new System.EventHandler(this.DestIntSecurityChkBox_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Server";
            // 
            // DestPwdTxtBox
            // 
            this.DestPwdTxtBox.Location = new System.Drawing.Point(326, 41);
            this.DestPwdTxtBox.Name = "DestPwdTxtBox";
            this.DestPwdTxtBox.Size = new System.Drawing.Size(126, 20);
            this.DestPwdTxtBox.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 42);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "User Name";
            // 
            // DestUsrTxtBox
            // 
            this.DestUsrTxtBox.Location = new System.Drawing.Point(105, 41);
            this.DestUsrTxtBox.Name = "DestUsrTxtBox";
            this.DestUsrTxtBox.Size = new System.Drawing.Size(114, 20);
            this.DestUsrTxtBox.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(238, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "Password";
            // 
            // DestDBTxtBox
            // 
            this.DestDBTxtBox.Location = new System.Drawing.Point(326, 15);
            this.DestDBTxtBox.Name = "DestDBTxtBox";
            this.DestDBTxtBox.Size = new System.Drawing.Size(126, 20);
            this.DestDBTxtBox.TabIndex = 3;
            // 
            // DestServerTxtBox
            // 
            this.DestServerTxtBox.Location = new System.Drawing.Point(105, 16);
            this.DestServerTxtBox.Name = "DestServerTxtBox";
            this.DestServerTxtBox.Size = new System.Drawing.Size(114, 20);
            this.DestServerTxtBox.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.CreateCopyComboBox);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.ActionComboBox);
            this.groupBox3.Controls.Add(this.TargetTableTxtBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.TableNameTxtBox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(474, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 119);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Query Options";
            // 
            // TargetTableTxtBox
            // 
            this.TargetTableTxtBox.Location = new System.Drawing.Point(327, 76);
            this.TargetTableTxtBox.Name = "TargetTableTxtBox";
            this.TargetTableTxtBox.Size = new System.Drawing.Size(114, 20);
            this.TargetTableTxtBox.TabIndex = 7;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(324, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 16);
            this.label13.TabIndex = 6;
            this.label13.Text = "Target Table";
            // 
            // TableNameTxtBox
            // 
            this.TableNameTxtBox.Location = new System.Drawing.Point(207, 77);
            this.TableNameTxtBox.Name = "TableNameTxtBox";
            this.TableNameTxtBox.Size = new System.Drawing.Size(114, 20);
            this.TableNameTxtBox.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(204, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Source Table";
            // 
            // ScriptActionBtn
            // 
            this.ScriptActionBtn.Location = new System.Drawing.Point(819, 235);
            this.ScriptActionBtn.Name = "ScriptActionBtn";
            this.ScriptActionBtn.Size = new System.Drawing.Size(105, 33);
            this.ScriptActionBtn.TabIndex = 6;
            this.ScriptActionBtn.Text = "Submit";
            this.ScriptActionBtn.UseVisualStyleBackColor = true;
            this.ScriptActionBtn.Click += new System.EventHandler(this.ScriptActionBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.NoColsRdBtn);
            this.groupBox1.Controls.Add(this.CommaSepColTextBox);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.ExcludeColRdBtn);
            this.groupBox1.Controls.Add(this.IncludeColRdBtn);
            this.groupBox1.Location = new System.Drawing.Point(474, 143);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(449, 86);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Column List";
            // 
            // NoColsRdBtn
            // 
            this.NoColsRdBtn.AutoSize = true;
            this.NoColsRdBtn.Location = new System.Drawing.Point(7, 19);
            this.NoColsRdBtn.Name = "NoColsRdBtn";
            this.NoColsRdBtn.Size = new System.Drawing.Size(51, 17);
            this.NoColsRdBtn.TabIndex = 0;
            this.NoColsRdBtn.TabStop = true;
            this.NoColsRdBtn.Text = "None";
            this.NoColsRdBtn.UseVisualStyleBackColor = true;
            this.NoColsRdBtn.CheckedChanged += new System.EventHandler(this.NoColsRdBtn_CheckedChanged);
            // 
            // CommaSepColTextBox
            // 
            this.CommaSepColTextBox.Location = new System.Drawing.Point(83, 43);
            this.CommaSepColTextBox.Name = "CommaSepColTextBox";
            this.CommaSepColTextBox.Size = new System.Drawing.Size(298, 20);
            this.CommaSepColTextBox.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(10, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "Columns";
            // 
            // ExcludeColRdBtn
            // 
            this.ExcludeColRdBtn.AutoSize = true;
            this.ExcludeColRdBtn.Location = new System.Drawing.Point(130, 19);
            this.ExcludeColRdBtn.Name = "ExcludeColRdBtn";
            this.ExcludeColRdBtn.Size = new System.Drawing.Size(63, 17);
            this.ExcludeColRdBtn.TabIndex = 2;
            this.ExcludeColRdBtn.TabStop = true;
            this.ExcludeColRdBtn.Text = "Exclude";
            this.ExcludeColRdBtn.UseVisualStyleBackColor = true;
            // 
            // IncludeColRdBtn
            // 
            this.IncludeColRdBtn.AutoSize = true;
            this.IncludeColRdBtn.Location = new System.Drawing.Point(64, 19);
            this.IncludeColRdBtn.Name = "IncludeColRdBtn";
            this.IncludeColRdBtn.Size = new System.Drawing.Size(60, 17);
            this.IncludeColRdBtn.TabIndex = 1;
            this.IncludeColRdBtn.TabStop = true;
            this.IncludeColRdBtn.Text = "Include";
            this.IncludeColRdBtn.UseVisualStyleBackColor = true;
            // 
            // ActionComboBox
            // 
            this.ActionComboBox.FormattingEnabled = true;
            this.ActionComboBox.Location = new System.Drawing.Point(72, 19);
            this.ActionComboBox.Name = "ActionComboBox";
            this.ActionComboBox.Size = new System.Drawing.Size(250, 21);
            this.ActionComboBox.TabIndex = 8;
            this.ActionComboBox.SelectedIndexChanged += new System.EventHandler(this.ActionComboBox_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(10, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 16);
            this.label14.TabIndex = 9;
            this.label14.Text = "Action";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(10, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(144, 16);
            this.label15.TabIndex = 10;
            this.label15.Text = "Create/Copy Option";
            // 
            // CreateCopyComboBox
            // 
            this.CreateCopyComboBox.FormattingEnabled = true;
            this.CreateCopyComboBox.Location = new System.Drawing.Point(13, 77);
            this.CreateCopyComboBox.Name = "CreateCopyComboBox";
            this.CreateCopyComboBox.Size = new System.Drawing.Size(188, 21);
            this.CreateCopyComboBox.TabIndex = 11;
            // 
            // SMOTestHarnessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CloseBtn;
            this.ClientSize = new System.Drawing.Size(928, 778);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ScriptActionBtn);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.DestGroupBox);
            this.Controls.Add(this.SourceGroupBox);
            this.Controls.Add(this.ResultsTxtBox);
            this.Controls.Add(this.SQLTxtBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.CloseBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SMOTestHarnessForm";
            this.ShowIcon = false;
            this.Text = "SMO Test Harness";
            this.SourceGroupBox.ResumeLayout(false);
            this.SourceGroupBox.PerformLayout();
            this.DestGroupBox.ResumeLayout(false);
            this.DestGroupBox.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button SourceTestConnBtn;
        private System.Windows.Forms.TextBox ResultsTxtBox;
        private System.Windows.Forms.CheckBox SrcIntSecurityChkBox;
        private System.Windows.Forms.TextBox SQLTxtBox;
        private System.Windows.Forms.TextBox SourcePwdTxtBox;
        private System.Windows.Forms.TextBox SourceUsrTxtBox;
        private System.Windows.Forms.TextBox SourceDBTxtBox;
        private System.Windows.Forms.TextBox SourceServerTxtBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox SourceGroupBox;
        private System.Windows.Forms.GroupBox DestGroupBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TableNameTxtBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button DestTestConnBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox DestIntSecurityChkBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox DestPwdTxtBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox DestUsrTxtBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox DestDBTxtBox;
        private System.Windows.Forms.TextBox DestServerTxtBox;
        private System.Windows.Forms.Button ScriptActionBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox CommaSepColTextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton ExcludeColRdBtn;
        private System.Windows.Forms.RadioButton IncludeColRdBtn;
        private System.Windows.Forms.RadioButton NoColsRdBtn;
        private System.Windows.Forms.TextBox TargetTableTxtBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ActionComboBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox CreateCopyComboBox;
    }
}

