﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using mn.SSIS.Common.FTPLibrary;

namespace mn.SSIS.Common.FTPTestHarness
{
    public partial class FTPTestHarnessForm : Form
    {
        public FTPTestHarnessForm()
        {
            InitializeComponent();
        }

        private void OpenFileButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the open file dialog box.
            //OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Set filter options and filter index.
            OpenFileDialgobox.Filter = "CSV Files (.csv)|*.csv|All Files (*.*)|*.*";
            OpenFileDialgobox.FilterIndex = 1;

            OpenFileDialgobox.Multiselect = false;

            // Call the ShowDialog method to show the dialog box.
            DialogResult userClickedOK = OpenFileDialgobox.ShowDialog();

            // Process input if the user clicked OK.
            if (userClickedOK == DialogResult.OK)
            {
                // Open the selected file to read.
                string strFileName = OpenFileDialgobox.FileName;
                FileTouploadTextbox.Text = strFileName;

                // Read the first line from the file and write it the textbox.
                AddToResults(strFileName);
            }
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ResetThisForm();
        }

        private void UploadFileBtn_Click(object sender, EventArgs e)
        {
            bool blnValid = CheckValidInput(true);

            if (blnValid && (ProtocolComboBox.SelectedItem != null))
            {
                try
                {
                    if (ProtocolComboBox.SelectedItem.ToString() == "FTP")
                    {
                        FTPclient ftpClient = GetFTPClient();
                        if (File.Exists(this.FileToUpload))
                        {
                            string strTargetFileName = Path.GetFileName(this.FileToUpload);
                            AddToResults(string.Format("Uploading File from:{0} to {1}.", this.FileToUpload, strTargetFileName));
                            bool blnUpload = ftpClient.Upload(this.FileToUpload, strTargetFileName);
                            AddToResults("Upload File Results:" + blnUpload.ToString());
                            ListFTPDirectory();
                        }
                        else
                        {
                            AddToResults("File To upload:" + this.FileToUpload + " is missing.");
                        }
                    }
                    else if (ProtocolComboBox.SelectedItem.ToString() == "SFTP")
                    {
                        SFTPClient.UploadFile(this.UserName, this.Password, this.HostName, this.Port, this.FTPFolder, this.FileToUpload, true);
                        ListFTPDirectory();
                    }
                }
                catch(Exception ex)
                {
                    AddToResults(ex.Message);
                }
            }
        }

        private void ListFilesBtn_Click(object sender, EventArgs e)
        {
            ListFTPDirectory();
        }

        private void TestConnBtn_Click(object sender, EventArgs e)
        {
            ListFTPDirectory();
        }

        private void ListFTPDirectory()
        {
            bool blnValid = CheckValidInput(false);
            if (blnValid)
            {
                try
                {
                    if (ProtocolComboBox.SelectedIndex == 0)
                    {
                        FTPclient ftpClient = GetFTPClient();
                        List<string> strDirectoryList = ftpClient.ListDirectory(this.FTPFolder);
                        AddToResults(strDirectoryList);
                    }
                    else if (ProtocolComboBox.SelectedIndex == 1)
                    {
                        DataTable dt = SFTPClient.ListFiles(this.UserName, this.Password, this.HostName, this.Port, this.FTPFolder);
                        if (dt != null)
                        {
                            foreach (DataRow dr in dt.Rows)
                                foreach (DataColumn dc in dt.Columns)
                                    AddToResults(string.Format("Name:{0}, Value:{1}", dc.ColumnName, dr[dc].ToString()));
                        }
                        else
                        {
                            AddToResults("No files to list.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    AddToResults(ex.Message);
                }
            }
        }


        private FTPclient GetFTPClient()
        {
            FTPclient ftpClient = new FTPclient(this.HostName, this.UserName, this.Password);
            return ftpClient;
        }

        private void AddToResults(string ResultMsg)
        {
            ResultsTextbox.AppendText(System.Environment.NewLine);
            ResultsTextbox.AppendText(ResultMsg);
            ResultsTextbox.ScrollToCaret();
        }

        private void AddToResults(IList<string> ResultList)
        {
            if (ResultList != null)
                foreach (string strResult in ResultList)
                    AddToResults(strResult);
            else
                AddToResults("No Data to List");
        }


        private void ResetThisForm()
        {
            this.HostTxtBox.Text = string.Empty;
            this.PortTxtBox.Text = string.Empty;
            this.UserNameTxtBox.Text = string.Empty;
            this.PasswordTxtBox.Text = string.Empty;
            this.FTPFolderPathTxtBox.Text = string.Empty;
            this.FileTouploadTextbox.Text = string.Empty;

            this.ResultsTextbox.Text = "";
        }

        private bool CheckValidInput(bool CheckFileName)
        {
            bool blnRetval = false;
            string strMsg = "";

            string strFileName = FileTouploadTextbox.Text;
            string strHostName = HostTxtBox.Text;
            string strPort = PortTxtBox.Text.Trim();
            int intPort;

            if (strHostName.Length == 0)
                strMsg = "Please enter valid FTP Host name!";
            else if (ProtocolComboBox.SelectedIndex < 0)
                strMsg = "Please select a FTP Protocol!";
            else if (string.IsNullOrEmpty(UserNameTxtBox.Text.Trim()))
                strMsg = "Please enter a valid Username!";
            else if (string.IsNullOrEmpty(PasswordTxtBox.Text.Trim()))
                strMsg = "Please enter a valid Password!";
            else if ((CheckFileName == true) && (strFileName.Length == 0))
                strMsg = "Please enter valid File to Upload!";
            else if (strPort.Length > 0)
            {
                // should be a number
                if (!int.TryParse(strPort, out intPort))
                    strMsg = "Port Number should be only integers.";
            }

            if (strMsg.Length > 0)
                MessageBox.Show(strMsg, "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            blnRetval = (strMsg.Length == 0) ? true : false;

            return blnRetval;
        }

        #region Properties to read from form

        private string HostName
        {
            get
            {
                return this.HostTxtBox.Text.Trim();
            }
        }

        private string UserName
        {
            get
            {
                return this.UserNameTxtBox.Text.Trim();
            }
        }

        private string Password
        {
            get
            {
                return this.PasswordTxtBox.Text.Trim();
            }
        }

        private int Port
        {
            get
            {
                int intPort = -1;
                int.TryParse(this.PortTxtBox.Text.Trim(), out intPort);
                return intPort;
            }
        }

        private string Protocol
        {
            get
            {
                string str = string.Empty;
                if (ProtocolComboBox.SelectedIndex >= 0)
                    str = ProtocolComboBox.SelectedValue.ToString();
                return str;
            }
        }

        private string FTPFolder
        {
            get
            {
                return FTPFolderPathTxtBox.Text.Trim();
            }
        }

        private string FileToUpload
        {
            get
            {
                return FileTouploadTextbox.Text.Trim();
            }
        }

        #endregion

    }
}
