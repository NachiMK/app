﻿namespace mn.SSIS.Common.FTPTestHarness
{
    partial class FTPTestHarnessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UploadFileBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.FTPConnectiongb = new System.Windows.Forms.GroupBox();
            this.TestConnBtn = new System.Windows.Forms.Button();
            this.PasswordTxtBox = new System.Windows.Forms.TextBox();
            this.UserNameTxtBox = new System.Windows.Forms.TextBox();
            this.PortTxtBox = new System.Windows.Forms.TextBox();
            this.HostTxtBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ProtocolComboBox = new System.Windows.Forms.ComboBox();
            this.FTPFolderPathTxtBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ListFilesBtn = new System.Windows.Forms.Button();
            this.OpenFileDialgobox = new System.Windows.Forms.OpenFileDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.FileTouploadTextbox = new System.Windows.Forms.TextBox();
            this.OpenFileButton = new System.Windows.Forms.Button();
            this.ResultsTextbox = new System.Windows.Forms.TextBox();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.FTPConnectiongb.SuspendLayout();
            this.SuspendLayout();
            // 
            // UploadFileBtn
            // 
            this.UploadFileBtn.Location = new System.Drawing.Point(514, 128);
            this.UploadFileBtn.Name = "UploadFileBtn";
            this.UploadFileBtn.Size = new System.Drawing.Size(169, 24);
            this.UploadFileBtn.TabIndex = 4;
            this.UploadFileBtn.Text = "Upload To Host";
            this.UploadFileBtn.UseVisualStyleBackColor = true;
            this.UploadFileBtn.Click += new System.EventHandler(this.UploadFileBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(499, 612);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(85, 33);
            this.ResetBtn.TabIndex = 5;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // FTPConnectiongb
            // 
            this.FTPConnectiongb.Controls.Add(this.ListFilesBtn);
            this.FTPConnectiongb.Controls.Add(this.FTPFolderPathTxtBox);
            this.FTPConnectiongb.Controls.Add(this.label6);
            this.FTPConnectiongb.Controls.Add(this.ProtocolComboBox);
            this.FTPConnectiongb.Controls.Add(this.label5);
            this.FTPConnectiongb.Controls.Add(this.TestConnBtn);
            this.FTPConnectiongb.Controls.Add(this.PasswordTxtBox);
            this.FTPConnectiongb.Controls.Add(this.UserNameTxtBox);
            this.FTPConnectiongb.Controls.Add(this.PortTxtBox);
            this.FTPConnectiongb.Controls.Add(this.HostTxtBox);
            this.FTPConnectiongb.Controls.Add(this.label4);
            this.FTPConnectiongb.Controls.Add(this.label3);
            this.FTPConnectiongb.Controls.Add(this.label2);
            this.FTPConnectiongb.Controls.Add(this.label1);
            this.FTPConnectiongb.Location = new System.Drawing.Point(12, 12);
            this.FTPConnectiongb.Name = "FTPConnectiongb";
            this.FTPConnectiongb.Size = new System.Drawing.Size(671, 110);
            this.FTPConnectiongb.TabIndex = 0;
            this.FTPConnectiongb.TabStop = false;
            this.FTPConnectiongb.Text = "FTP Connection";
            // 
            // TestConnBtn
            // 
            this.TestConnBtn.Location = new System.Drawing.Point(417, 68);
            this.TestConnBtn.Name = "TestConnBtn";
            this.TestConnBtn.Size = new System.Drawing.Size(124, 23);
            this.TestConnBtn.TabIndex = 12;
            this.TestConnBtn.Text = "Test Connection";
            this.TestConnBtn.UseVisualStyleBackColor = true;
            this.TestConnBtn.Click += new System.EventHandler(this.TestConnBtn_Click);
            // 
            // PasswordTxtBox
            // 
            this.PasswordTxtBox.Location = new System.Drawing.Point(255, 70);
            this.PasswordTxtBox.Name = "PasswordTxtBox";
            this.PasswordTxtBox.Size = new System.Drawing.Size(129, 20);
            this.PasswordTxtBox.TabIndex = 9;
            // 
            // UserNameTxtBox
            // 
            this.UserNameTxtBox.Location = new System.Drawing.Point(78, 70);
            this.UserNameTxtBox.Name = "UserNameTxtBox";
            this.UserNameTxtBox.Size = new System.Drawing.Size(130, 20);
            this.UserNameTxtBox.TabIndex = 7;
            // 
            // PortTxtBox
            // 
            this.PortTxtBox.Location = new System.Drawing.Point(326, 41);
            this.PortTxtBox.Name = "PortTxtBox";
            this.PortTxtBox.Size = new System.Drawing.Size(58, 20);
            this.PortTxtBox.TabIndex = 5;
            // 
            // HostTxtBox
            // 
            this.HostTxtBox.Location = new System.Drawing.Point(78, 15);
            this.HostTxtBox.Name = "HostTxtBox";
            this.HostTxtBox.Size = new System.Drawing.Size(306, 20);
            this.HostTxtBox.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(214, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Pwd";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "User";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(252, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Host";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Protocol";
            // 
            // ProtocolComboBox
            // 
            this.ProtocolComboBox.FormattingEnabled = true;
            this.ProtocolComboBox.Items.AddRange(new object[] {
            "FTP",
            "SFTP"});
            this.ProtocolComboBox.Location = new System.Drawing.Point(78, 39);
            this.ProtocolComboBox.Name = "ProtocolComboBox";
            this.ProtocolComboBox.Size = new System.Drawing.Size(121, 21);
            this.ProtocolComboBox.TabIndex = 3;
            // 
            // FTPFolderPathTxtBox
            // 
            this.FTPFolderPathTxtBox.Location = new System.Drawing.Point(473, 19);
            this.FTPFolderPathTxtBox.Name = "FTPFolderPathTxtBox";
            this.FTPFolderPathTxtBox.Size = new System.Drawing.Size(198, 20);
            this.FTPFolderPathTxtBox.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(414, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Folder";
            // 
            // ListFilesBtn
            // 
            this.ListFilesBtn.Location = new System.Drawing.Point(547, 67);
            this.ListFilesBtn.Name = "ListFilesBtn";
            this.ListFilesBtn.Size = new System.Drawing.Size(124, 23);
            this.ListFilesBtn.TabIndex = 13;
            this.ListFilesBtn.Text = "List Files";
            this.ListFilesBtn.UseVisualStyleBackColor = true;
            this.ListFilesBtn.Click += new System.EventHandler(this.ListFilesBtn_Click);
            // 
            // OpenFileDialgobox
            // 
            this.OpenFileDialgobox.FileName = "*.csv";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "File to Upload:";
            // 
            // FileTouploadTextbox
            // 
            this.FileTouploadTextbox.Location = new System.Drawing.Point(125, 128);
            this.FileTouploadTextbox.Name = "FileTouploadTextbox";
            this.FileTouploadTextbox.ReadOnly = true;
            this.FileTouploadTextbox.Size = new System.Drawing.Size(329, 20);
            this.FileTouploadTextbox.TabIndex = 2;
            // 
            // OpenFileButton
            // 
            this.OpenFileButton.Location = new System.Drawing.Point(460, 126);
            this.OpenFileButton.Name = "OpenFileButton";
            this.OpenFileButton.Size = new System.Drawing.Size(33, 23);
            this.OpenFileButton.TabIndex = 3;
            this.OpenFileButton.Text = "(...)";
            this.OpenFileButton.UseVisualStyleBackColor = true;
            this.OpenFileButton.Click += new System.EventHandler(this.OpenFileButton_Click);
            // 
            // ResultsTextbox
            // 
            this.ResultsTextbox.Location = new System.Drawing.Point(4, 175);
            this.ResultsTextbox.Multiline = true;
            this.ResultsTextbox.Name = "ResultsTextbox";
            this.ResultsTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ResultsTextbox.Size = new System.Drawing.Size(679, 431);
            this.ResultsTextbox.TabIndex = 7;
            // 
            // CloseBtn
            // 
            this.CloseBtn.Location = new System.Drawing.Point(590, 612);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(85, 33);
            this.CloseBtn.TabIndex = 6;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // FTPTestHarnessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 649);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.ResultsTextbox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.FileTouploadTextbox);
            this.Controls.Add(this.OpenFileButton);
            this.Controls.Add(this.FTPConnectiongb);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.UploadFileBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FTPTestHarnessForm";
            this.ShowIcon = false;
            this.Text = "FTP Test Harness";
            this.FTPConnectiongb.ResumeLayout(false);
            this.FTPConnectiongb.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UploadFileBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.GroupBox FTPConnectiongb;
        private System.Windows.Forms.ComboBox ProtocolComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button TestConnBtn;
        private System.Windows.Forms.TextBox PasswordTxtBox;
        private System.Windows.Forms.TextBox UserNameTxtBox;
        private System.Windows.Forms.TextBox PortTxtBox;
        private System.Windows.Forms.TextBox HostTxtBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ListFilesBtn;
        private System.Windows.Forms.TextBox FTPFolderPathTxtBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.OpenFileDialog OpenFileDialgobox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox FileTouploadTextbox;
        private System.Windows.Forms.Button OpenFileButton;
        private System.Windows.Forms.TextBox ResultsTextbox;
        private System.Windows.Forms.Button CloseBtn;
    }
}

