﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mn.SSIS.Common.S3FileTransferTestHarness;
using mn.SSIS.Common.ExportToFile.TestHarness;
using mn.SSIS.Common.SMOTestHarness;
using mn.SSIS.Common.FTPTestHarness;

namespace mn.SSIS.Common.TestHarness
{
    public partial class TestHarnessForm : Form
    {
        public TestHarnessForm()
        {
            InitializeComponent();
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TestS3Btn_Click(object sender, EventArgs e)
        {
            S3TestHarnessForm s3TestForm = new S3TestHarnessForm();
            s3TestForm.ShowDialog();
        }

        private void TestExportBtn_Click(object sender, EventArgs e)
        {
            ExportToFileForm export2FileForm = new ExportToFileForm();
            export2FileForm.ShowDialog();
        }

        private void SMOTestBtn_Click(object sender, EventArgs e)
        {
            SMOTestHarnessForm smoTestForm = new SMOTestHarnessForm();
            smoTestForm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FTPTestHarnessForm ftpForm = new FTPTestHarnessForm();
            ftpForm.ShowDialog();
        }

        private void dummy()
        {
            TestHarnessDummy t = new TestHarnessDummy();
            t.DummyTest();
        }
    }
}
