﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using mn.SSIS.Common.BulkCopyLibrary;
using mn.SSIS.Common;
using mn.SSIS.Common.ExportToFile;
using mn.SSIS.Common.CloudFileTransferLibrary;
using mn.SSIS.Common.FTPLibrary;
using mn.SSIS.Common.SMOLibrary;
//using mn.SSIS.Common.SSISPackageLibrary;

namespace mn.SSIS.Common.TestHarness
{
    class TestHarnessDummy
    {
        BulkCopyResults b = null;
        SQLConnector s = null;
        ExportFile e = null;
        FTPclient f = null;
        AWSFileTransfer a = null;
        SMOHelper s1 = null;
        //Type t = typeof(PackageHelper);

        internal void DummyTest()
        {
            if (
                    (b != null)
                && (s != null)
                && (e != null)
                && (f != null)
                && (a != null)
                && (s1 != null)
                //&& (t != null)
                )
            {
                return;
            }
        }
    }
}
