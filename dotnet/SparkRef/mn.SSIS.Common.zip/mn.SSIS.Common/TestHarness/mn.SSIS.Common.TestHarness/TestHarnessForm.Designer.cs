﻿namespace mn.SSIS.Common.TestHarness
{
    partial class TestHarnessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TestS3Btn = new System.Windows.Forms.Button();
            this.TestExportBtn = new System.Windows.Forms.Button();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.SMOTestBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TestS3Btn
            // 
            this.TestS3Btn.Location = new System.Drawing.Point(12, 12);
            this.TestS3Btn.Name = "TestS3Btn";
            this.TestS3Btn.Size = new System.Drawing.Size(155, 23);
            this.TestS3Btn.TabIndex = 0;
            this.TestS3Btn.Text = "Launch S3 Upload Tool";
            this.TestS3Btn.UseVisualStyleBackColor = true;
            this.TestS3Btn.Click += new System.EventHandler(this.TestS3Btn_Click);
            // 
            // TestExportBtn
            // 
            this.TestExportBtn.Location = new System.Drawing.Point(182, 12);
            this.TestExportBtn.Name = "TestExportBtn";
            this.TestExportBtn.Size = new System.Drawing.Size(155, 23);
            this.TestExportBtn.TabIndex = 1;
            this.TestExportBtn.Text = "Launch Export File Tool";
            this.TestExportBtn.UseVisualStyleBackColor = true;
            this.TestExportBtn.Click += new System.EventHandler(this.TestExportBtn_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CloseBtn.Location = new System.Drawing.Point(262, 88);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(75, 23);
            this.CloseBtn.TabIndex = 2;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // SMOTestBtn
            // 
            this.SMOTestBtn.Location = new System.Drawing.Point(12, 56);
            this.SMOTestBtn.Name = "SMOTestBtn";
            this.SMOTestBtn.Size = new System.Drawing.Size(155, 23);
            this.SMOTestBtn.TabIndex = 3;
            this.SMOTestBtn.Text = "Launch SMO Test Tool";
            this.SMOTestBtn.UseVisualStyleBackColor = true;
            this.SMOTestBtn.Click += new System.EventHandler(this.SMOTestBtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(182, 56);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Launch FTP Test Tool";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TestHarnessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CloseBtn;
            this.ClientSize = new System.Drawing.Size(343, 123);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SMOTestBtn);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.TestExportBtn);
            this.Controls.Add(this.TestS3Btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TestHarnessForm";
            this.Text = "Test Harness";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button TestS3Btn;
        private System.Windows.Forms.Button TestExportBtn;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button SMOTestBtn;
        private System.Windows.Forms.Button button1;
    }
}

