﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mn.SSIS.Common.CloudFileTransferLibrary;

namespace mn.SSIS.Common.S3FileTransferTestHarness
{
    public partial class S3TestHarnessForm : Form
    {

        ICloudFileTransfer CloudClient;

        public S3TestHarnessForm()
        {
            InitializeComponent();
            ResetThisForm();

            InitializeAWSClient();
        }

        private void OpenFileButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the open file dialog box.
            //OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Set filter options and filter index.
            OpenFileDialgobox.Filter = "CSV Files (.csv)|*.csv|All Files (*.*)|*.*";
            OpenFileDialgobox.FilterIndex = 1;

            OpenFileDialgobox.Multiselect = false;

            // Call the ShowDialog method to show the dialog box.
            DialogResult userClickedOK = OpenFileDialgobox.ShowDialog();

            // Process input if the user clicked OK.
            if (userClickedOK == DialogResult.OK)
            {
                // Open the selected file to read.
                string strFileName = OpenFileDialgobox.FileName;
                FileTouploadTextbox.Text = strFileName;

                // Read the first line from the file and write it the textbox.
                AddToResults(strFileName);
            }
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ListfilesBtn_Click(object sender, EventArgs e)
        {
            ListFilesInS3(BucketNameTxtBox.Text, SubFolderTextBox.Text);
        }

        private void UploadBtn_Click(object sender, EventArgs e)
        {
            // Open the selected file to read.
            string strFileName = FileTouploadTextbox.Text;
            string strBucketName = BucketNameTxtBox.Text;
            string strKeyPrefix = SubFolderTextBox.Text;

            if (!CheckValidInput(true))
                return;

            // Read the first line from the file and write it the textbox.
            string strKey = strKeyPrefix + System.IO.Path.GetFileName(strFileName);
            AddToResults(string.Format("File to upload: {0}", strKey));

            UploadFileToS3(strFileName, BucketNameTxtBox.Text, strKeyPrefix);
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ResetThisForm();
        }

        private void InitializeAWSClient()
        {
            try
            {
                string profileName = AWSProfileNameTxtBox.Text;
                string profileLocation = AWSProfileLocationTxtBox.Text;
                string region = AWSRegionTxtBox.Text;
                DBAppLogList Results = null;
                // create client only if needed
                if (CloudClient == null)
                {
                    CloudClient = AWSFileTransfer.CreateNewByProfile(profileName, profileLocation, region, out Results);
                    if (Results != null)
                        AddToResults(Results.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please create a AWS JSON Profile file (eg: aws-spark-data-services.json) with correct Access/Secret Keys and enter the Profile Locaiton in AWS Profile Locaiton box");
                MessageBox.Show(ex.Message);
            }
        }

        private void UploadFileToS3(string FileToUpload, string BucketName, string KeyName)
        {
            DBAppLogList Results = null;
            Cursor.Current = Cursors.WaitCursor;
            //DBAppParamList paramList = null;
            try
            {
                InitializeAWSClient();
                if (CloudClient != null)
                {
                    //if (KeyName.Length > 0)
                    //{
                    //    paramList = new DBAppParamList();
                    //    paramList.Add("KeyName", KeyName);
                    //}
                    // call upload function
                    CloudClient.UploadFile(FileToUpload, BucketName, KeyName, out Results);
                    if (Results != null)
                        AddToResults(Results.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void ListFilesInS3(string BucketName, string FilePrefix)
        {
            DBAppLogList Results = null;
            Cursor.Current = Cursors.WaitCursor;
            //DBAppParamList paramList = null;
            try
            {
                InitializeAWSClient();
                if (CloudClient != null)
                {
                    //if (FilePrefix.Length > 0)
                    //{
                    //    paramList = new DBAppParamList();
                    //    paramList.Add("FilePrefix", FilePrefix);
                    //}
                    // call upload function
                    List<string> fileList = CloudClient.ListFiles(BucketName, FilePrefix, out Results);
                    
                    // add file list
                    if (fileList != null)
                    {
                        AddToResults(string.Format("No of Files @ S3 Bucket: {0} is: {1}", BucketName, fileList.Count.ToString()));
                        AddToResults(string.Join(System.Environment.NewLine, fileList));
                    }
                    // add output
                    if (Results != null)
                        AddToResults(Results.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void AddToResults(string ResultMsg)
        {
            ResultsTextbox.AppendText(System.Environment.NewLine);
            ResultsTextbox.AppendText(ResultMsg);
            ResultsTextbox.ScrollToCaret();
        }


        private void ResetThisForm()
        {
            this.BucketNameTxtBox.Text = "spark-data-services";
            this.SubFolderTextBox.Text = "input/redshift/opensub/";
            this.AWSProfileNameTxtBox.Text = "spark-data-services";
            this.AWSProfileLocationTxtBox.Text = "aws-spark-data-services.json";
            this.AWSRegionTxtBox.Text = "us-west-2";
            this.ResultsTextbox.Text = "";
        }

        private bool CheckValidInput(bool CheckFileName)
        {
            bool blnRetval = false;
            string strMsg = "";

            string strFileName = FileTouploadTextbox.Text;
            string strBucketName = BucketNameTxtBox.Text;

            if (strBucketName.Length == 0)
                strMsg = "Please enter valid S3 Bucket Name to upload!";
            else if ((CheckFileName == true) && (strFileName.Length == 0))
                strMsg = "Please enter valid File to Upload!";

            if (strMsg.Length > 0)
                MessageBox.Show(strMsg, "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            blnRetval = (strMsg.Length == 0) ? true : false;

            return blnRetval;
        }
    }
}
