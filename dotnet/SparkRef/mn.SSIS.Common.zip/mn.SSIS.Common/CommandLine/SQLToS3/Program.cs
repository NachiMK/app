﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PowerArgs;
using mn.SSIS.Common.ExportToFile;
using mn.SSIS.Common.CloudFileTransferLibrary;

namespace mn.SSIS.Common.CommandLine.SQLToS3
{
    // A class that describes the command line arguments for this program
    public class SQLToS3Args
    {
        // This argument is required and if not specified the user will 
        // be prompted.
        [ArgRequired(), ArgShortcut("-SQLCon"), ArgDescription("SQL server Connection info."), ArgExample("-SQLCon:server=OCSQL01;user id=Nachi;password= xxx;initial catalog=Indy", "Connects to OCCSQL01")]
        public string SQLConnection { get; set; }

        // This argument is not required, but if specified must be >= 0 and <= 60
        [ArgRequired(), ArgShortcut("-SQLCmd"), ArgDescription("SQL Query you want to run"), ArgExample("-SQLCmd: EXEC mnIndy.dbo.usp_GetRows @P1 = 'test'", "Stored proc or Query you want to Run")]
        public string SQLQuery { get; set; }

        [ArgRequired(), ArgShortcut("-Path"), ArgDescription("Path where data from SQL should be stored with given file name"), ArgExistingDirectory()]
        public string FilePath { get; set; }
        
        [ArgExistingDirectory(), ArgShortcut("-Stage"), ArgDescription("Path where to save files for staging. Default is current directory")]
        public string StagePath { get; set; }

        [ArgRequired(), ArgShortcut("-File"), ArgDescription("Prefix of Filename to save SQL results and to Transfer to S3")]
        public string FilePrefix { get; set; }

        [ArgRequired(), ArgShortcut("-Profile"), ArgDescription("Name of AWS profile")]
        public string awsProfile { get; set; }

        [ArgRequired(), ArgShortcut("-ProfilePath"), ArgExistingFile(), ArgDescription("Path to JSON file that has AWS credentials")]
        public string awsProfilePath { get; set; }

        [ArgShortcut("-Region"), ArgDefaultValue("aws-west"), ArgDescription("Name of AWS region were S3 buckets are stored.")]
        public string awsRegion { get; set; }

        [ArgRequired(), ArgShortcut("-S3Path"), ArgDescription("S3 location and bucket name")]
        public string awsS3Path { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(200);
            sb.AppendLine(string.Format("-SQLCon:{0}", this.SQLConnection));
            sb.AppendLine(string.Format("-SQLCmd:{0}", this.SQLQuery));
            sb.AppendLine(string.Format("-Path:{0}", this.FilePath));
            sb.AppendLine(string.Format("-StagePath:{0}", this.StagePath));
            sb.AppendLine(string.Format("-FilePrefix:{0}", this.FilePrefix));
            sb.AppendLine(string.Format("-Profile:{0}", this.awsProfile));
            sb.AppendLine(string.Format("-ProfilePath:{0}", this.awsProfilePath));
            sb.AppendLine(string.Format("-Region:{0}", this.awsRegion));
            sb.AppendLine(string.Format("-S3Path:{0}", this.awsS3Path));
            return sb.ToString();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var parsed = Args.Parse<SQLToS3Args>(args);
                Console.WriteLine("Args you entered:{0}", parsed.ToString());

                DBAppLogList retList = new DBAppLogList();
                ExportFileList fileList = ExportToFile(parsed);
                foreach (ExportFile e in fileList.Values)
                {
                    if (!string.IsNullOrEmpty(e.ExportedFileName))
                    {
                        AWSFileTransfer objS3Tran = AWSFileTransfer.CreateNewByProfile(parsed.awsProfile, parsed.awsProfilePath, parsed.awsRegion, out retList);
                        if (objS3Tran != null)
                        {
                            objS3Tran.UploadFile(e.ExportedFileName, parsed.awsS3Path, out retList);
                            
                            // remove path
                            string strExportedFile = System.IO.Path.GetFileName(e.ExportedFileName);

                            if (!objS3Tran.CheckFileExists(parsed.awsS3Path, strExportedFile, out retList))
                                retList.Add("File :" + strExportedFile + " was not uploaded to Bucket:" + parsed.awsS3Path, DBLogTypeEnum.Error);
                        }
                    }
                }
                AddToResults(retList.ToString());
            }
            catch (ArgException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ArgUsage.GenerateUsageFromTemplate<SQLToS3Args>());
            }
        }

        static ExportFileList ExportToFile(SQLToS3Args sqlToS3Args)
        {
            ExportFileList FileList = null;
            mn.SSIS.Common.ExportToFile.ExportToFile _ExportToFile = null;
            try
            {
                _ExportToFile = CreateExportToFile(sqlToS3Args);
                if (_ExportToFile != null)
                {
                    // Export data
                    DBAppLogList exportResults = _ExportToFile.Export(out FileList);

                    // add results to text box.
                    if (exportResults != null)
                        AddToResults(exportResults.ToString());

                    // Add export data  to results
                    if (FileList != null)
                        AddToResults(FileList.ToString());
                }
            }
            catch (Exception ex)
            {
                AddToResults(ex.Message);
            }

            return FileList;
        }

        static mn.SSIS.Common.ExportToFile.ExportToFile CreateExportToFile(SQLToS3Args sqlToS3Args)
        {
            mn.SSIS.Common.ExportToFile.ExportToFile _ExportToFile = null;
            IList<string> validationMessages = null;

            SQLConnector _SQLConnector = SQLConnector.NewSQLConnectorByConnectionString(sqlToS3Args.SQLConnection, sqlToS3Args.SQLQuery, out validationMessages);
            if (_SQLConnector == null)
            {
                AddToResults(validationMessages);
            }
            else
            {
                _ExportToFile = mn.SSIS.Common.ExportToFile.ExportToFile.NewExportToFile(_SQLConnector, out validationMessages);
                if (_ExportToFile == null)
                    AddToResults(validationMessages);
                else
                {
                    // COPY OTHER VALUES FROM FORM TO OBJECT    
                    _ExportToFile.AppendDateFormat = true;
                    //_ExportToFile.BatchSize = (MultipleFileRdBtn.Checked) ? (int)BatchSizeNumUpDwn.Value : _ExportToFile.BatchSize;
                    _ExportToFile.CompressionType = FileCompressionTypeEnum.gzip;
                    _ExportToFile.ExportToFileType = ExportToFileTypeEnum.csv;

                    _ExportToFile.ColDelimiter = ColumnDelimiter.Comma;
                    _ExportToFile.RowDelimiter = RowDelimiters.CarriageReturnLineFeed;

                    _ExportToFile.FileDateFormat = "MMddyyyyHHmmss";
                    _ExportToFile.FileEncoding = new UTF8Encoding(false, false);

                    _ExportToFile.FilePrefix = sqlToS3Args.FilePrefix;
                    _ExportToFile.IncludeHeaders = true;
                    _ExportToFile.IncludeTextQualifiers = true;
                    _ExportToFile.SplitFiles = false;
                    _ExportToFile.StagingFileLocation = sqlToS3Args.StagePath;
                    _ExportToFile.DestinationLocation = sqlToS3Args.FilePath;
                }
            }

            return _ExportToFile;
        }

        private static void AddToResults(string Msg)
        {
            Console.WriteLine(System.Environment.NewLine + Msg);
        }

        private static void AddToResults(IList<string> MsgList)
        {
            if ((MsgList != null) && (MsgList.Count > 0))
                Console.WriteLine(System.Environment.NewLine + String.Join(System.Environment.NewLine, MsgList));
        }
    }
}
