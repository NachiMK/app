﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PowerArgs;
using mn.SSIS.Common;
using mn.SSIS.Common.ExportToFile;
using mn.SSIS.Common.FTPLibrary;
using System.IO;

namespace SQLToFTP
{

    [ArgExample("SQLToFTP -SQLCon \"server=lastgdb01;user id=sql_reporting;password= R3p0rt!ng;initial catalog=canaryReporting\" -SQLCmd \"EXEC dbo.usp_Export_mpulse_MembersOptedInForSMS @Database_List = 'vlm6-geha'\" -Path \"C:\\canaryhealth\\etl_data\" -File \"test_\" -Host \"sftp.canaryhealth.com\" -User \"mpulsesecure\" -Pwd \"\" -Port \"22\" -Protocol \"SFTP\" -FTPPath \"upload/mpulsesecure\"", "Example for mpulsesecure upload.")]
    public class SQLToFTPArgs
    {
        // This argument is required and if not specified the user will 
        // be prompted.
        [ArgRequired(), ArgShortcut("-SQLCon"), ArgDescription("SQL server Connection info."), ArgExample("-SQLCon:server=db3;user id=Nachi;password= xxx;initial catalog=vlm6-geha", "Connects to db3")]
        public string SQLConnection { get; set; }

        // This argument is not required, but if specified must be >= 0 and <= 60
        [ArgRequired(), ArgShortcut("-SQLCmd"), ArgDescription("SQL Query you want to run"), ArgExample("-SQLCmd: EXEC dbo.usp_GetRows @P1 = 'test'", "Stored proc or Query you want to Run")]
        public string SQLQuery { get; set; }

        [ArgRequired(), ArgShortcut("-Path"), ArgDescription("Path where data from SQL should be stored with given file name"), ArgExistingDirectory()]
        public string FilePath { get; set; }

        [ArgExistingDirectory(), ArgShortcut("-Stage"), ArgDescription("Path where to save files for staging. Default is current directory")]
        public string StagePath { get; set; }

        [ArgRequired(), ArgShortcut("-File"), ArgDescription("Prefix of Filename to save SQL results and to Transfer to FTP")]
        public string FilePrefix { get; set; }

        [ArgRequired(), ArgShortcut("-Host"), ArgDescription("FTP Host")]
        public string ftpHost { get; set; }

        [ArgShortcut("-Port"), ArgDefaultValue("22"), ArgDescription("FTP Port, example 22 for sFTP")]
        public string ftpPort { get; set; }

        [ArgRequired(), ArgShortcut("-User"), ArgDescription("Username for connecting to FTP")]
        public string ftpUserName { get; set; }

        [ArgRequired(), ArgShortcut("-Pwd"), ArgDescription("FTP/SFTP Password")]
        public string ftpPassword { get; set; }

        [ArgRequired(), ArgShortcut("-P"), ArgDescription("FTP protocol only options are FTP or SFTP.")]
        public string ftpProtocol { get; set; }

        [ArgShortcut("-FTPPath"), ArgDescription("FTP upload path.")]
        public string ftpUploadPath { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(200);
            sb.AppendLine(string.Format("-SQLCon:{0}", this.SQLConnection));
            sb.AppendLine(string.Format("-SQLCmd:{0}", this.SQLQuery));
            sb.AppendLine(string.Format("-Path:{0}", this.FilePath));
            sb.AppendLine(string.Format("-StagePath:{0}", this.StagePath));
            sb.AppendLine(string.Format("-FilePrefix:{0}", this.FilePrefix));
            sb.AppendLine(string.Format("-FTP Host:{0}", this.ftpHost));
            sb.AppendLine(string.Format("-FTP Port:{0}", this.ftpPort));
            sb.AppendLine(string.Format("-FTP UserName:{0}", this.ftpUserName));
            sb.AppendLine(string.Format("-FTP Password:{0}", this.ftpPassword));
            sb.AppendLine(string.Format("-FTP Protocol:{0}", this.ftpProtocol));
            sb.AppendLine(string.Format("-FTP Upload Path:{0}", this.ftpUploadPath));
            return sb.ToString();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var parsed = Args.Parse<SQLToFTPArgs>(args);
                Console.WriteLine("Args you entered:{0}", parsed.ToString());

                DBAppLogList retList = new DBAppLogList();
                ExportFileList fileList = ExportToFile(parsed);
                foreach (ExportFile e in fileList.Values)
                {
                    if (!string.IsNullOrEmpty(e.ExportedFileName))
                    {
                        string strExportedFile = System.IO.Path.GetFileName(e.ExportedFileName);
                        UploadFile(parsed, e.ExportedFileName);
                    }
                }
            }
            catch (ArgException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ArgUsage.GenerateUsageFromTemplate<SQLToFTPArgs>());
            }
        }

        static ExportFileList ExportToFile(SQLToFTPArgs sqlToFTPArgs)
        {
            ExportFileList FileList = null;
            mn.SSIS.Common.ExportToFile.ExportToFile _ExportToFile = null;
            try
            {
                _ExportToFile = CreateExportToFile(sqlToFTPArgs);
                if (_ExportToFile != null)
                {
                    // Export data
                    DBAppLogList exportResults = _ExportToFile.Export(out FileList);

                    // add results to text box.
                    if (exportResults != null)
                        AddToResults(exportResults.ToString());

                    // Add export data  to results
                    if (FileList != null)
                        AddToResults(FileList.ToString());
                }
            }
            catch (Exception ex)
            {
                AddToResults(ex.Message);
            }

            return FileList;
        }

        static mn.SSIS.Common.ExportToFile.ExportToFile CreateExportToFile(SQLToFTPArgs sqlToFTPArgs)
        {
            mn.SSIS.Common.ExportToFile.ExportToFile _ExportToFile = null;
            IList<string> validationMessages = null;

            SQLConnector _SQLConnector = SQLConnector.NewSQLConnectorByConnectionString(sqlToFTPArgs.SQLConnection, sqlToFTPArgs.SQLQuery, out validationMessages);
            if (_SQLConnector == null)
            {
                AddToResults(validationMessages);
            }
            else
            {
                _ExportToFile = mn.SSIS.Common.ExportToFile.ExportToFile.NewExportToFile(_SQLConnector, out validationMessages);
                if (_ExportToFile == null)
                    AddToResults(validationMessages);
                else
                {
                    // COPY OTHER VALUES FROM FORM TO OBJECT    
                    _ExportToFile.AppendDateFormat = true;
                    //_ExportToFile.BatchSize = (MultipleFileRdBtn.Checked) ? (int)BatchSizeNumUpDwn.Value : _ExportToFile.BatchSize;
                    _ExportToFile.CompressionType = FileCompressionTypeEnum.None;
                    _ExportToFile.ExportToFileType = ExportToFileTypeEnum.csv;

                    _ExportToFile.ColDelimiter = ColumnDelimiter.Comma;
                    _ExportToFile.RowDelimiter = RowDelimiters.CarriageReturnLineFeed;

                    _ExportToFile.FileDateFormat = "MMddyyyyHHmmss";
                    _ExportToFile.FileEncoding = new UTF8Encoding(false, false);

                    _ExportToFile.FilePrefix = sqlToFTPArgs.FilePrefix;
                    _ExportToFile.IncludeHeaders = true;
                    _ExportToFile.IncludeTextQualifiers = true;
                    _ExportToFile.SplitFiles = false;
                    _ExportToFile.StagingFileLocation = (string.IsNullOrEmpty(sqlToFTPArgs.StagePath)) ? "" : sqlToFTPArgs.StagePath;
                    _ExportToFile.DestinationLocation = sqlToFTPArgs.FilePath;
                }
            }

            return _ExportToFile;
        }

        private static void UploadFile(SQLToFTPArgs sqlftpArgs, string exportedFile)
        {
            string strMsg;
            DBAppLogList Log = new DBAppLogList();

            bool blnValid = SFTPClient.CheckValidInput(sqlftpArgs.ftpUserName
                , sqlftpArgs.ftpPassword
                , sqlftpArgs.ftpHost
                , sqlftpArgs.ftpPort
                , sqlftpArgs.ftpUploadPath
                , sqlftpArgs.ftpProtocol
                , exportedFile
                , false
                , out strMsg);

            if (blnValid && (!string.IsNullOrEmpty(sqlftpArgs.ftpProtocol)))
            {
                try
                {
                    if (!File.Exists(exportedFile))
                    {
                        AddToResults("File To upload:" + exportedFile + " is missing.");
                    }
                    else
                    {
                        string strTargetFileName = Path.GetFileName(exportedFile);
                        if (sqlftpArgs.ftpProtocol == "FTP")
                        {
                            FTPclient ftpClient = GetFTPClient(sqlftpArgs);
                            AddToResults(string.Format("Uploading File from:{0} to {1}.", exportedFile, strTargetFileName));
                            bool blnUpload = ftpClient.Upload(exportedFile, strTargetFileName);
                            AddToResults("Upload File Results:" + blnUpload.ToString());
                        }
                        else if (sqlftpArgs.ftpProtocol == "SFTP")
                        {
                            int intport = 22;
                            if (!int.TryParse(sqlftpArgs.ftpPort, out intport))
                                intport = 22;

                            SFTPClient.UploadFile(sqlftpArgs.ftpUserName
                                , sqlftpArgs.ftpPassword
                                , sqlftpArgs.ftpHost
                                , intport
                                , sqlftpArgs.ftpUploadPath
                                , exportedFile
                                , true);
                        }

                        SFTPClient.FileExistsInHost(sqlftpArgs.ftpUserName, sqlftpArgs.ftpPassword
                            , sqlftpArgs.ftpHost
                            , sqlftpArgs.ftpPort
                            , sqlftpArgs.ftpUploadPath
                            , sqlftpArgs.ftpProtocol
                            , strTargetFileName
                            , out Log);

                        AddToResults(Log.ToString());

                    }
                }
                catch (Exception ex)
                {
                    AddToResults(ex.Message);
                }
            }
            else
            {
                AddToResults("Invalid Input:" + strMsg);
            }
        }

        private static FTPclient GetFTPClient(SQLToFTPArgs sqlftpArgs)
        {
            FTPclient ftpClient = new FTPclient(sqlftpArgs.ftpHost, sqlftpArgs.ftpUserName, sqlftpArgs.ftpPassword);
            return ftpClient;
        }

        private static void AddToResults(string Msg)
        {
            Console.WriteLine(System.Environment.NewLine + Msg);
        }

        private static void AddToResults(IList<string> MsgList)
        {
            if ((MsgList != null) && (MsgList.Count > 0))
                Console.WriteLine(System.Environment.NewLine + String.Join(System.Environment.NewLine, MsgList));
        }
    }
}
